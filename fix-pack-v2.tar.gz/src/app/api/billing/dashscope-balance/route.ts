/**
 * DashScope / 通义万相 Account Balance Query V2
 * 使用 DashScope 官方余额查询API
 * GET https://dashscope.aliyuncs.com/api/v1/account/quota
 * 如果API查询失败，回退到 DASHSCOPE_ACCOUNT_BALANCE 环境变量
 */
import { NextResponse } from "next/server";

export async function GET() {
  const apiKey = process.env.DASHSCOPE_API_KEY;

  if (!apiKey) {
    const raw = process.env.DASHSCOPE_ACCOUNT_BALANCE;
    if (raw) {
      const balance = parseFloat(raw);
      if (!isNaN(balance)) {
        return NextResponse.json({ availableAmount: balance, availableCashAmount: balance, currency: "CNY", source: "env_var" });
      }
    }
    return NextResponse.json(
      { availableAmount: null, availableCashAmount: null, currency: "CNY", source: "error", error: "通义万相 API Key 未配置，请设置 DASHSCOPE_API_KEY 环境变量" },
      { status: 503 }
    );
  }

  try {
    const res = await fetch("https://dashscope.aliyuncs.com/api/v1/account/quota", {
      method: "GET",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      signal: AbortSignal.timeout(10000),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error("[dashscope-balance] API error:", res.status, errText);
      const raw = process.env.DASHSCOPE_ACCOUNT_BALANCE;
      if (raw) {
        const balance = parseFloat(raw);
        if (!isNaN(balance)) {
          return NextResponse.json({ availableAmount: balance, availableCashAmount: balance, currency: "CNY", source: "env_var_fallback" });
        }
      }
      return NextResponse.json(
        { availableAmount: null, availableCashAmount: null, currency: "CNY", source: "error", error: `通义万相 API 返回错误 (${res.status})` },
        { status: 503 }
      );
    }

    const body = await res.json();
    const data = body?.data;
    
    let availableAmount = 0;
    if (data?.available_quota !== undefined) {
      availableAmount = parseFloat(data.available_quota);
    } else if (data?.quota_usage) {
      const total = parseFloat(data.quota_usage.total_count) || 0;
      const used = parseFloat(data.quota_usage.used_count) || 0;
      availableAmount = total - used;
    } else if (typeof data === 'number') {
      availableAmount = data;
    }

    return NextResponse.json({ availableAmount, availableCashAmount: availableAmount, currency: "CNY", source: "dashscope_api", raw: data });
  } catch (err) {
    console.error("[dashscope-balance] Request failed:", err);
    const raw = process.env.DASHSCOPE_ACCOUNT_BALANCE;
    if (raw) {
      const balance = parseFloat(raw);
      if (!isNaN(balance)) {
        return NextResponse.json({ availableAmount: balance, availableCashAmount: balance, currency: "CNY", source: "env_var_fallback" });
      }
    }
    return NextResponse.json(
      { availableAmount: null, availableCashAmount: null, currency: "CNY", source: "error", error: "通义万相余额查询请求失败" },
      { status: 503 }
    );
  }
}
