import { NextResponse } from 'next/server';

// Alibaba Cloud BSS API - QueryAccountBalance
// Requires: ALIBABA_CLOUD_ACCESS_KEY_ID + ALIBABA_CLOUD_ACCESS_KEY_SECRET
// RAM user needs AliyunBSSReadOnlyAccess permission

const ACCESS_KEY_ID = process.env.ALIBABA_CLOUD_ACCESS_KEY_ID || '';
const ACCESS_KEY_SECRET = process.env.ALIBABA_CLOUD_ACCESS_KEY_SECRET || '';

interface BssBalanceData {
  AvailableCashAmount?: string;
  AvailableAmount?: string;
  CreditAmount?: string;
  Currency?: string;
}

function percentEncode(str: string): string {
  return encodeURIComponent(str)
    .replace(/\+/g, '%20')
    .replace(/\*/g, '%2A')
    .replace(/%7E/g, '~')
    .replace(/!/g, '%21')
    .replace(/'/g, '%27')
    .replace(/\(/g, '%28')
    .replace(/\)/g, '%29');
}

async function callBssApi(action: string): Promise<{ success: boolean; data?: BssBalanceData; message?: string }> {
  if (!ACCESS_KEY_ID || !ACCESS_KEY_SECRET) {
    return { success: false, message: 'AccessKey未配置' };
  }

  const params: Record<string, string> = {
    Action: action,
    Format: 'JSON',
    Version: '2017-12-14',
    AccessKeyId: ACCESS_KEY_ID,
    SignatureMethod: 'HMAC-SHA1',
    SignatureVersion: '1.0',
    SignatureNonce: Math.random().toString(36).substring(2, 15) + Date.now().toString(36),
    Timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
  };

  // Sort and encode parameters
  const sortedKeys = Object.keys(params).sort();
  const canonicalizedQueryString = sortedKeys
    .map(key => `${percentEncode(key)}=${percentEncode(params[key])}`)
    .join('&');

  // Construct string to sign
  const stringToSign = `GET&${percentEncode('/')}&${percentEncode(canonicalizedQueryString)}`;

  // HMAC-SHA1 signature
  const crypto = await import('crypto');
  const signature = crypto
    .createHmac('sha1', ACCESS_KEY_SECRET + '&')
    .update(stringToSign)
    .digest('base64');

  // Add signature to params
  params.Signature = signature;

  // Build final URL
  const url = `https://business.aliyuncs.com/?${sortedKeys
    .map(key => `${percentEncode(key)}=${percentEncode(params[key])}`)
    .join('&')}&Signature=${percentEncode(signature)}`;

  try {
    const response = await fetch(url, {
      method: 'GET',
      headers: { 'Content-Type': 'application/json' },
    });

    const data = await response.json();

    if (data.Code === '200' || data.Success === true) {
      return { success: true, data: data.Data };
    } else {
      return {
        success: false,
        message: data.Message || `BSS API错误 (${data.Code || response.status})`,
      };
    }
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : '网络请求失败';
    return { success: false, message: msg };
  }
}

export async function GET() {
  try {
    // Try BSS QueryAccountBalance first
    const result = await callBssApi('QueryAccountBalance');

    if (result.success && result.data) {
      const balance = result.data;
      const availableAmount = parseFloat(balance.AvailableAmount || '0');
      const cashAmount = parseFloat(balance.AvailableCashAmount || '0');
      const currency = balance.Currency || 'CNY';

      return NextResponse.json({
        provider: '通义万相 (阿里云百炼)',
        balance: availableAmount,
        cashBalance: cashAmount,
        currency,
        source: 'BSS QueryAccountBalance',
        status: 'active',
        detail: `可用额度 ¥${availableAmount.toFixed(2)} / 现金余额 ¥${cashAmount.toFixed(2)}`,
      });
    }

    // Fallback: test API key validity with a lightweight call
    const dashscopeKey =
      process.env.DASHSCOPE_API_KEY ||
      process.env.ALIYUN_API_KEY ||
      process.env.WANXIANG_API_KEY ||
      '';

    if (dashscopeKey) {
      return NextResponse.json({
        provider: '通义万相 (阿里云百炼)',
        balance: -1,
        currency: 'CNY',
        source: 'fallback',
        status: 'key_configured',
        detail: `BSS查询失败: ${result.message}。API Key已配置，但余额需在阿里云控制台查看`,
      });
    }

    return NextResponse.json(
      {
        provider: '通义万相 (阿里云百炼)',
        balance: 0,
        currency: 'CNY',
        error: result.message || '无法查询余额',
        detail: '请配置 ALIBABA_CLOUD_ACCESS_KEY_ID + ALIBABA_CLOUD_ACCESS_KEY_SECRET 环境变量，并授予 AliyunBSSReadOnlyAccess 权限',
      },
      { status: 500 }
    );
  } catch (error: unknown) {
    const msg = error instanceof Error ? error.message : '内部错误';
    return NextResponse.json(
      {
        provider: '通义万相 (阿里云百炼)',
        balance: 0,
        currency: 'CNY',
        error: msg,
      },
      { status: 500 }
    );
  }
}
