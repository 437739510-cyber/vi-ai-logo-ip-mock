/**
 * API: Generate VI Manual PPTX via PptxGenJS Engine V3
 *
 * V3 fixes:
 * - brandColors 从 submission 两种格式都能解析
 * - 传递 brandColors 给 renderPptxToBuffer（V2忘了这步！）
 * - Logo/mascot 多源查找
 * - AI布局端口修复（3001→3000）
 */
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { readFile, mkdir, writeFile, readdir } from "fs/promises";
import { planPages } from "@/lib/page-planner";
import { renderPptxToBuffer } from "@/lib/render-pptx";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { projectId, clientInfo, brandColors, logoUrl, mascotUrl, mascotFiles } = body;

    if (!projectId) {
      return NextResponse.json({ error: "projectId required" }, { status: 400 });
    }

    const companyName = clientInfo?.companyName || clientInfo?.clientName || "";

    // Step 1: Load logo/mascot
    let logoData: string | null = null;
    let mascotData: string | null = null;
    let mascotSplitViews: string[] | null = null;

    if (logoUrl) logoData = await loadImg(logoUrl);
    if (!logoData) logoData = await findAsset(projectId, "logo");

    if (mascotUrl) mascotData = await loadImg(mascotUrl);
    if (!mascotData && mascotFiles?.length > 0) {
      for (const mf of mascotFiles) {
        const url = typeof mf === "string" ? mf : mf.url;
        mascotData = await loadImg(url);
        if (mascotData) break;
      }
    }
    if (!mascotData) mascotData = await findAsset(projectId, "mascot");
    if (mascotData) mascotSplitViews = await findSplitViews(projectId);

    // Step 2: Normalize brandColors — handle BOTH formats
    const realColors = normalizeColors(brandColors, clientInfo?.industry);

    console.log("[generate-pptx] Company:", companyName || "(empty)");
    console.log("[generate-pptx] Logo:", logoData ? "OK" : "null");
    console.log("[generate-pptx] Mascot:", mascotData ? "OK" : "null");
    console.log("[generate-pptx] Colors:", JSON.stringify(realColors));

    // Step 3: Generate Blueprints
    const blueprints = await planPages({
      clientInfo: {
        companyName: companyName || "\u54c1\u724c",
        brandVision: clientInfo?.brandVision || "",
        coreValues: clientInfo?.coreValues || "",
        targetMarket: clientInfo?.targetMarket || "",
        logoPhilosophy: clientInfo?.logoPhilosophy || "",
        mascotPhilosophy: clientInfo?.mascotPhilosophy || "",
        industry: clientInfo?.industry || "",
      },
      brandColors: {
        primary: { hex: realColors.primary },
        secondary: { hex: realColors.secondary },
        accent: { hex: realColors.accent },
      },
      assetAnalysis: {
        logo: { hasLogo: !!logoData, logoUrl: logoUrl || "", elements: [], styleTags: [], meaning: clientInfo?.logoPhilosophy || "" },
        mascot: { hasMascot: !!mascotData, mascotUrl: mascotUrl || "", isThreeView: !!(mascotSplitViews?.length === 3), splitViews: mascotSplitViews || [], name: "", style: "", personality: "" },
      },
    });

    console.log("[generate-pptx] Blueprints:", blueprints.length, "pages");

    // Step 4: Render PPTX — *** 传递 brandColors！（V2忘了这步） ***
    const buffer = await renderPptxToBuffer(blueprints, {
      projectName: projectId,
      companyName: companyName || "\u54c1\u724c",
      logoData,
      mascotData,
      mascotSplitViews,
      brandColors: realColors,  // ← 关键！V2没有传这个
    });

    // Step 5: Save file
    const outputDir = path.join(process.cwd(), "public", "generated");
    await mkdir(outputDir, { recursive: true });
    const fileName = `vi-manual-${projectId}-${Date.now()}.pptx`;
    await writeFile(path.join(outputDir, fileName), buffer);

    return NextResponse.json({
      success: true,
      url: `/generated/${fileName}`,
      pageCount: blueprints.length,
      fileName,
    });
  } catch (error: any) {
    console.error("[generate-pptx] Error:", error);
    return NextResponse.json({ error: error.message || "PPTX generation failed" }, { status: 500 });
  }
}

// ========== Helpers ==========

/** Normalize brandColors from both formats */
function normalizeColors(colors: any, industry?: string): { primary: string; secondary: string; accent: string } {
  const defaults = { primary: "#1A73E8", secondary: "#34A853", accent: "#FBBC04" };
  if (!colors) return defaults;
  // Format 1: { primary: { hex: "#xxx" }, ... } — from Supabase/manual-pages
  if (colors.primary?.hex) {
    return {
      primary: colors.primary.hex || defaults.primary,
      secondary: colors.secondary?.hex || defaults.secondary,
      accent: colors.accent?.hex || defaults.accent,
    };
  }
  // Format 2: { primary: "#xxx", ... } — from Submission type
  if (typeof colors.primary === "string") {
    return {
      primary: colors.primary || defaults.primary,
      secondary: (typeof colors.secondary === "string" ? colors.secondary : defaults.secondary),
      accent: (typeof colors.accent === "string" ? colors.accent : defaults.accent),
    };
  }
  return defaults;
}

async function loadImg(imagePath: string): Promise<string | null> {
  if (!imagePath) return null;
  const candidates = [
    path.join(process.cwd(), "public", imagePath.replace(/^\//, "")),
    path.join(process.cwd(), imagePath),
  ];
  for (const fp of candidates) {
    try {
      const buf = await readFile(fp);
      const ext = path.extname(fp).toLowerCase();
      const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".gif" ? "image/gif" : ext === ".svg" ? "image/svg+xml" : "image/png";
      return `data:${mime};base64,${buf.toString("base64")}`;
    } catch { /* next */ }
  }
  if (imagePath.startsWith("http")) {
    try {
      const resp = await fetch(imagePath);
      if (resp.ok) {
        const buf = Buffer.from(await resp.arrayBuffer());
        const ct = resp.headers.get("content-type") || "image/png";
        return `data:${ct};base64,${buf.toString("base64")}`;
      }
    } catch { /* fail */ }
  }
  return null;
}

async function findAsset(projectId: string, type: "logo" | "mascot"): Promise<string | null> {
  try {
    const dir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(dir);
    const keywords = type === "logo" ? ["logo", "logo-processed"] : ["mascot", "ip", "character"];
    for (const file of files) {
      const lower = file.toLowerCase();
      if (keywords.some(k => lower.includes(k))) {
        const buf = await readFile(path.join(dir, file));
        const ext = path.extname(file).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        return `data:${mime};base64,${buf.toString("base64")}`;
      }
    }
  } catch { /* dir not found */ }
  return null;
}

async function findSplitViews(projectId: string): Promise<string[] | null> {
  try {
    const dir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(dir);
    const views: string[] = [];
    for (const suffix of ["-front", "-side", "-back"]) {
      for (const file of files) {
        if (file.toLowerCase().includes(`mascot${suffix}`) || file.toLowerCase().includes(`ip${suffix}`)) {
          const buf = await readFile(path.join(dir, file));
          const ext = path.extname(file).toLowerCase();
          const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : "image/png";
          views.push(`data:${mime};base64,${buf.toString("base64")}`);
          break;
        }
      }
    }
    return views.length === 3 ? views : null;
  } catch { return null; }
}
