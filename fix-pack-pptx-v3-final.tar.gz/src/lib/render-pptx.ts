/**
 * PptxGenJS Renderer V3 — 专业级 VI 手册渲染
 *
 * V2→V3 核心改动：
 * 1. 所有内容页统一白底+深色文字（不再有白字白底/蓝字蓝底）
 * 2. 品牌颜色从 options.brandColors 直接传入，不再依赖蓝图背景色
 * 3. 封面/结尾用品牌主色做背景+白色文字
 * 4. 色彩页直接显示传入的真实品牌色
 * 5. 场景页白底，不再用品牌色做背景
 * 6. findTextAny 增加模糊匹配，兼容AI和fallback蓝图
 */
import PptxGenJS from "pptxgenjs";
import type { PageBlueprint, PageElement } from "./page-planner";

const SW = 8.27;
const SH = 11.69;
const MARGIN = 0.6;
const CONTENT_W = SW - MARGIN * 2;

export interface RenderPptxOptions {
  projectName?: string;
  companyName?: string;
  logoData?: string | null;
  mascotData?: string | null;
  mascotSplitViews?: string[] | null;
  brandColors?: { primary?: string; secondary?: string; accent?: string };
}

interface BC {
  pri: string; sec: string; acc: string;
  priDark: string;
}

function resolveBC(opts: RenderPptxOptions, blueprints: PageBlueprint[]): BC {
  const p = opts.brandColors?.primary;
  const s = opts.brandColors?.secondary;
  const a = opts.brandColors?.accent;
  if (p && p !== "#FFFFFF" && p !== "#ffffff") {
    return { pri: hx(p), sec: hx(s || "#34A853"), acc: hx(a || "#FBBC04"), priDark: darken(hx(p)) };
  }
  // fallback: from cover blueprint bg
  const cover = blueprints.find(b => b.pageId === "cover");
  if (cover?.background?.primaryColor && cover.background.primaryColor !== "#FFFFFF") {
    return { pri: hx(cover.background.primaryColor), sec: hx(cover.background.secondaryColor || "#34A853"), acc: hx(cover.background.accentColor || "#FBBC04"), priDark: darken(hx(cover.background.primaryColor)) };
  }
  return { pri: "1A73E8", sec: "34A853", acc: "FBBC04", priDark: "0D47A1" };
}

export async function renderPptx(blueprints: PageBlueprint[], options: RenderPptxOptions = {}): Promise<PptxGenJS> {
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: "A4_PORTRAIT", width: SW, height: SH });
  pptx.layout = "A4_PORTRAIT";
  pptx.author = "Brand Brain";
  const cn = options.companyName || "\u54c1\u724c";
  pptx.subject = `${cn} VI \u89c4\u8303\u624b\u518c`;
  pptx.title = `${cn} \u54c1\u724c\u89c6\u89c9\u8bc6\u522b\u7cfb\u7edf\uff08VI\uff09\u89c4\u8303\u624b\u518c`;
  const bc = resolveBC(options, blueprints);
  for (const bp of blueprints) {
    const slide = pptx.addSlide();
    renderSlide(slide, bp, options, bc);
  }
  return pptx;
}

export async function renderPptxToBuffer(blueprints: PageBlueprint[], options: RenderPptxOptions = {}): Promise<Buffer> {
  const pptx = await renderPptx(blueprints, options);
  const base64 = await pptx.write({ outputType: "base64" }) as string;
  return Buffer.from(base64, "base64");
}

const PAGE_ORDER = ["cover","brand-philosophy","logo-interpretation","brand-colors","typography","basic-spec","stationery","packaging","marketing","summary","closing"];

function renderSlide(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  switch (bp.pageId) {
    case "cover": renderCover(slide, bp, opts, bc); break;
    case "closing": renderClosing(slide, bp, opts, bc); break;
    case "brand-philosophy": renderPhilosophy(slide, bp, opts, bc); break;
    case "logo-interpretation": renderLogoPage(slide, bp, opts, bc); break;
    case "brand-colors": renderColors(slide, bp, opts, bc); break;
    case "typography": renderTypography(slide, bp, opts, bc); break;
    case "basic-spec": renderBasicSpec(slide, bp, opts, bc); break;
    case "stationery": renderScene(slide, bp, opts, "stationery", bc); break;
    case "packaging": renderScene(slide, bp, opts, "packaging", bc); break;
    case "marketing": renderScene(slide, bp, opts, "marketing", bc); break;
    case "summary": renderSummary(slide, bp, opts, bc); break;
    default: renderGeneric(slide, bp, opts, bc);
  }
  if (bp.pageId !== "cover" && bp.pageId !== "closing") {
    const idx = PAGE_ORDER.indexOf(bp.pageId);
    slide.addText(`${idx > 0 ? idx : ""}`, { x: SW - MARGIN - 0.5, y: SH - 0.5, w: 0.5, h: 0.3, fontSize: 7, color: "AAAAAA", align: "right" });
  }
}

// ========== Cover ==========
function renderCover(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  const cn = fta(bp, ["cover-company-name","company-name"]) || opts.companyName || "\u54c1\u724c";
  // 品牌主色背景
  slide.background = { fill: bc.pri };
  // 顶部accent条
  slide.addShape("rect", { x: 0, y: 0, w: SW, h: 0.06, fill: { color: bc.acc } });
  // Logo 大图居中
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: (SW - 4.5) / 2, y: 1.2, w: 4.5, h: 2.2, sizing: { type: "contain", w: 4.5, h: 2.2 } });
  } else {
    slide.addShape("rect", { x: (SW - 3) / 2, y: 1.5, w: 3, h: 1.5, fill: { color: "FFFFFF" }, rectRadius: 0.1, line: { color: "CCCCCC", width: 0.5 } });
  }
  // 公司名称
  slide.addText(cn, { x: MARGIN, y: 4.2, w: CONTENT_W, h: 0.8, fontSize: 36, bold: true, color: "FFFFFF", align: "center", fontFace: "Microsoft YaHei" });
  // 分割线
  slide.addShape("line", { x: (SW - 2.5) / 2, y: 5.1, w: 2.5, h: 0, line: { color: bc.acc, width: 1.5 } });
  // 副标题
  slide.addText("\u54c1\u724c\u89c6\u89c9\u8bc6\u522b\u7cfb\u7edf\uff08VI\uff09\u89c4\u8303\u624b\u518c", { x: MARGIN, y: 5.4, w: CONTENT_W, h: 0.5, fontSize: 18, bold: true, color: "FFFFFF", align: "center", transparency: 10 });
  slide.addText("VISUAL IDENTITY GUIDELINES", { x: MARGIN, y: 5.9, w: CONTENT_W, h: 0.35, fontSize: 12, color: "FFFFFF", align: "center", transparency: 30, charSpacing: 4 });
  // IP
  if (opts.mascotData) {
    slide.addImage({ data: normImg(opts.mascotData), x: SW - 3.5, y: 4.5, w: 2.8, h: 3.2, sizing: { type: "contain", w: 2.8, h: 3.2 }, transparency: 5 });
  }
  // 底部
  slide.addText(`${cn}  \u00b7  v1.0  \u00b7  ${new Date().getFullYear()}`, { x: MARGIN, y: SH - 1.2, w: CONTENT_W, h: 0.3, fontSize: 11, color: "FFFFFF", align: "center", transparency: 30 });
  slide.addShape("rect", { x: 0, y: SH - 0.08, w: SW, h: 0.08, fill: { color: bc.acc } });
}

// ========== Closing ==========
function renderClosing(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  const cn = opts.companyName || "\u54c1\u724c";
  slide.background = { fill: bc.pri };
  slide.addText("\u611f\u8c22\u89c2\u770b", { x: MARGIN, y: SH / 2 - 1.5, w: CONTENT_W, h: 0.8, fontSize: 32, bold: true, color: "FFFFFF", align: "center" });
  slide.addText(`${cn} \u00b7 \u54c1\u724c\u89c6\u89c9\u8bc6\u522b\u7cfb\u7edf (VI) \u89c4\u8303\u624b\u518c`, { x: MARGIN, y: SH / 2 - 0.5, w: CONTENT_W, h: 0.4, fontSize: 13, color: "FFFFFF", align: "center", transparency: 30 });
  if (opts.mascotData) {
    slide.addImage({ data: normImg(opts.mascotData), x: (SW - 2) / 2, y: SH / 2 + 0.5, w: 2, h: 2.3, sizing: { type: "contain", w: 2, h: 2.3 }, transparency: 20 });
  }
  slide.addText(`\u5982\u6709\u7591\u95ee\uff0c\u8bf7\u8054\u7cfb ${cn}`, { x: MARGIN, y: SH - 1.5, w: CONTENT_W, h: 0.3, fontSize: 10, color: "FFFFFF", align: "center", transparency: 40 });
  slide.addShape("rect", { x: 0, y: SH - 0.08, w: SW, h: 0.08, fill: { color: bc.acc } });
}

// ========== Content Page Header (WHITE BG + DARK TEXT) ==========
function addHeader(slide: PptxGenJS.Slide, title: string, bc: BC): void {
  slide.background = { fill: "FFFFFF" };
  slide.addShape("rect", { x: 0, y: 0, w: SW, h: 0.05, fill: { color: bc.pri } });
  slide.addText(title, { x: MARGIN, y: 0.4, w: CONTENT_W, h: 0.5, fontSize: 20, bold: true, color: bc.priDark });
  slide.addShape("rect", { x: MARGIN, y: 0.95, w: 1.5, h: 0.04, fill: { color: bc.acc } });
}

// ========== Brand Philosophy ==========
function renderPhilosophy(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "\u54c1\u724c\u6838\u5fc3\u7406\u5ff5", bc);
  const sections = extractPhilSections(bp);
  let yPos = 1.8;
  for (let i = 0; i < sections.length; i++) {
    const s = sections[i];
    // 左侧品牌色竖条
    slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.08, h: 1.4, fill: { color: bc.pri } });
    // 标签 — 品牌色文字
    slide.addText(s.label, { x: MARGIN + 0.2, y: yPos, w: CONTENT_W - 0.2, h: 0.35, fontSize: 14, bold: true, color: bc.pri });
    // 内容 — 深色文字
    slide.addText(s.content, { x: MARGIN + 0.2, y: yPos + 0.4, w: CONTENT_W - 0.2, h: 0.9, fontSize: 11, color: "444444", lineSpacingMultiple: 1.5 });
    if (i < sections.length - 1) {
      slide.addShape("rect", { x: MARGIN, y: yPos + 1.5, w: CONTENT_W, h: 0.01, fill: { color: "E0E0E0" } });
    }
    yPos += 1.8;
  }
  // 小IP
  if (opts.mascotData) {
    slide.addImage({ data: normImg(opts.mascotData), x: SW - MARGIN - 1.4, y: SH - 3.5, w: 1.4, h: 1.7, sizing: { type: "contain", w: 1.4, h: 1.7 }, transparency: 10 });
  }
}

// ========== Logo Interpretation ==========
function renderLogoPage(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "\u6807\u8bc6\u8be0\u91ca", bc);
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: (SW - 3.5) / 2, y: 1.8, w: 3.5, h: 2.5, sizing: { type: "contain", w: 3.5, h: 2.5 } });
  } else {
    slide.addShape("rect", { x: (SW - 3.5) / 2, y: 1.8, w: 3.5, h: 2.5, fill: { color: "F5F5F5" }, line: { color: "CCCCCC", width: 0.5, dashType: "dash" }, rectRadius: 0.1 });
    slide.addText("LOGO", { x: (SW - 3.5) / 2, y: 2.5, w: 3.5, h: 1, fontSize: 20, color: "CCCCCC", align: "center", valign: "middle" });
  }
  const meaning = fta(bp, ["logo-meaning","logo-philosophy","logo-desc","meaning"]);
  if (meaning) {
    slide.addText(meaning, { x: MARGIN, y: 4.8, w: CONTENT_W, h: 1.0, fontSize: 11, color: "444444", align: "center", lineSpacingMultiple: 1.5 });
  }
  const elements = fta(bp, ["logo-elements","elements-desc"]);
  if (elements) {
    slide.addShape("rect", { x: MARGIN, y: 6.0, w: CONTENT_W, h: 0.08, fill: { color: bc.pri } });
    slide.addText("\u8bbe\u8ba1\u5143\u7d20\u62c6\u89e3", { x: MARGIN, y: 6.2, w: CONTENT_W, h: 0.3, fontSize: 12, bold: true, color: bc.pri });
    slide.addText(elements, { x: MARGIN, y: 6.6, w: CONTENT_W, h: 1.0, fontSize: 10, color: "555555", lineSpacingMultiple: 1.4 });
  }
  if (opts.mascotData) {
    slide.addText("IP \u89d2\u8272\u4ecb\u7ecd", { x: MARGIN, y: 7.8, w: CONTENT_W, h: 0.3, fontSize: 12, bold: true, color: bc.pri });
    if (opts.mascotSplitViews && opts.mascotSplitViews.length === 3) {
      const vw = 1.8, gap = (CONTENT_W - vw * 3) / 2;
      for (let v = 0; v < 3; v++) {
        slide.addImage({ data: normImg(opts.mascotSplitViews[v]), x: MARGIN + v * (vw + gap), y: 8.15, w: vw, h: 2.0, sizing: { type: "contain", w: vw, h: 2.0 } });
      }
    } else {
      slide.addImage({ data: normImg(opts.mascotData), x: (SW - 1.8) / 2, y: 8.15, w: 1.8, h: 2.0, sizing: { type: "contain", w: 1.8, h: 2.0 } });
    }
  }
}

// ========== Brand Colors ==========
function renderColors(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "\u6807\u51c6\u8272\u5f69\u89c4\u8303", bc);
  // 直接用传入的真实品牌色，不再从蓝图提取（蓝图颜色经常错）
  const colors = [
    { hex: bc.pri, name: "\u54c1\u724c\u4e3b\u8272" },
    { hex: bc.sec, name: "\u8f85\u52a9\u8272" },
    { hex: bc.acc, name: "\u5f3a\u8c03\u8272" },
  ];
  const bw = 2.2, gap = (CONTENT_W - bw * 3) / 2;
  for (let i = 0; i < 3; i++) {
    const c = colors[i];
    const x = MARGIN + i * (bw + gap);
    // 色块
    slide.addShape("rect", { x, y: 2.0, w: bw, h: 1.3, fill: { color: c.hex }, rectRadius: 0.05, shadow: { type: "outer", blur: 3, offset: 2, color: "000000", opacity: 0.08 } });
    // 如果色块很浅，加边框
    if (isLight(c.hex)) {
      slide.addShape("rect", { x, y: 2.0, w: bw, h: 1.3, fill: { color: c.hex }, rectRadius: 0.05, line: { color: "CCCCCC", width: 0.5 } });
    }
    // 色名
    slide.addText(c.name, { x, y: 3.4, w: bw, h: 0.25, fontSize: 10, bold: true, color: "333333", align: "center" });
    // Hex
    slide.addText(`#${c.hex}`, { x, y: 3.65, w: bw, h: 0.2, fontSize: 9, color: "666666", align: "center" });
    // RGB
    const rgb = hex2rgb(c.hex);
    if (rgb) {
      slide.addText(`RGB: ${rgb.r}, ${rgb.g}, ${rgb.b}`, { x, y: 3.85, w: bw, h: 0.2, fontSize: 8, color: "888888", align: "center" });
      const cmyk = rgb2cmyk(rgb);
      if (cmyk) {
        slide.addText(`CMYK: ${cmyk.c}, ${cmyk.m}, ${cmyk.y}, ${cmyk.k}`, { x, y: 4.05, w: bw, h: 0.2, fontSize: 8, color: "888888", align: "center" });
      }
    }
  }
  // 组合示例
  slide.addText("\u8272\u5f69\u7ec4\u5408\u793a\u4f8b", { x: MARGIN, y: 5.0, w: CONTENT_W, h: 0.35, fontSize: 12, bold: true, color: bc.pri });
  // 示例1
  slide.addShape("rect", { x: MARGIN, y: 5.5, w: 3.4, h: 0.6, fill: { color: bc.pri } });
  slide.addShape("rect", { x: MARGIN + 3.4, y: 5.5, w: 3.47, h: 0.6, fill: { color: bc.sec } });
  slide.addText("\u4e3b\u8272 + \u8f85\u52a9\u8272", { x: MARGIN, y: 6.15, w: CONTENT_W, h: 0.2, fontSize: 8, color: "888888" });
  // 示例2
  slide.addShape("rect", { x: MARGIN, y: 6.7, w: 4.9, h: 0.6, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: MARGIN + 4.9, y: 6.7, w: 1.97, h: 0.6, fill: { color: bc.acc } });
  slide.addText("\u767d\u5e95 + \u5f3a\u8c03\u8272\u70b9\u7f00", { x: MARGIN, y: 7.35, w: CONTENT_W, h: 0.2, fontSize: 8, color: "888888" });
  // 示例3
  slide.addShape("rect", { x: MARGIN, y: 7.9, w: 3.0, h: 0.6, fill: { color: bc.priDark } });
  slide.addShape("rect", { x: MARGIN + 3.0, y: 7.9, w: 3.87, h: 0.6, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addText("\u6df1\u8272\u4e3b\u8272 + \u767d\u5e95", { x: MARGIN, y: 8.55, w: CONTENT_W, h: 0.2, fontSize: 8, color: "888888" });
}

// ========== Typography ==========
function renderTypography(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "\u5b57\u4f53\u7cfb\u7edf", bc);
  slide.addShape("rect", { x: MARGIN, y: 1.8, w: 0.08, h: 1.2, fill: { color: bc.pri } });
  slide.addText("\u4e2d\u6587\u5b57\u4f53", { x: MARGIN + 0.2, y: 1.8, w: CONTENT_W - 0.2, h: 0.3, fontSize: 14, bold: true, color: bc.pri });
  slide.addText("\u54c1\u724c\u5b57\u4f53\uff1a\u601d\u6e90\u9ed1\u4f53 / Noto Sans SC", { x: MARGIN + 0.2, y: 2.2, w: CONTENT_W - 0.2, h: 0.3, fontSize: 11, color: "444444" });
  slide.addText("\u6b63\u6587\u5b57\u4f53\uff1a\u601d\u6e90\u5b8b\u4f53 / Noto Serif SC", { x: MARGIN + 0.2, y: 2.5, w: CONTENT_W - 0.2, h: 0.3, fontSize: 11, color: "444444" });
  slide.addText("AaBbCc \u4f60\u597d\u4e16\u754c 0123", { x: MARGIN + 0.2, y: 2.85, w: CONTENT_W - 0.2, h: 0.35, fontSize: 20, color: "333333", fontFace: "Microsoft YaHei" });
  slide.addShape("rect", { x: MARGIN, y: 3.6, w: 0.08, h: 1.2, fill: { color: bc.sec } });
  slide.addText("\u82f1\u6587\u5b57\u4f53", { x: MARGIN + 0.2, y: 3.6, w: CONTENT_W - 0.2, h: 0.3, fontSize: 14, bold: true, color: bc.sec });
  slide.addText("Brand Font: Montserrat", { x: MARGIN + 0.2, y: 4.0, w: CONTENT_W - 0.2, h: 0.3, fontSize: 11, color: "444444" });
  slide.addText("Body Font: Open Sans", { x: MARGIN + 0.2, y: 4.3, w: CONTENT_W - 0.2, h: 0.3, fontSize: 11, color: "444444" });
  slide.addText("AaBbCc Hello World 0123", { x: MARGIN + 0.2, y: 4.65, w: CONTENT_W - 0.2, h: 0.35, fontSize: 20, color: "333333" });
  slide.addText("\u5b57\u53f7\u5c42\u7ea7\u89c4\u8303", { x: MARGIN, y: 5.5, w: CONTENT_W, h: 0.3, fontSize: 12, bold: true, color: bc.pri });
  const rows = [
    [{ text: "\u7c7b\u522b", options: { bold: true, color: "FFFFFF", fill: { color: bc.pri }, fontSize: 9 } }, { text: "\u5b57\u53f7", options: { bold: true, color: "FFFFFF", fill: { color: bc.pri }, fontSize: 9 } }, { text: "\u7528\u9014", options: { bold: true, color: "FFFFFF", fill: { color: bc.pri }, fontSize: 9 } }],
    [{ text: "\u4e3b\u6807\u9898", options: { fontSize: 9, color: "333333" } }, { text: "28-36pt", options: { fontSize: 9, color: "333333" } }, { text: "\u5c01\u9762/\u91cd\u8981\u9875\u5927\u6807\u9898", options: { fontSize: 9, color: "333333" } }],
    [{ text: "\u526f\u6807\u9898", options: { fontSize: 9, color: "333333" } }, { text: "18-24pt", options: { fontSize: 9, color: "333333" } }, { text: "\u7ae0\u8282\u6807\u9898", options: { fontSize: 9, color: "333333" } }],
    [{ text: "\u5c0f\u6807\u9898", options: { fontSize: 9, color: "333333" } }, { text: "12-14pt", options: { fontSize: 9, color: "333333" } }, { text: "\u533a\u5757\u6807\u9898", options: { fontSize: 9, color: "333333" } }],
    [{ text: "\u6b63\u6587", options: { fontSize: 9, color: "333333" } }, { text: "10-11pt", options: { fontSize: 9, color: "333333" } }, { text: "\u5185\u5bb9\u6587\u5b57", options: { fontSize: 9, color: "333333" } }],
    [{ text: "\u6ce8\u91ca", options: { fontSize: 9, color: "333333" } }, { text: "8-9pt", options: { fontSize: 9, color: "333333" } }, { text: "\u8bf4\u660e/\u811a\u6ce8", options: { fontSize: 9, color: "333333" } }],
  ];
  slide.addTable(rows, { x: MARGIN, y: 5.9, w: CONTENT_W, colW: [2.0, 2.0, 3.07], border: { pt: 0.5, color: "E0E0E0" }, rowH: [0.35, 0.35, 0.35, 0.35, 0.35, 0.35] });
}

// ========== Basic Spec ==========
function renderBasicSpec(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "\u57fa\u7840\u89c4\u8303", bc);
  slide.addText("LOGO \u4fdd\u62a4\u7a7a\u95f4", { x: MARGIN, y: 1.5, w: CONTENT_W, h: 0.3, fontSize: 13, bold: true, color: bc.pri });
  slide.addText("LOGO \u56db\u5468\u4fdd\u7559\u81f3\u5c11 15% \u4fdd\u62a4\u7a7a\u95f4\uff0c\u4e0d\u53ef\u88ab\u4efb\u4f55\u5143\u7d20\u906e\u6321\u6216\u88c1\u5207", { x: MARGIN, y: 1.9, w: CONTENT_W, h: 0.3, fontSize: 10, color: "555555" });
  if (opts.logoData) {
    const ls = 2.0, pd = ls * 0.15, ts = ls + pd * 2;
    slide.addShape("rect", { x: (SW - ts) / 2, y: 2.5, w: ts, h: ts, fill: { color: "F5F5F5" }, line: { color: "CCCCCC", width: 0.5, dashType: "dash" } });
    slide.addImage({ data: normImg(opts.logoData), x: (SW - ls) / 2, y: 2.5 + pd, w: ls, h: ls, sizing: { type: "contain", w: ls, h: ls } });
    slide.addText("15%", { x: (SW - ts) / 2 + 0.05, y: 2.5 + pd / 2 - 0.1, w: 0.5, h: 0.2, fontSize: 7, color: "AAAAAA" });
  }
  slide.addText("\u6700\u5c0f\u5c3a\u5bf8\u89c4\u8303", { x: MARGIN, y: 6.5, w: CONTENT_W, h: 0.3, fontSize: 12, bold: true, color: bc.pri });
  const rows = [
    [{ text: "\u5a92\u4ecb", options: { bold: true, color: "FFFFFF", fill: { color: bc.pri }, fontSize: 9 } }, { text: "\u6700\u5c0f\u5bbd\u5ea6", options: { bold: true, color: "FFFFFF", fill: { color: bc.pri }, fontSize: 9 } }, { text: "\u8bf4\u660e", options: { bold: true, color: "FFFFFF", fill: { color: bc.pri }, fontSize: 9 } }],
    [{ text: "\u5370\u5237\u54c1", options: { fontSize: 9, color: "333333" } }, { text: "20mm", options: { fontSize: 9, color: "333333" } }, { text: "\u540d\u7247/\u4fe1\u5c01\u7b49\u5c0f\u5c3a\u5bf8\u5370\u5237\u7269", options: { fontSize: 9, color: "333333" } }],
    [{ text: "\u5c4f\u5e55\u663e\u793a", options: { fontSize: 9, color: "333333" } }, { text: "80px", options: { fontSize: 9, color: "333333" } }, { text: "\u7f51\u7ad9/App \u7b49\u6570\u5b57\u5a92\u4ecb", options: { fontSize: 9, color: "333333" } }],
    [{ text: "\u6237\u5916\u5e7f\u544a", options: { fontSize: 9, color: "333333" } }, { text: "200mm", options: { fontSize: 9, color: "333333" } }, { text: "\u5e7f\u544a\u724c/\u5c55\u67b6\u7b49\u5927\u5c3a\u5bf8\u573a\u666f", options: { fontSize: 9, color: "333333" } }],
  ];
  slide.addTable(rows, { x: MARGIN, y: 6.9, w: CONTENT_W, colW: [1.5, 1.5, 4.07], border: { pt: 0.5, color: "E0E0E0" }, rowH: [0.35, 0.35, 0.35, 0.35] });
}

// ========== Scene Pages (WHITE BG!) ==========
function renderScene(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, type: string, bc: BC): void {
  slide.background = { fill: "FFFFFF" };
  const titles: Record<string, string> = { stationery: "\u529e\u516c\u5e94\u7528\u7cfb\u7edf", packaging: "\u4ea7\u54c1\u5305\u88c5\u7cfb\u7edf", marketing: "\u8425\u9500\u5c55\u793a\u7cfb\u7edf" };
  const descs: Record<string, string> = { stationery: "\u54c1\u724c\u5728\u5546\u52a1\u573a\u666f\u4e2d\u7684\u6807\u51c6\u5316\u5e94\u7528\u3002", packaging: "\u54c1\u724c\u4e3b\u8272\u8c03\u8d2f\u7a7f\u5305\u88c5\u8bbe\u8ba1\u3002", marketing: "\u573a\u666f\u5316\u54c1\u724c\u89c6\u89c9\u5e94\u7528\u3002" };
  addHeader(slide, titles[type] || type, bc);
  slide.addText(descs[type] || "", { x: MARGIN, y: 1.8, w: CONTENT_W, h: 0.5, fontSize: 10, color: "666666" });
  if (type === "stationery") drawStationery(slide, bc, opts);
  else if (type === "packaging") drawPackaging(slide, bc, opts);
  else drawMarketing(slide, bc, opts);
}

function drawStationery(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  const cw = 3.5, ch = 2.0, cx = (SW - cw) / 2, sy = 2.8;
  slide.addShape("rect", { x: cx, y: sy, w: cw, h: ch, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.5 }, rectRadius: 0.05, shadow: { type: "outer", blur: 3, offset: 2, color: "000000", opacity: 0.1 } });
  slide.addShape("rect", { x: cx, y: sy, w: 0.1, h: ch, fill: { color: bc.pri }, rectRadius: 0.05 });
  if (opts.logoData) slide.addImage({ data: normImg(opts.logoData), x: cx + 0.3, y: sy + 0.2, w: 1.2, h: 0.6, sizing: { type: "contain", w: 1.2, h: 0.6 } });
  slide.addText("\u59d3\u540d / \u804c\u4f4d\n\u8054\u7cfb\u65b9\u5f0f", { x: cx + 0.3, y: sy + 1.0, w: 2.5, h: 0.7, fontSize: 8, color: "888888", lineSpacingMultiple: 1.3 });
  slide.addText("\u540d\u7247", { x: cx, y: sy + ch + 0.1, w: cw, h: 0.2, fontSize: 8, color: "AAAAAA", align: "center" });
  const ey = sy + ch + 0.8, ew = 4.0, eh = 2.5, ex = (SW - ew) / 2;
  slide.addShape("rect", { x: ex, y: ey, w: ew, h: eh, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.5 }, rectRadius: 0.05, shadow: { type: "outer", blur: 3, offset: 2, color: "000000", opacity: 0.1 } });
  slide.addShape("rect", { x: ex, y: ey, w: ew, h: 0.15, fill: { color: bc.pri }, rectRadius: 0.05 });
  if (opts.logoData) slide.addImage({ data: normImg(opts.logoData), x: ex + ew - 1.3, y: ey + 0.4, w: 0.9, h: 0.5, sizing: { type: "contain", w: 0.9, h: 0.5 } });
  slide.addText("\u4fe1\u5c01", { x: ex, y: ey + eh + 0.1, w: ew, h: 0.2, fontSize: 8, color: "AAAAAA", align: "center" });
  const ly = ey + eh + 0.7;
  slide.addShape("rect", { x: (SW - 3.5) / 2, y: ly, w: 3.5, h: 1.0, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.5 }, rectRadius: 0.05 });
  slide.addShape("rect", { x: (SW - 3.5) / 2, y: ly, w: 3.5, h: 0.08, fill: { color: bc.pri } });
  slide.addText("\u4fe1\u7eb8 / \u62a5\u4fe1\u7eb8", { x: (SW - 3.5) / 2, y: ly + 0.3, w: 3.5, h: 0.5, fontSize: 8, color: "CCCCCC", align: "center", valign: "middle" });
}

function drawPackaging(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  const bw = 3.0, bh = 3.5, bx = (SW - bw) / 2, sy = 2.8;
  slide.addShape("rect", { x: bx, y: sy, w: bw, h: bh, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.5 }, rectRadius: 0.05, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.12 } });
  slide.addShape("rect", { x: bx, y: sy + bh * 0.3, w: bw, h: bh * 0.3, fill: { color: bc.pri } });
  if (opts.logoData) slide.addImage({ data: normImg(opts.logoData), x: bx + 0.5, y: sy + bh * 0.3 + 0.2, w: 2.0, h: 1.0, sizing: { type: "contain", w: 2.0, h: 1.0 } });
  slide.addText("\u4ea7\u54c1\u5305\u88c5\u76d2", { x: bx, y: sy + bh + 0.1, w: bw, h: 0.2, fontSize: 8, color: "AAAAAA", align: "center" });
  const bgY = sy + bh + 1.0, bgW = 2.5, bgH = 3.0, bgX = (SW - bgW) / 2;
  slide.addShape("rect", { x: bgX, y: bgY, w: bgW, h: bgH, fill: { color: bc.pri }, line: { color: "E0E0E0", width: 0.5 }, rectRadius: 0.05, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.12 } });
  if (opts.logoData) slide.addImage({ data: normImg(opts.logoData), x: bgX + 0.4, y: bgY + 0.5, w: 1.7, h: 1.2, sizing: { type: "contain", w: 1.7, h: 1.2 } });
  slide.addText("\u624b\u63d0\u888b / \u5916\u5356\u888b", { x: bgX, y: bgY + bgH + 0.1, w: bgW, h: 0.2, fontSize: 8, color: "AAAAAA", align: "center" });
}

function drawMarketing(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  const pw = 3.5, ph = 5.0, px = (SW - pw) / 2, sy = 2.8;
  slide.addShape("rect", { x: px, y: sy, w: pw, h: ph, fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.5 }, rectRadius: 0.05, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.12 } });
  slide.addShape("rect", { x: px, y: sy, w: pw, h: ph * 0.5, fill: { color: bc.pri }, rectRadius: 0.05 });
  if (opts.logoData) slide.addImage({ data: normImg(opts.logoData), x: px + 0.8, y: sy + 0.5, w: 1.9, h: 1.2, sizing: { type: "contain", w: 1.9, h: 1.2 } });
  slide.addText("\u54c1\u724c\u4e3b\u6807\u9898", { x: px + 0.3, y: sy + ph * 0.5 + 0.3, w: pw - 0.6, h: 0.4, fontSize: 12, bold: true, color: "333333" });
  slide.addText("\u526f\u6807\u9898\u6587\u5b57\u8bf4\u660e", { x: px + 0.3, y: sy + ph * 0.5 + 0.8, w: pw - 0.6, h: 0.3, fontSize: 9, color: "888888" });
  slide.addText("\u6d77\u62a5 / \u5ba3\u4f20\u9875", { x: px, y: sy + ph + 0.1, w: pw, h: 0.2, fontSize: 8, color: "AAAAAA", align: "center" });
}

// ========== Summary ==========
function renderSummary(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "\u603b\u7ed3", bc);
  const vision = fta(bp, ["ph-vision-content","brand-vision-content","vision-content"]);
  if (vision && vision !== "\u5f85\u5b9a") {
    slide.addText(`\u201c${vision}\u201d`, { x: MARGIN + 0.3, y: 2.0, w: CONTENT_W - 0.6, h: 1.0, fontSize: 13, italic: true, color: bc.pri, align: "center", lineSpacingMultiple: 1.5 });
  }
  const pillars = [
    { label: "\u4e00\u81f4\u6027", desc: "\u6240\u6709\u5a92\u4ecb\u8f93\u51fa\u5fc5\u987b\u4e25\u683c\u9075\u5b88\u672c\u624b\u518c\u89c4\u8303\uff0c\u786e\u4fdd\u54c1\u724c\u5728\u4efb\u4f55\u89e6\u70b9\u4e0b\u90fd\u80fd\u88ab\u7cbe\u51c6\u8bc6\u522b" },
    { label: "\u4e13\u4e1a\u6027", desc: "\u901a\u8fc7\u6807\u51c6\u5316\u7684\u89c6\u89c9\u8bed\u8a00\u5efa\u7acb\u5ba2\u6237\u4fe1\u4efb\uff0c\u5c55\u73b0\u54c1\u724c\u4f5c\u4e3a\u884c\u4e1a\u4e13\u5bb6\u7684\u4e13\u4e1a\u5f62\u8c61" },
    { label: "\u6301\u7eed\u6027", desc: "VI \u7cfb\u7edf\u662f\u54c1\u724c\u957f\u671f\u53d1\u5c55\u7684\u6838\u5fc3\u65e0\u5f62\u8d44\u4ea7\uff0c\u662f\u54c1\u724c\u4ef7\u503c\u6301\u7eed\u79ef\u7d2f\u7684\u89c6\u89c9\u8f7d\u4f53" },
  ];
  let yPos = 3.5;
  for (let i = 0; i < pillars.length; i++) {
    const p = pillars[i];
    slide.addShape("ellipse", { x: MARGIN + 0.2, y: yPos, w: 0.4, h: 0.4, fill: { color: bc.pri } });
    slide.addText(`${i + 1}`, { x: MARGIN + 0.2, y: yPos, w: 0.4, h: 0.4, fontSize: 12, bold: true, color: "FFFFFF", align: "center", valign: "middle" });
    slide.addText(p.label, { x: MARGIN + 0.8, y: yPos, w: 2, h: 0.35, fontSize: 13, bold: true, color: bc.pri });
    slide.addText(p.desc, { x: MARGIN + 0.8, y: yPos + 0.4, w: CONTENT_W - 1, h: 0.6, fontSize: 10, color: "555555", lineSpacingMultiple: 1.4 });
    yPos += 1.3;
  }
  const cv = fta(bp, ["ph-values-content","core-values-content","values-content"]);
  if (cv && cv !== "\u5f85\u5b9a") {
    slide.addText(`\u6838\u5fc3\u4ef7\u503c\uff1a${cv}`, { x: MARGIN, y: SH - 1.8, w: CONTENT_W, h: 0.3, fontSize: 10, color: bc.pri, align: "center", bold: true });
  }
}

// ========== Generic ==========
function renderGeneric(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, bp.label || bp.pageId, bc);
  let yPos = 1.8;
  for (const el of bp.elements) {
    if (el.type === "text" && el.content) {
      const fs = el.fontSize ? Math.max(8, Math.round(el.fontSize * 0.6)) : 11;
      slide.addText(el.content, { x: MARGIN, y: yPos, w: CONTENT_W, h: 0.4, fontSize: fs, bold: (el.fontWeight || 400) >= 600, color: "333333" });
      yPos += 0.5;
    }
  }
}

// ========== Helpers ==========
function hx(c: string): string { return c.replace("#", "").toUpperCase(); }
function normImg(d: string): string { return d.startsWith("data:") ? d : `data:image/png;base64,${d}`; }
function darken(hex: string): string {
  const c = hex.replace("#", "");
  const r = Math.max(0, parseInt(c.slice(0, 2), 16) - 60);
  const g = Math.max(0, parseInt(c.slice(2, 4), 16) - 60);
  const b = Math.max(0, parseInt(c.slice(4, 6), 16) - 60);
  return [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("").toUpperCase();
}
function isLight(hex: string): boolean {
  const c = hex.replace("#", "");
  if (c.length < 6) return false;
  const r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16);
  return (r * 0.299 + g * 0.587 + b * 0.114) > 200;
}
function hex2rgb(hex: string): { r: number; g: number; b: number } | null {
  const c = hex.replace("#", "");
  if (c.length < 6) return null;
  return { r: parseInt(c.slice(0, 2), 16), g: parseInt(c.slice(2, 4), 16), b: parseInt(c.slice(4, 6), 16) };
}
function rgb2cmyk(rgb: { r: number; g: number; b: number }): { c: number; m: number; y: number; k: number } | null {
  const r1 = rgb.r / 255, g1 = rgb.g / 255, b1 = rgb.b / 255;
  const k = 1 - Math.max(r1, g1, b1);
  if (k >= 1) return { c: 0, m: 0, y: 0, k: 100 };
  return { c: Math.round(((1 - r1 - k) / (1 - k)) * 100), m: Math.round(((1 - g1 - k) / (1 - k)) * 100), y: Math.round(((1 - b1 - k) / (1 - k)) * 100), k: Math.round(k * 100) };
}
function fta(bp: PageBlueprint, ids: string[]): string {
  for (const id of ids) { const el = bp.elements.find(e => e.id === id); if (el?.content) return el.content; }
  for (const id of ids) { const el = bp.elements.find(e => e.id?.includes(id)); if (el?.content) return el.content; }
  return "";
}
function extractPhilSections(bp: PageBlueprint): { label: string; content: string }[] {
  const pairs = [
    { ids: ["ph-vision-label","brand-vision-label"], cids: ["ph-vision-content","brand-vision-content","vision-content"], fallback: "\u54c1\u724c\u613f\u666f", keywords: ["\u613f\u666f","\u6253\u9020"] },
    { ids: ["ph-values-label","core-values-label"], cids: ["ph-values-content","core-values-content","values-content"], fallback: "\u6838\u5fc3\u4ef7\u503c", keywords: ["\u4ef7\u503c","\u6838\u5fc3"] },
    { ids: ["ph-market-label","target-market-label"], cids: ["ph-market-content","target-market-content","market-content"], fallback: "\u76ee\u6807\u5e02\u573a", keywords: ["\u5e02\u573a","\u76ee\u6807"] },
  ];
  return pairs.map(p => {
    const label = fta(bp, p.ids) || p.fallback;
    let content = fta(bp, p.cids);
    if (!content || content === "\u5f85\u5b9a") {
      for (const el of bp.elements) {
        if (el.type === "text" && el.content) {
          const cl = el.content.toLowerCase();
          if (p.keywords.some(kw => cl.includes(kw))) { content = el.content; break; }
        }
      }
    }
    return { label, content: content || "\u5f85\u5b9a" };
  });
}
