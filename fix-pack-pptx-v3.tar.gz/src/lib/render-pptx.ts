/**
 * PptxGenJS Renderer V2 — 专业级 VI 手册渲染
 *
 * V1 问题：
 * - 所有元素窄居中，大量留白
 * - 色块叠在一起
 * - Logo/IP 没加载
 * - 场景页空框
 *
 * V2 改进：
 * - 自定义每页布局，不复用 SVG 的小框居中逻辑
 * - 色块横排、文字满宽、Logo 居中放大
 * - 场景页用 PPTX 形状画 mockup
 * - 正确处理 marginLeft/marginRight 偏移
 */
import PptxGenJS from "pptxgenjs";
import type { PageBlueprint, PageElement, PageBackground } from "./page-planner";

// ========== 页面尺寸 (A4 竖版) ==========
const SW = 8.27;  // slide width in inches
const SH = 11.69; // slide height in inches
const MARGIN = 0.6; // page margin in inches
const CONTENT_W = SW - MARGIN * 2; // usable content width

export interface RenderPptxOptions {
  projectName?: string;
  companyName?: string;
  logoData?: string | null;
  mascotData?: string | null;
  mascotSplitViews?: string[] | null;
}

// ========== 主入口 ==========

export async function renderPptx(
  blueprints: PageBlueprint[],
  options: RenderPptxOptions = {}
): Promise<PptxGenJS> {
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: "A4_PORTRAIT", width: SW, height: SH });
  pptx.layout = "A4_PORTRAIT";
  pptx.author = "Brand Brain";
  pptx.subject = `${options.companyName || "\u54c1\u724c"} VI \u89c4\u8303\u624b\u518c`;
  pptx.title = `${options.companyName || "\u54c1\u724c"} \u54c1\u724c\u89c6\u89c9\u8bc6\u522b\u7cfb\u7edf\uff08VI\uff09\u89c4\u8303\u624b\u518c`;

  for (const bp of blueprints) {
    const slide = pptx.addSlide();
    renderSlide(slide, bp, options, blueprints.length);
  }

  return pptx;
}

export async function renderPptxToBuffer(
  blueprints: PageBlueprint[],
  options: RenderPptxOptions = {}
): Promise<Buffer> {
  const pptx = await renderPptx(blueprints, options);
  const base64 = await pptx.write({ outputType: "base64" }) as string;
  return Buffer.from(base64, "base64");
}

// ========== 页面渲染分发 ==========

function renderSlide(
  slide: PptxGenJS.Slide,
  bp: PageBlueprint,
  options: RenderPptxOptions,
  totalPages: number
): void {
  // 1. Background
  renderBg(slide, bp.background);

  // 2. Page-specific layout
  switch (bp.pageId) {
    case "cover":
      renderCover(slide, bp, options);
      break;
    case "closing":
      renderClosing(slide, bp, options);
      break;
    case "brand-philosophy":
      renderBrandPhilosophy(slide, bp, options);
      break;
    case "logo-interpretation":
      renderLogoInterpretation(slide, bp, options);
      break;
    case "brand-colors":
      renderBrandColors(slide, bp, options);
      break;
    case "typography":
      renderTypography(slide, bp, options);
      break;
    case "basic-spec":
      renderBasicSpec(slide, bp, options);
      break;
    case "stationery":
      renderScenePage(slide, bp, options, "stationery");
      break;
    case "packaging":
      renderScenePage(slide, bp, options, "packaging");
      break;
    case "marketing":
      renderScenePage(slide, bp, options, "marketing");
      break;
    case "summary":
      renderSummary(slide, bp, options);
      break;
    default:
      renderGenericPage(slide, bp, options);
  }

  // 3. Page number (except cover/closing)
  if (bp.pageId !== "cover" && bp.pageId !== "closing") {
    const idx = PAGE_ORDER.indexOf(bp.pageId);
    slide.addText(`${idx > 0 ? idx : ""}`, {
      x: SW - MARGIN - 0.5, y: SH - 0.5,
      w: 0.5, h: 0.3,
      fontSize: 7, color: "AAAAAA", align: "right",
    });
  }
}

const PAGE_ORDER = [
  "cover", "brand-philosophy", "logo-interpretation", "brand-colors",
  "typography", "basic-spec", "stationery", "packaging",
  "marketing", "summary", "closing",
];

// ========== Background ==========

function renderBg(slide: PptxGenJS.Slide, bg: PageBackground): void {
  const pri = hex(bg.primaryColor);
  if (bg.type === "gradient" && bg.secondaryColor) {
    const sec = hex(bg.secondaryColor);
    slide.background = {
      gradient: { type: "linear", stops: [{ position: 0, color: pri }, { position: 100, color: sec }], direction: "downRight" },
    };
  } else {
    slide.background = { fill: pri };
  }
}

// ========== Cover Page ==========

function renderCover(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const companyName = findText(bp, "cover-company-name") || opts.companyName || "\u54c1\u724c\u540d\u79f0";

  // Top accent bar
  slide.addShape("rect", {
    x: 0, y: 0, w: SW, h: 0.06,
    fill: { color: findAccentColor(bp) },
  });

  // Logo — large, centered, top area
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: (SW - 4.5) / 2, y: 1.2, w: 4.5, h: 2.2,
      sizing: { type: "contain", w: 4.5, h: 2.2 },
    });
  } else {
    slide.addShape("rect", {
      x: (SW - 3) / 2, y: 1.5, w: 3, h: 1.5,
      fill: { color: "FFFFFF" }, rectRadius: 0.1,
      line: { color: "CCCCCC", width: 0.5 },
    });
  }

  // Company name
  slide.addText(companyName, {
    x: MARGIN, y: 4.2, w: CONTENT_W, h: 0.8,
    fontSize: 36, bold: true, color: "FFFFFF", align: "center",
    fontFace: "Microsoft YaHei",
  });

  // Divider line
  const divColor = findAccentColor(bp);
  slide.addShape("line", {
    x: (SW - 2.5) / 2, y: 5.1, w: 2.5, h: 0,
    line: { color: divColor, width: 1.5 },
  });

  // Subtitle
  slide.addText("\u54c1\u724c\u89c6\u89c9\u8bc6\u522b\u7cfb\u7edf\uff08VI\uff09\u89c4\u8303\u624b\u518c", {
    x: MARGIN, y: 5.4, w: CONTENT_W, h: 0.5,
    fontSize: 18, bold: true, color: "FFFFFF", align: "center",
    transparency: 10,
  });

  slide.addText("VISUAL IDENTITY GUIDELINES", {
    x: MARGIN, y: 5.9, w: CONTENT_W, h: 0.35,
    fontSize: 12, color: "FFFFFF", align: "center",
    transparency: 30, charSpacing: 4,
  });

  // IP mascot — big, right side
  if (opts.mascotData) {
    slide.addImage({
      data: normImg(opts.mascotData),
      x: SW - 3.5, y: 4.5, w: 2.8, h: 3.2,
      sizing: { type: "contain", w: 2.8, h: 3.2 },
      transparency: 5,
    });
  }

  // Bottom info
  slide.addText("\u54c1\u724c\u7ba1\u7406\u90e8  \u00b7  v1.0  \u00b7  2026", {
    x: MARGIN, y: SH - 1.2, w: CONTENT_W, h: 0.3,
    fontSize: 11, color: "FFFFFF", align: "center", transparency: 30,
  });

  // Bottom accent bar
  slide.addShape("rect", {
    x: 0, y: SH - 0.08, w: SW, h: 0.08,
    fill: { color: findAccentColor(bp) },
  });
}

// ========== Closing Page ==========

function renderClosing(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const companyName = opts.companyName || "\u54c1\u724c\u540d\u79f0";

  slide.addText("\u611f\u8c22\u89c2\u770b", {
    x: MARGIN, y: SH / 2 - 1.5, w: CONTENT_W, h: 0.8,
    fontSize: 32, bold: true, color: "FFFFFF", align: "center",
  });

  slide.addText(`${companyName} \u00b7 \u54c1\u724c\u89c6\u89c9\u8bc6\u522b\u7cfb\u7edf (VI) \u89c4\u8303\u624b\u518c`, {
    x: MARGIN, y: SH / 2 - 0.5, w: CONTENT_W, h: 0.4,
    fontSize: 13, color: "FFFFFF", align: "center", transparency: 30,
  });

  if (opts.mascotData) {
    slide.addImage({
      data: normImg(opts.mascotData),
      x: (SW - 2) / 2, y: SH / 2 + 0.5, w: 2, h: 2.3,
      sizing: { type: "contain", w: 2, h: 2.3 },
      transparency: 20,
    });
  }

  slide.addText("\u5982\u6709\u7591\u95ee\uff0c\u8bf7\u54a8\u8be2\u54c1\u724c\u7ba1\u7406\u90e8", {
    x: MARGIN, y: SH - 1.5, w: CONTENT_W, h: 0.3,
    fontSize: 10, color: "FFFFFF", align: "center", transparency: 40,
  });

  slide.addShape("rect", {
    x: 0, y: SH - 0.08, w: SW, h: 0.08,
    fill: { color: findAccentColor(bp) },
  });
}

// ========== Brand Philosophy ==========

function renderBrandPhilosophy(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);

  // Page header
  addPageHeader(slide, "\u54c1\u724c\u6838\u5fc3\u7406\u5ff5", pri, acc);

  // Three sections stacked vertically with accent color bars
  const sections = extractPhilosophySections(bp);
  let yPos = 1.8;

  for (let i = 0; i < sections.length; i++) {
    const s = sections[i];

    // Accent color left bar
    slide.addShape("rect", {
      x: MARGIN, y: yPos, w: 0.06, h: 1.4,
      fill: { color: acc },
    });

    // Section label
    slide.addText(s.label, {
      x: MARGIN + 0.25, y: yPos, w: CONTENT_W - 0.25, h: 0.35,
      fontSize: 14, bold: true, color: pri,
    });

    // Section content
    slide.addText(s.content, {
      x: MARGIN + 0.25, y: yPos + 0.4, w: CONTENT_W - 0.25, h: 0.9,
      fontSize: 12, color: "444444", lineSpacingMultiple: 1.5,
      valign: "top",
    });

    yPos += 1.7;

    // Divider between sections
    if (i < sections.length - 1) {
      slide.addShape("line", {
        x: MARGIN, y: yPos - 0.15, w: CONTENT_W, h: 0,
        line: { color: "E0E0E0", width: 0.5 },
      });
    }
  }

  // Mascot decoration
  if (opts.mascotData) {
    slide.addImage({
      data: normImg(opts.mascotData),
      x: SW - 1.8, y: SH - 2.8, w: 1.4, h: 1.7,
      sizing: { type: "contain", w: 1.4, h: 1.7 },
      transparency: 40,
    });
  }
}

// ========== Logo Interpretation ==========

function renderLogoInterpretation(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);

  addPageHeader(slide, "\u6807\u8bc6\u8be0\u91ca", pri, acc);

  // Logo — large, centered
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: (SW - 3.5) / 2, y: 1.8, w: 3.5, h: 2.5,
      sizing: { type: "contain", w: 3.5, h: 2.5 },
    });
  } else {
    slide.addShape("rect", {
      x: (SW - 3) / 2, y: 2, w: 3, h: 2,
      fill: { color: "F5F5F5" }, rectRadius: 0.1,
      line: { color: "CCCCCC", width: 0.5, dashType: "dash" },
    });
    slide.addText("LOGO", {
      x: (SW - 3) / 2, y: 2, w: 3, h: 2,
      fontSize: 14, color: "AAAAAA", align: "center", valign: "middle",
    });
  }

  // Extract text content from blueprint
  const elementsText = findText(bp, "li-elements") || "";
  const meaningText = findText(bp, "li-meaning") || "";
  const styleTags = findText(bp, "li-styles") || "";

  let yPos = 4.8;

  if (elementsText) {
    slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.06, h: 0.8, fill: { color: acc } });
    slide.addText("\u8bbe\u8ba1\u5143\u7d20\u62c6\u89e3", {
      x: MARGIN + 0.25, y: yPos, w: CONTENT_W - 0.25, h: 0.3,
      fontSize: 12, bold: true, color: pri,
    });
    slide.addText(elementsText, {
      x: MARGIN + 0.25, y: yPos + 0.35, w: CONTENT_W - 0.25, h: 0.5,
      fontSize: 10, color: "555555", lineSpacingMultiple: 1.4,
    });
    yPos += 1.1;
  }

  if (meaningText) {
    slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.06, h: 0.8, fill: { color: acc } });
    slide.addText("\u8bbe\u8ba1\u542b\u4e49", {
      x: MARGIN + 0.25, y: yPos, w: CONTENT_W - 0.25, h: 0.3,
      fontSize: 12, bold: true, color: pri,
    });
    slide.addText(meaningText, {
      x: MARGIN + 0.25, y: yPos + 0.35, w: CONTENT_W - 0.25, h: 0.5,
      fontSize: 10, color: "555555", lineSpacingMultiple: 1.4,
    });
    yPos += 1.1;
  }

  if (styleTags) {
    slide.addText(styleTags, {
      x: MARGIN, y: yPos, w: CONTENT_W, h: 0.25,
      fontSize: 9, color: "888888", align: "center",
    });
  }

  // IP section
  const mascotName = findText(bp, "li-ip-name") || "";
  const mascotDesc = findText(bp, "li-ip-desc") || "";
  if (mascotName || (opts.mascotData)) {
    yPos = 7.5;
    slide.addShape("line", {
      x: MARGIN, y: yPos, w: CONTENT_W, h: 0,
      line: { color: "E0E0E0", width: 0.5 },
    });
    yPos += 0.3;

    slide.addText("IP \u89d2\u8272\u4ecb\u7ecd", {
      x: MARGIN, y: yPos, w: CONTENT_W, h: 0.3,
      fontSize: 12, bold: true, color: pri,
    });
    yPos += 0.35;

    if (opts.mascotData) {
      // Mascot on right, text on left
      slide.addImage({
        data: normImg(opts.mascotData),
        x: SW - MARGIN - 2, y: yPos, w: 1.8, h: 2,
        sizing: { type: "contain", w: 1.8, h: 2 },
      });

      const textW = CONTENT_W - 2.3;
      if (mascotName) {
        slide.addText(mascotName, {
          x: MARGIN, y: yPos, w: textW, h: 0.3,
          fontSize: 11, bold: true, color: "333333",
        });
      }
      if (mascotDesc) {
        slide.addText(mascotDesc, {
          x: MARGIN, y: yPos + 0.35, w: textW, h: 0.5,
          fontSize: 10, color: "555555", lineSpacingMultiple: 1.4,
        });
      }
    } else {
      if (mascotName) {
        slide.addText(mascotName, {
          x: MARGIN, y: yPos, w: CONTENT_W, h: 0.3,
          fontSize: 11, bold: true, color: "333333",
        });
      }
    }
  }
}

// ========== Brand Colors ==========

function renderBrandColors(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);

  addPageHeader(slide, "\u6807\u51c6\u8272\u5f69\u89c4\u8303", pri, acc);

  // Extract color swatches from blueprint
  const swatches = bp.elements.filter(e => e.type === "color-swatch");
  if (swatches.length === 0) return;

  // Layout: 3 swatches side by side
  const swatchW = (CONTENT_W - 0.4) / 3; // 3 columns with gaps
  const swatchH = 2.0;
  const colorBlockH = 1.3;
  let startX = MARGIN;

  for (let i = 0; i < swatches.length && i < 3; i++) {
    const sw = swatches[i];
    const x = startX + i * (swatchW + 0.2);
    const y = 2.0;
    const swatchHex = sw.color ? hex(sw.color) : "1A73E8";
    const label = sw.params?.label || "";
    const name = sw.params?.name || "";
    const hexVal = sw.color || "#000000";

    // Color block
    slide.addShape("rect", {
      x, y, w: swatchW, h: colorBlockH,
      fill: { color: swatchHex },
      rectRadius: 0.12,
    });

    // Label on color block
    const isDark = isDarkColor(swatchHex);
    slide.addText(label, {
      x, y, w: swatchW, h: colorBlockH,
      fontSize: 14, bold: true, color: isDark ? "FFFFFF" : "333333",
      align: "center", valign: "middle",
    });

    // Name below
    slide.addText(name, {
      x, y: y + colorBlockH + 0.1, w: swatchW, h: 0.25,
      fontSize: 10, color: "555555", align: "center",
    });

    // Hex value
    slide.addText(hexVal.toUpperCase(), {
      x, y: y + colorBlockH + 0.35, w: swatchW, h: 0.2,
      fontSize: 9, color: "888888", align: "center",
    });

    // RGB values
    const rgb = hexToRgb(hexVal);
    if (rgb) {
      slide.addText(`RGB: ${rgb.r}, ${rgb.g}, ${rgb.b}`, {
        x, y: y + colorBlockH + 0.55, w: swatchW, h: 0.2,
        fontSize: 8, color: "999999", align: "center",
      });
    }

    // CMYK values
    const cmyk = rgbToCmyk(rgb);
    if (cmyk) {
      slide.addText(`CMYK: ${cmyk.c}, ${cmyk.m}, ${cmyk.y}, ${cmyk.k}`, {
        x, y: y + colorBlockH + 0.75, w: swatchW, h: 0.2,
        fontSize: 8, color: "999999", align: "center",
      });
    }
  }

  // Color combination section
  const comboY = 5.5;
  slide.addText("\u8272\u5f69\u7ec4\u5408\u793a\u4f8b", {
    x: MARGIN, y: comboY, w: CONTENT_W, h: 0.35,
    fontSize: 13, bold: true, color: pri,
  });

  // Horizontal color bars showing combinations
  if (swatches.length >= 2) {
    const barY = comboY + 0.5;
    const barH = 0.6;
    // Primary + Secondary gradient bar
    slide.addShape("rect", {
      x: MARGIN, y: barY, w: CONTENT_W / 2 - 0.1, h: barH,
      fill: { color: hex(swatches[0].color || "#1A73E8") },
    });
    slide.addShape("rect", {
      x: MARGIN + CONTENT_W / 2, y: barY, w: CONTENT_W / 2, h: barH,
      fill: { color: hex(swatches[1].color || "#34A853") },
    });
    slide.addText("\u4e3b\u8272 + \u8f85\u52a9\u8272", {
      x: MARGIN, y: barY + barH + 0.05, w: CONTENT_W, h: 0.2,
      fontSize: 8, color: "888888", align: "center",
    });

    // Accent strip
    const bar2Y = barY + 1.2;
    slide.addShape("rect", {
      x: MARGIN, y: bar2Y, w: CONTENT_W * 0.7, h: barH,
      fill: { color: "FFFFFF" }, line: { color: "E0E0E0", width: 0.5 },
    });
    slide.addShape("rect", {
      x: MARGIN + CONTENT_W * 0.7, y: bar2Y, w: CONTENT_W * 0.3, h: barH,
      fill: { color: hex(swatches[2]?.color || "#FBBC04") },
    });
    slide.addText("\u767d\u5e95 + \u5f3a\u8c03\u8272\u70b9\u7f00", {
      x: MARGIN, y: bar2Y + barH + 0.05, w: CONTENT_W, h: 0.2,
      fontSize: 8, color: "888888", align: "center",
    });
  }
}

// ========== Typography ==========

function renderTypography(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);

  addPageHeader(slide, "\u5b57\u4f53\u7cfb\u7edf", pri, acc);

  let yPos = 1.8;

  // Chinese fonts
  slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.06, h: 1.2, fill: { color: acc } });
  slide.addText("\u4e2d\u6587\u5b57\u4f53", {
    x: MARGIN + 0.25, y: yPos, w: CONTENT_W - 0.25, h: 0.3,
    fontSize: 14, bold: true, color: pri,
  });
  slide.addText([
    { text: "\u54c1\u724c\u5b57\u4f53\uff1a", options: { bold: true, fontSize: 11 } },
    { text: "\u601d\u6e90\u9ed1\u4f53 / Noto Sans SC", options: { fontSize: 11 } },
  ], {
    x: MARGIN + 0.25, y: yPos + 0.4, w: CONTENT_W - 0.25, h: 0.3,
    color: "444444",
  });
  slide.addText([
    { text: "\u6b63\u6587\u5b57\u4f53\uff1a", options: { bold: true, fontSize: 11 } },
    { text: "\u601d\u6e90\u5b8b\u4f53 / Noto Serif SC", options: { fontSize: 11 } },
  ], {
    x: MARGIN + 0.25, y: yPos + 0.7, w: CONTENT_W - 0.25, h: 0.3,
    color: "444444",
  });

  // Font demo
  slide.addText("AaBbCc \u4f60\u597d\u4e16\u754c 0123", {
    x: MARGIN + 0.25, y: yPos + 1.05, w: CONTENT_W - 0.25, h: 0.35,
    fontSize: 20, color: pri, fontFace: "Microsoft YaHei",
  });

  yPos += 2.0;

  // English fonts
  slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.06, h: 1.2, fill: { color: acc } });
  slide.addText("\u82f1\u6587\u5b57\u4f53", {
    x: MARGIN + 0.25, y: yPos, w: CONTENT_W - 0.25, h: 0.3,
    fontSize: 14, bold: true, color: pri,
  });
  slide.addText([
    { text: "Brand Font: ", options: { bold: true, fontSize: 11 } },
    { text: "Montserrat", options: { fontSize: 11 } },
  ], {
    x: MARGIN + 0.25, y: yPos + 0.4, w: CONTENT_W - 0.25, h: 0.3,
    color: "444444",
  });
  slide.addText([
    { text: "Body Font: ", options: { bold: true, fontSize: 11 } },
    { text: "Open Sans", options: { fontSize: 11 } },
  ], {
    x: MARGIN + 0.25, y: yPos + 0.7, w: CONTENT_W - 0.25, h: 0.3,
    color: "444444",
  });
  slide.addText("AaBbCc The Quick Brown Fox 0123", {
    x: MARGIN + 0.25, y: yPos + 1.05, w: CONTENT_W - 0.25, h: 0.35,
    fontSize: 20, color: pri, fontFace: "Arial",
  });

  yPos += 2.0;

  // Hierarchy table
  slide.addText("\u5b57\u53f7\u5c42\u7ea7\u89c4\u8303", {
    x: MARGIN, y: yPos, w: CONTENT_W, h: 0.3,
    fontSize: 13, bold: true, color: pri,
  });
  yPos += 0.4;

  const tableRows = [
    [
      { text: "\u5c42\u7ea7", options: { bold: true, fontSize: 9, fill: { color: "F5F5F5" } } },
      { text: "\u5b57\u53f7", options: { bold: true, fontSize: 9, fill: { color: "F5F5F5" } } },
      { text: "\u5b57\u91cd", options: { bold: true, fontSize: 9, fill: { color: "F5F5F5" } } },
      { text: "\u7528\u9014", options: { bold: true, fontSize: 9, fill: { color: "F5F5F5" } } },
    ],
    ["H1 / \u6807\u9898", "24pt", "Bold 700", "\u9875\u9762\u4e3b\u6807\u9898"],
    ["H2 / \u526f\u6807\u9898", "16pt", "Medium 500", "\u6bb5\u843d\u6807\u9898"],
    ["\u6b63\u6587", "12pt", "Regular 400", "\u6b63\u6587\u5185\u5bb9"],
    ["\u8bf4\u660e", "10pt", "Light 300", "\u6ce8\u91ca\u8bf4\u660e"],
  ];

  slide.addTable(tableRows, {
    x: MARGIN, y: yPos, w: CONTENT_W,
    colW: [CONTENT_W * 0.25, CONTENT_W * 0.2, CONTENT_W * 0.25, CONTENT_W * 0.3],
    border: { type: "solid", pt: 0.5, color: "E0E0E0" },
    fontSize: 9, color: "444444",
    rowH: [0.3, 0.28, 0.28, 0.28, 0.28],
  });
}

// ========== Basic Spec ==========

function renderBasicSpec(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);

  addPageHeader(slide, "\u57fa\u7840\u89c4\u8303", pri, acc);

  // Logo with clear space
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: (SW - 3) / 2, y: 2.0, w: 3, h: 2.5,
      sizing: { type: "contain", w: 3, h: 2.5 },
    });

    // Clear space indicator (dashed border)
    slide.addShape("rect", {
      x: (SW - 4) / 2, y: 1.5, w: 4, h: 3.5,
      line: { color: acc, width: 0.5, dashType: "dash" },
      rectRadius: 0.05,
    });

    slide.addText("LOGO \u56db\u5468\u4fdd\u7559\u81f3\u5c11 15% \u4fdd\u62a4\u7a7a\u95f4\uff0c\u4e0d\u53ef\u88ab\u4efb\u4f55\u5143\u7d20\u906e\u6321\u6216\u88c1\u5207", {
      x: MARGIN, y: 5.3, w: CONTENT_W, h: 0.4,
      fontSize: 11, color: "555555", align: "center",
    });
  }

  // Minimum sizes table
  const yPos = 6.5;
  slide.addText("\u6700\u5c0f\u5c3a\u5bf8\u89c4\u8303", {
    x: MARGIN, y: yPos, w: CONTENT_W, h: 0.3,
    fontSize: 13, bold: true, color: pri,
  });

  slide.addTable([
    [
      { text: "\u573a\u666f", options: { bold: true, fontSize: 10, fill: { color: "F5F5F5" } } },
      { text: "\u6700\u5c0f\u5c3a\u5bf8", options: { bold: true, fontSize: 10, fill: { color: "F5F5F5" } } },
    ],
    ["\u5370\u5237", "8mm (0.31 in)"],
    ["\u5c4f\u5e55", "24px"],
  ], {
    x: MARGIN + 1, y: yPos + 0.4, w: CONTENT_W - 2,
    colW: [(CONTENT_W - 2) * 0.5, (CONTENT_W - 2) * 0.5],
    border: { type: "solid", pt: 0.5, color: "E0E0E0" },
    fontSize: 10, color: "444444",
  });
}

// ========== Scene Pages (stationery/packaging/marketing) ==========

function renderScenePage(
  slide: PptxGenJS.Slide,
  bp: PageBlueprint,
  opts: RenderPptxOptions,
  sceneType: string
): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);
  const label = bp.label;

  addPageHeader(slide, label, pri, acc);

  // Description text
  const descEl = bp.elements.find(e => e.type === "text" && e.id?.includes("desc"));
  if (descEl?.content) {
    slide.addText(descEl.content, {
      x: MARGIN, y: 1.8, w: CONTENT_W, h: 0.5,
      fontSize: 11, color: "666666", lineSpacingMultiple: 1.5,
    });
  }

  // Mockup shapes based on scene type
  const mockupY = 2.8;

  switch (sceneType) {
    case "stationery":
      renderStationeryMockup(slide, pri, acc, mockupY, opts);
      break;
    case "packaging":
      renderPackagingMockup(slide, pri, acc, mockupY, opts);
      break;
    case "marketing":
      renderMarketingMockup(slide, pri, acc, mockupY, opts);
      break;
  }
}

function renderStationeryMockup(
  slide: PptxGenJS.Slide,
  pri: string, acc: string,
  startY: number, opts: RenderPptxOptions
): void {
  // Business card mockup
  const cardW = 3.5, cardH = 2.0;
  const cardX = (SW - cardW) / 2;
  slide.addShape("rect", {
    x: cardX, y: startY, w: cardW, h: cardH,
    fill: { color: "FFFFFF" },
    line: { color: "E0E0E0", width: 0.5 },
    rectRadius: 0.05,
    shadow: { type: "outer", blur: 3, offset: 2, color: "000000", opacity: 0.1 },
  });
  // Brand color bar on card
  slide.addShape("rect", {
    x: cardX, y: startY, w: 0.12, h: cardH,
    fill: { color: pri }, rectRadius: 0.05,
  });
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: cardX + 0.3, y: startY + 0.2, w: 1.2, h: 0.6,
      sizing: { type: "contain", w: 1.2, h: 0.6 },
    });
  }
  slide.addText("\u59d3\u540d / \u804c\u4f4d\n\u8054\u7cfb\u65b9\u5f0f", {
    x: cardX + 0.3, y: startY + 1.0, w: 2.5, h: 0.7,
    fontSize: 8, color: "888888", lineSpacingMultiple: 1.3,
  });
  slide.addText("\u540d\u7247", {
    x: cardX, y: startY + cardH + 0.1, w: cardW, h: 0.2,
    fontSize: 8, color: "AAAAAA", align: "center",
  });

  // Envelope mockup
  const envY = startY + cardH + 0.8;
  const envW = 4.0, envH = 2.5;
  const envX = (SW - envW) / 2;
  slide.addShape("rect", {
    x: envX, y: envY, w: envW, h: envH,
    fill: { color: "FFFFFF" },
    line: { color: "E0E0E0", width: 0.5 },
    rectRadius: 0.05,
    shadow: { type: "outer", blur: 3, offset: 2, color: "000000", opacity: 0.1 },
  });
  // Color stripe on envelope
  slide.addShape("rect", {
    x: envX, y: envY, w: envW, h: 0.15,
    fill: { color: pri }, rectRadius: 0.05,
  });
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: envX + envW - 1.3, y: envY + 0.4, w: 0.9, h: 0.5,
      sizing: { type: "contain", w: 0.9, h: 0.5 },
    });
  }
  slide.addText("\u4fe1\u5c01", {
    x: envX, y: envY + envH + 0.1, w: envW, h: 0.2,
    fontSize: 8, color: "AAAAAA", align: "center",
  });

  // Letterhead hint
  const lhY = envY + envH + 0.7;
  slide.addShape("rect", {
    x: (SW - 3.5) / 2, y: lhY, w: 3.5, h: 1.0,
    fill: { color: "FFFFFF" },
    line: { color: "E0E0E0", width: 0.5 },
    rectRadius: 0.05,
  });
  slide.addShape("rect", {
    x: (SW - 3.5) / 2, y: lhY, w: 3.5, h: 0.08,
    fill: { color: pri },
  });
  slide.addText("\u4fe1\u7eb8 / \u62a5\u4fe1\u7eb8", {
    x: (SW - 3.5) / 2, y: lhY + 0.3, w: 3.5, h: 0.5,
    fontSize: 8, color: "CCCCCC", align: "center", valign: "middle",
  });
}

function renderPackagingMockup(
  slide: PptxGenJS.Slide,
  pri: string, acc: string,
  startY: number, opts: RenderPptxOptions
): void {
  // Box mockup
  const boxW = 3.0, boxH = 3.5;
  const boxX = (SW - boxW) / 2;
  slide.addShape("rect", {
    x: boxX, y: startY, w: boxW, h: boxH,
    fill: { color: "FFFFFF" },
    line: { color: "E0E0E0", width: 0.5 },
    rectRadius: 0.05,
    shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.12 },
  });
  // Brand color band
  slide.addShape("rect", {
    x: boxX, y: startY + boxH * 0.3, w: boxW, h: boxH * 0.3,
    fill: { color: pri },
  });
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: boxX + 0.5, y: startY + boxH * 0.3 + 0.2, w: 2.0, h: 1.0,
      sizing: { type: "contain", w: 2.0, h: 1.0 },
    });
  }
  slide.addText("\u4ea7\u54c1\u5305\u88c5\u76d2", {
    x: boxX, y: startY + boxH + 0.1, w: boxW, h: 0.2,
    fontSize: 8, color: "AAAAAA", align: "center",
  });

  // Bag mockup
  const bagY = startY + boxH + 1.0;
  const bagW = 2.5, bagH = 3.0;
  const bagX = (SW - bagW) / 2;
  slide.addShape("rect", {
    x: bagX, y: bagY, w: bagW, h: bagH,
    fill: { color: pri },
    line: { color: "E0E0E0", width: 0.5 },
    rectRadius: 0.05,
    shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.12 },
  });
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: bagX + 0.4, y: bagY + 0.5, w: 1.7, h: 1.2,
      sizing: { type: "contain", w: 1.7, h: 1.2 },
    });
  }
  slide.addText("\u624b\u63d0\u888b / \u5916\u5356\u888b", {
    x: bagX, y: bagY + bagH + 0.1, w: bagW, h: 0.2,
    fontSize: 8, color: "AAAAAA", align: "center",
  });
}

function renderMarketingMockup(
  slide: PptxGenJS.Slide,
  pri: string, acc: string,
  startY: number, opts: RenderPptxOptions
): void {
  // Poster mockup
  const posterW = 3.5, posterH = 5.0;
  const posterX = (SW - posterW) / 2;
  slide.addShape("rect", {
    x: posterX, y: startY, w: posterW, h: posterH,
    fill: { color: "FFFFFF" },
    line: { color: "E0E0E0", width: 0.5 },
    rectRadius: 0.05,
    shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.12 },
  });
  // Color gradient area
  slide.addShape("rect", {
    x: posterX, y: startY, w: posterW, h: posterH * 0.5,
    fill: { color: pri },
    rectRadius: 0.05,
  });
  if (opts.logoData) {
    slide.addImage({
      data: normImg(opts.logoData),
      x: posterX + 0.8, y: startY + 0.5, w: 1.9, h: 1.2,
      sizing: { type: "contain", w: 1.9, h: 1.2 },
    });
  }
  // Placeholder text lines
  slide.addText("\u54c1\u724c\u4e3b\u6807\u9898", {
    x: posterX + 0.3, y: startY + posterH * 0.5 + 0.3, w: posterW - 0.6, h: 0.4,
    fontSize: 12, bold: true, color: "333333",
  });
  slide.addText("\u526f\u6807\u9898\u6587\u5b57\u8bf4\u660e", {
    x: posterX + 0.3, y: startY + posterH * 0.5 + 0.8, w: posterW - 0.6, h: 0.3,
    fontSize: 9, color: "888888",
  });
  slide.addText("\u6d77\u62a5 / \u5ba3\u4f20\u9875", {
    x: posterX, y: startY + posterH + 0.1, w: posterW, h: 0.2,
    fontSize: 8, color: "AAAAAA", align: "center",
  });
}

// ========== Summary ==========

function renderSummary(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  const acc = findAccentColor(bp);
  const companyName = opts.companyName || "\u54c1\u724c";

  addPageHeader(slide, "\u603b\u7ed3", pri, acc);

  // Vision statement
  const visionEl = bp.elements.find(e => e.id === "ph-vision-content");
  const visionText = visionEl?.content || "";

  if (visionText) {
    slide.addText(`\u201c${visionText}\u201d`, {
      x: MARGIN + 0.3, y: 2.0, w: CONTENT_W - 0.6, h: 1.0,
      fontSize: 13, italic: true, color: pri, align: "center",
      lineSpacingMultiple: 1.5,
    });
  }

  // Three pillars
  const pillars = [
    { label: "\u4e00\u81f4\u6027", desc: "\u6240\u6709\u5a92\u4ecb\u8f93\u51fa\u5fc5\u987b\u4e25\u683c\u9075\u5b88\u672c\u624b\u518c\u89c4\u8303\uff0c\u786e\u4fdd\u54c1\u724c\u5728\u4efb\u4f55\u89e6\u70b9\u4e0b\u90fd\u80fd\u88ab\u7cbe\u51c6\u8bc6\u522b" },
    { label: "\u4e13\u4e1a\u6027", desc: "\u901a\u8fc7\u6807\u51c6\u5316\u7684\u89c6\u89c9\u8bed\u8a00\u5efa\u7acb\u5ba2\u6237\u4fe1\u4efb\uff0c\u5c55\u73b0\u54c1\u724c\u4f5c\u4e3a\u884c\u4e1a\u4e13\u5bb6\u7684\u4e13\u4e1a\u5f62\u8c61" },
    { label: "\u6301\u7eed\u6027", desc: "VI \u7cfb\u7edf\u662f\u54c1\u724c\u957f\u671f\u53d1\u5c55\u7684\u6838\u5fc3\u65e0\u5f62\u8d44\u4ea7\uff0c\u662f\u54c1\u724c\u4ef7\u503c\u6301\u7eed\u79ef\u7d2f\u7684\u89c6\u89c9\u8f7d\u4f53" },
  ];

  let yPos = 3.5;
  for (let i = 0; i < pillars.length; i++) {
    const p = pillars[i];
    // Number circle
    slide.addShape("ellipse", {
      x: MARGIN + 0.2, y: yPos, w: 0.4, h: 0.4,
      fill: { color: pri },
    });
    slide.addText(`${i + 1}`, {
      x: MARGIN + 0.2, y: yPos, w: 0.4, h: 0.4,
      fontSize: 12, bold: true, color: "FFFFFF", align: "center", valign: "middle",
    });
    // Pillar label
    slide.addText(p.label, {
      x: MARGIN + 0.8, y: yPos, w: 2, h: 0.35,
      fontSize: 13, bold: true, color: pri,
    });
    // Pillar description
    slide.addText(p.desc, {
      x: MARGIN + 0.8, y: yPos + 0.4, w: CONTENT_W - 1, h: 0.6,
      fontSize: 10, color: "555555", lineSpacingMultiple: 1.4,
    });
    yPos += 1.3;
  }

  // Core values footer
  const coreValues = findText(bp, "ph-values-content") || "";
  if (coreValues) {
    slide.addText(`\u6838\u5fc3\u4ef7\u503c\uff1a${coreValues}`, {
      x: MARGIN, y: SH - 1.8, w: CONTENT_W, h: 0.3,
      fontSize: 10, color: pri, align: "center", bold: true,
    });
  }
}

// ========== Generic Page Fallback ==========

function renderGenericPage(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions): void {
  const pri = findPrimaryColor(bp);
  addPageHeader(slide, bp.label, pri, findAccentColor(bp));

  // Render all elements with improved layout
  let yPos = 1.8;
  for (const el of bp.elements) {
    if (el.type === "text" && el.content) {
      const fontSize = el.fontSize ? Math.max(8, Math.round(el.fontSize * 0.6)) : 11;
      const isBold = (el.fontWeight || 400) >= 600;
      slide.addText(el.content, {
        x: MARGIN, y: yPos, w: CONTENT_W, h: 0.4,
        fontSize, bold: isBold, color: el.color ? hex(el.color) : "333333",
        align: (el.params?.align === "left") ? "left" : "center",
      });
      yPos += 0.5;
    }
  }
}

// ========== Page Header Component ==========

function addPageHeader(slide: PptxGenJS.Slide, title: string, pri: string, acc: string): void {
  // Top accent bar
  slide.addShape("rect", {
    x: 0, y: 0, w: SW, h: 0.05,
    fill: { color: acc },
  });

  // Title
  slide.addText(title, {
    x: MARGIN, y: 0.4, w: CONTENT_W, h: 0.5,
    fontSize: 20, bold: true, color: pri,
  });

  // Title underline
  slide.addShape("rect", {
    x: MARGIN, y: 0.95, w: 1.5, h: 0.04,
    fill: { color: acc },
  });

  // Company name top-right
  slide.addText("", {
    x: SW - MARGIN - 2, y: 0.45, w: 2, h: 0.3,
    fontSize: 8, color: "AAAAAA", align: "right",
  });
}

// ========== Helpers ==========

function hex(color: string): string {
  return color.replace("#", "").toUpperCase();
}

function isDarkColor(colorHex: string): boolean {
  const c = colorHex.replace("#", "");
  if (c.length < 6) return false;
  const r = parseInt(c.slice(0, 2), 16);
  const g = parseInt(c.slice(2, 4), 16);
  const b = parseInt(c.slice(4, 6), 16);
  return (r * 0.299 + g * 0.587 + b * 0.114) < 140;
}

function hexToRgb(colorHex: string): { r: number; g: number; b: number } | null {
  const c = colorHex.replace("#", "");
  if (c.length < 6) return null;
  return {
    r: parseInt(c.slice(0, 2), 16),
    g: parseInt(c.slice(2, 4), 16),
    b: parseInt(c.slice(4, 6), 16),
  };
}

function rgbToCmyk(rgb: { r: number; g: number; b: number } | null): { c: number; m: number; y: number; k: number } | null {
  if (!rgb) return null;
  const r1 = rgb.r / 255, g1 = rgb.g / 255, b1 = rgb.b / 255;
  const k = 1 - Math.max(r1, g1, b1);
  if (k >= 1) return { c: 0, m: 0, y: 0, k: 100 };
  const c = Math.round(((1 - r1 - k) / (1 - k)) * 100);
  const m = Math.round(((1 - g1 - k) / (1 - k)) * 100);
  const y = Math.round(((1 - b1 - k) / (1 - k)) * 100);
  return { c, m, y, k: Math.round(k * 100) };
}

function normImg(data: string): string {
  if (data.startsWith("data:")) return data;
  if (/^[A-Za-z0-9+/=]+$/.test(data)) return `data:image/png;base64,${data}`;
  return data;
}

function findText(bp: PageBlueprint, id: string): string {
  const el = bp.elements.find(e => e.id === id);
  return el?.content || "";
}

function findPrimaryColor(bp: PageBlueprint): string {
  return hex(bp.background.primaryColor || "#1A73E8");
}

function findAccentColor(bp: PageBlueprint): string {
  return hex(bp.background.secondaryColor || "#FBBC04");
}

interface PhilSection { label: string; content: string; }

function extractPhilosophySections(bp: PageBlueprint): PhilSection[] {
  const sections: PhilSection[] = [];
  const visionContent = findText(bp, "ph-vision-content");
  const valuesContent = findText(bp, "ph-values-content");
  const marketContent = findText(bp, "ph-market-content");

  if (visionContent) sections.push({ label: "\u54c1\u724c\u613f\u666f", content: visionContent });
  if (valuesContent) sections.push({ label: "\u6838\u5fc3\u4ef7\u503c", content: valuesContent });
  if (marketContent) sections.push({ label: "\u76ee\u6807\u5e02\u573a", content: marketContent });

  if (sections.length === 0) {
    // Fallback: extract from text elements
    const textEls = bp.elements.filter(e => e.type === "text" && e.content && e.id?.startsWith("ph-"));
    for (const el of textEls) {
      if (el.id?.includes("label")) {
        const contentId = el.id.replace("-label", "-content");
        const content = findText(bp, contentId);
        if (content) sections.push({ label: el.content, content });
      }
    }
  }

  return sections.length > 0 ? sections : [
    { label: "\u54c1\u724c\u613f\u666f", content: "\u5f85\u5b9a" },
    { label: "\u6838\u5fc3\u4ef7\u503c", content: "\u5f85\u5b9a" },
    { label: "\u76ee\u6807\u5e02\u573a", content: "\u5f85\u5b9a" },
  ];
}
