/**
 * API: Generate VI Manual PPTX via PptxGenJS Engine V3
 *
 * V3 fixes:
 * - Correctly read logo/mascot from project processed assets (not submission URLs)
 * - Handle brandColors format from submission ({ primary: "#xxx" } vs { primary: { hex: "#xxx" } })
 * - Fix AILayoutPlanner port issue (use internal URL)
 * - Save generated PPTX to project's generated-manuals list
 * - Better company name extraction
 */
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { readFile, mkdir, writeFile, readdir, stat, access } from "fs/promises";
import { planPages } from "@/lib/page-planner";
import { renderPptxToBuffer } from "@/lib/render-pptx";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { projectId, clientInfo, brandColors, logoUrl, mascotUrl, mascotFiles } = body;

    if (!projectId) {
      return NextResponse.json({ error: "projectId required" }, { status: 400 });
    }

    const companyName = clientInfo?.companyName || clientInfo?.clientName || "";

    // Step 1: Load logo/mascot as base64 data URIs
    // Try multiple sources: direct URL, processed-assets directory, submission assets
    let logoData: string | null = null;
    let mascotData: string | null = null;
    let mascotSplitViews: string[] | null = null;

    // Load logo
    if (logoUrl) {
      logoData = await loadImageAsBase64(logoUrl);
    }
    // If logo not found from URL, try processed-assets directory
    if (!logoData) {
      logoData = await findProcessedAsset(projectId, "logo");
    }

    // Load mascot
    if (mascotUrl) {
      mascotData = await loadImageAsBase64(mascotUrl);
    }
    if (!mascotData && mascotFiles && mascotFiles.length > 0) {
      // Try first mascot file
      for (const mf of mascotFiles) {
        const url = mf.url || mf;
        mascotData = await loadImageAsBase64(url);
        if (mascotData) break;
      }
    }
    if (!mascotData) {
      mascotData = await findProcessedAsset(projectId, "mascot");
    }

    // Load mascot split views
    if (mascotData) {
      mascotSplitViews = await findMascotSplitViews(projectId);
    }

    console.log("[generate-pptx] Company name:", companyName || "(empty)");
    console.log("[generate-pptx] Logo data:", logoData ? `OK (${Math.round(logoData.length / 1024)}KB)` : "null");
    console.log("[generate-pptx] Mascot data:", mascotData ? `OK (${Math.round(mascotData.length / 1024)}KB)` : "null");

    // Step 2: Normalize brandColors — submission uses { primary: "#xxx" }, planner needs { primary: { hex: "#xxx" } }
    const normalizedColors = normalizeBrandColors(brandColors, clientInfo?.industry);

    // Step 3: Generate Page Blueprints
    const blueprints = await planPages({
      clientInfo: {
        companyName: companyName || "\u54c1\u724c",
        brandVision: clientInfo?.brandVision || "",
        coreValues: clientInfo?.coreValues || "",
        targetMarket: clientInfo?.targetMarket || "",
        logoPhilosophy: clientInfo?.logoPhilosophy || "",
        mascotPhilosophy: clientInfo?.mascotPhilosophy || "",
        industry: clientInfo?.industry || "",
      },
      brandColors: normalizedColors,
      assetAnalysis: {
        logo: {
          hasLogo: !!logoData,
          logoUrl: logoUrl || "",
          elements: [],
          styleTags: [],
          meaning: clientInfo?.logoPhilosophy || "",
        },
        mascot: {
          hasMascot: !!mascotData,
          mascotUrl: mascotUrl || "",
          isThreeView: !!(mascotSplitViews && mascotSplitViews.length === 3),
          splitViews: mascotSplitViews || [],
          name: "",
          style: "",
          personality: "",
        },
      },
    });

    console.log("[generate-pptx] Blueprints generated:", blueprints.length, "pages");

    // Step 4: Render PPTX
    const buffer = await renderPptxToBuffer(blueprints, {
      projectName: projectId,
      companyName: companyName || "\u54c1\u724c",
      logoData,
      mascotData,
      mascotSplitViews,
    });

    // Step 5: Save file
    const outputDir = path.join(process.cwd(), "public", "generated");
    await mkdir(outputDir, { recursive: true });
    const fileName = `vi-manual-${projectId}-${Date.now()}.pptx`;
    const filePath = path.join(outputDir, fileName);
    await writeFile(filePath, buffer);

    // Step 6: Save to generated-manuals index
    await saveToGeneratedIndex(projectId, {
      id: `pptx-${Date.now()}`,
      fileName,
      filePath: `/generated/${fileName}`,
      pageCount: blueprints.length,
      generatedAt: new Date().toISOString(),
      type: "pptx",
      engine: "pptxgenjs",
    });

    const downloadUrl = `/generated/${fileName}`;

    return NextResponse.json({
      success: true,
      url: downloadUrl,
      pageCount: blueprints.length,
      fileName,
    });
  } catch (error: any) {
    console.error("[generate-pptx] Error:", error);
    return NextResponse.json(
      { error: error.message || "PPTX generation failed" },
      { status: 500 }
    );
  }
}

// ========== Helpers ==========

/** Normalize brandColors from various formats */
function normalizeBrandColors(
  colors: any,
  industry?: string
): { primary: { hex: string }; secondary: { hex: string }; accent: { hex: string } } {
  // Default colors
  const defaultColors = {
    primary: { hex: "#1A73E8" },
    secondary: { hex: "#34A853" },
    accent: { hex: "#FBBC04" },
  };

  if (!colors) return defaultColors;

  // Format 1: { primary: { hex: "#xxx" }, ... } — already correct
  if (colors.primary?.hex) {
    return {
      primary: { hex: colors.primary.hex },
      secondary: { hex: colors.secondary?.hex || defaultColors.secondary.hex },
      accent: { hex: colors.accent?.hex || defaultColors.accent.hex },
    };
  }

  // Format 2: { primary: "#xxx", ... } — from Submission
  if (typeof colors.primary === "string") {
    return {
      primary: { hex: colors.primary },
      secondary: { hex: typeof colors.secondary === "string" ? colors.secondary : defaultColors.secondary.hex },
      accent: { hex: typeof colors.accent === "string" ? colors.accent : defaultColors.accent.hex },
    };
  }

  return defaultColors;
}

/** Load image from local file path or HTTP URL as base64 data URI */
async function loadImageAsBase64(imagePath: string): Promise<string | null> {
  if (!imagePath) return null;
  try {
    // Try local file paths
    const candidates = [
      path.join(process.cwd(), "public", imagePath.replace(/^\//, "")),
      path.join(process.cwd(), imagePath),
    ];

    for (const fullPath of candidates) {
      try {
        const buffer = await readFile(fullPath);
        const ext = path.extname(fullPath).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg"
          ? "image/jpeg"
          : ext === ".gif"
          ? "image/gif"
          : ext === ".svg"
          ? "image/svg+xml"
          : "image/png";
        const dataUri = `data:${mime};base64,${buffer.toString("base64")}`;
        console.log(`[loadImage] Success: ${fullPath} (${buffer.length} bytes)`);
        return dataUri;
      } catch {
        // Try next candidate
      }
    }

    // If it's already a URL (http/https), try to fetch it
    if (imagePath.startsWith("http")) {
      try {
        const resp = await fetch(imagePath);
        if (resp.ok) {
          const buffer = Buffer.from(await resp.arrayBuffer());
          const contentType = resp.headers.get("content-type") || "image/png";
          return `data:${contentType};base64,${buffer.toString("base64")}`;
        }
      } catch {
        // fetch failed
      }
    }

    console.warn("[loadImage] All paths failed for:", imagePath);
    return null;
  } catch (e) {
    console.warn("[loadImage] Error:", String(e));
    return null;
  }
}

/** Find processed asset (logo/mascot) in project's processed-assets directory */
async function findProcessedAsset(projectId: string, type: "logo" | "mascot"): Promise<string | null> {
  try {
    const processedDir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(processedDir);
    
    for (const file of files) {
      const lowerFile = file.toLowerCase();
      if (type === "logo" && (lowerFile.includes("logo") || lowerFile.includes("logo-processed"))) {
        const fullPath = path.join(processedDir, file);
        const buffer = await readFile(fullPath);
        const ext = path.extname(file).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        console.log(`[findProcessedAsset] Found ${type}: ${file} (${buffer.length} bytes)`);
        return `data:${mime};base64,${buffer.toString("base64")}`;
      }
      if (type === "mascot" && (lowerFile.includes("mascot") || lowerFile.includes("ip") || lowerFile.includes("character"))) {
        const fullPath = path.join(processedDir, file);
        const buffer = await readFile(fullPath);
        const ext = path.extname(file).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        console.log(`[findProcessedAsset] Found ${type}: ${file} (${buffer.length} bytes)`);
        return `data:${mime};base64,${buffer.toString("base64")}`;
      }
    }

    // Also try direct file names
    const directNames = type === "logo"
      ? ["logo.png", "logo.jpg", "logo.svg", "logo-processed.png"]
      : ["mascot.png", "mascot.jpg", "ip.png", "character.png", "mascot-front.png"];
    
    for (const name of directNames) {
      try {
        const fullPath = path.join(processedDir, name);
        const buffer = await readFile(fullPath);
        const ext = path.extname(name).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        console.log(`[findProcessedAsset] Found direct ${type}: ${name} (${buffer.length} bytes)`);
        return `data:${mime};base64,${buffer.toString("base64")}`;
      } catch {
        // Not found, try next
      }
    }

    console.log(`[findProcessedAsset] No ${type} found for project ${projectId}`);
    return null;
  } catch {
    // Directory not found or not accessible
    return null;
  }
}

/** Find mascot split views (front/side/back) */
async function findMascotSplitViews(projectId: string): Promise<string[] | null> {
  try {
    const processedDir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(processedDir);
    const views: string[] = [];
    
    for (const suffix of ["-front", "-side", "-back"]) {
      for (const file of files) {
        if (file.toLowerCase().includes(`mascot${suffix}`) || file.toLowerCase().includes(`ip${suffix}`)) {
          const fullPath = path.join(processedDir, file);
          const buffer = await readFile(fullPath);
          const ext = path.extname(file).toLowerCase();
          const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : "image/png";
          views.push(`data:${mime};base64,${buffer.toString("base64")}`);
          break;
        }
      }
    }

    return views.length === 3 ? views : null;
  } catch {
    return null;
  }
}

/** Save generation record to the project's generated-manuals index */
async function saveToGeneratedIndex(projectId: string, record: any): Promise<void> {
  try {
    const indexDir = path.join(process.cwd(), "data", "generated-manuals");
    await mkdir(indexDir, { recursive: true });
    const indexPath = path.join(indexDir, `${projectId}.json`);
    
    let records: any[] = [];
    try {
      const existing = await readFile(indexPath, "utf-8");
      records = JSON.parse(existing);
    } catch {
      // No existing file
    }
    
    records.push(record);
    await writeFile(indexPath, JSON.stringify(records, null, 2));
    console.log("[generate-pptx] Saved to generated-manuals index:", record.id);
  } catch (e) {
    console.warn("[generate-pptx] Failed to save index:", String(e));
    // Non-critical — the PPTX file itself is already saved
  }
}
