/**
 * PptxGenJS Renderer V5 — 行业适配版
 *
 * V4→V5 核心改动：
 * 1. 新增 industry 参数，根据行业切换场景页内容
 * 2. 餐饮→餐巾纸套/筷子套/外卖袋/菜单封面（非名片信封）
 * 3. 茶饮→杯套/外带杯/价目表
 * 4. 美容→预约卡/会员卡/产品标签
 * 5. 零售→价格标签/购物袋/货架卡
 * 6. 通用→名片/信封/包装盒/海报（V4默认）
 * 7. 保留V4全部改进：字体放大、场景写实化、lighten()
 */
import PptxGenJS from "pptxgenjs";
import type { PageBlueprint } from "./page-planner";

const SW = 8.27;
const SH = 11.69;
const MARGIN = 0.6;
const CONTENT_W = SW - MARGIN * 2;

export interface RenderPptxOptions {
  projectName?: string;
  companyName?: string;
  industry?: string;
  logoData?: string | null;
  mascotData?: string | null;
  mascotSplitViews?: string[] | null;
  brandColors?: { primary?: string; secondary?: string; accent?: string };
}

// ========== 行业类型 ==========
type IndustryType = "restaurant" | "beverage" | "beauty" | "retail" | "education" | "general";

function getIndustryType(industry?: string): IndustryType {
  if (!industry) return "general";
  const s = industry.toLowerCase();
  if (/餐|食|面|火锅|烧烤|烘焙|饺子|包子|炒菜|饭店|小吃|饭馆|海鲜|川菜|粤菜|湘菜|鲁菜|馆|椰岛/.test(s)) return "restaurant";
  if (/茶|咖啡|饮|奶茶|果汁|酒|酒吧|饮品|奶茶店/.test(s)) return "beverage";
  if (/美容|美发|理发|美甲|spa|沙龙|造型|护肤|美体|美睫/.test(s)) return "beauty";
  if (/零售|超市|便利|商店|杂货|服装|鞋|饰品|母婴|数码/.test(s)) return "retail";
  if (/教育|培训|学|课|幼儿园|托管|辅导/.test(s)) return "education";
  return "general";
}

// 行业场景配置
interface SceneConfig {
  title: string;
  desc: string;
}

function getSceneConfigs(industry: IndustryType): Record<string, SceneConfig> {
  const configs: Record<IndustryType, Record<string, SceneConfig>> = {
    restaurant: {
      stationery: { title: "餐饮应用系统", desc: "品牌在餐饮场景中的标准化应用" },
      packaging: { title: "餐饮包装系统", desc: "外卖与打包物料的品牌化呈现" },
      marketing: { title: "餐饮营销系统", desc: "店内宣传与客户触达物料" },
    },
    beverage: {
      stationery: { title: "茶饮应用系统", desc: "品牌在茶饮场景中的标准化应用" },
      packaging: { title: "茶饮包装系统", desc: "杯具与外带物料的品牌化呈现" },
      marketing: { title: "茶饮营销系统", desc: "门店宣传与促销物料" },
    },
    beauty: {
      stationery: { title: "美容应用系统", desc: "品牌在美容服务场景中的标准化应用" },
      packaging: { title: "美容包装系统", desc: "产品与礼品物料的品牌化呈现" },
      marketing: { title: "美容营销系统", desc: "门店宣传与客户维护物料" },
    },
    retail: {
      stationery: { title: "零售应用系统", desc: "品牌在零售场景中的标准化应用" },
      packaging: { title: "零售包装系统", desc: "购物袋与商品包装的品牌化呈现" },
      marketing: { title: "零售营销系统", desc: "店内宣传与促销物料" },
    },
    education: {
      stationery: { title: "教育应用系统", desc: "品牌在教育场景中的标准化应用" },
      packaging: { title: "教育包装系统", desc: "课程资料与教具的品牌化呈现" },
      marketing: { title: "教育营销系统", desc: "招生宣传与校区展示物料" },
    },
    general: {
      stationery: { title: "办公应用系统", desc: "品牌在商务场景中的标准化应用" },
      packaging: { title: "产品包装系统", desc: "品牌主色调贯穿包装设计" },
      marketing: { title: "营销展示系统", desc: "场景化品牌视觉应用" },
    },
  };
  return configs[industry] || configs.general;
}

interface BC {
  pri: string; sec: string; acc: string;
  priDark: string;
  priLight: string;
}

function resolveBC(opts: RenderPptxOptions, blueprints: PageBlueprint[]): BC {
  const p = opts.brandColors?.primary;
  const s = opts.brandColors?.secondary;
  const a = opts.brandColors?.accent;
  if (p && p !== "#FFFFFF" && p !== "#ffffff") {
    return { pri: hx(p), sec: hx(s || "#34A853"), acc: hx(a || "#FBBC04"), priDark: darken(hx(p)), priLight: lighten(hx(p)) };
  }
  const cover = blueprints.find(b => b.pageId === "cover");
  if (cover?.background?.primaryColor && cover.background.primaryColor !== "#FFFFFF") {
    return { pri: hx(cover.background.primaryColor), sec: hx(cover.background.secondaryColor || "#34A853"), acc: hx(cover.background.accentColor || "#FBBC04"), priDark: darken(hx(cover.background.primaryColor)), priLight: lighten(hx(cover.background.primaryColor)) };
  }
  return { pri: "1A73E8", sec: "34A853", acc: "FBBC04", priDark: "0D47A1", priLight: "E3F2FD" };
}

export async function renderPptx(blueprints: PageBlueprint[], options: RenderPptxOptions = {}): Promise<PptxGenJS> {
  const pptx = new PptxGenJS();
  pptx.defineLayout({ name: "A4_PORTRAIT", width: SW, height: SH });
  pptx.layout = "A4_PORTRAIT";
  pptx.author = "Brand Brain";
  const cn = options.companyName || "品牌";
  pptx.subject = `${cn} VI 规范手册`;
  pptx.title = `${cn} 品牌视觉识别系统（VI）规范手册`;
  const bc = resolveBC(options, blueprints);
  const industry = getIndustryType(options.industry);
  for (const bp of blueprints) {
    const slide = pptx.addSlide();
    renderSlide(slide, bp, options, bc, industry);
  }
  return pptx;
}

export async function renderPptxToBuffer(blueprints: PageBlueprint[], options: RenderPptxOptions = {}): Promise<Buffer> {
  const pptx = await renderPptx(blueprints, options);
  const base64 = await pptx.write({ outputType: "base64" }) as string;
  return Buffer.from(base64, "base64");
}

const PAGE_ORDER = ["cover","brand-philosophy","logo-interpretation","brand-colors","typography","basic-spec","stationery","packaging","marketing","summary","closing"];

function renderSlide(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC, industry: IndustryType): void {
  switch (bp.pageId) {
    case "cover": renderCover(slide, bp, opts, bc); break;
    case "closing": renderClosing(slide, bp, opts, bc); break;
    case "brand-philosophy": renderPhilosophy(slide, bp, opts, bc); break;
    case "logo-interpretation": renderLogoPage(slide, bp, opts, bc); break;
    case "brand-colors": renderColors(slide, bp, opts, bc); break;
    case "typography": renderTypography(slide, bp, opts, bc); break;
    case "basic-spec": renderBasicSpec(slide, bp, opts, bc); break;
    case "stationery": renderScene(slide, bp, opts, "stationery", bc, industry); break;
    case "packaging": renderScene(slide, bp, opts, "packaging", bc, industry); break;
    case "marketing": renderScene(slide, bp, opts, "marketing", bc, industry); break;
    case "summary": renderSummary(slide, bp, opts, bc); break;
    default: renderGeneric(slide, bp, opts, bc);
  }
  if (bp.pageId !== "cover" && bp.pageId !== "closing") {
    const idx = PAGE_ORDER.indexOf(bp.pageId);
    slide.addText(`${idx > 0 ? idx : ""}`, { x: SW - MARGIN - 0.5, y: SH - 0.5, w: 0.5, h: 0.3, fontSize: 9, color: "BBBBBB", align: "right" });
  }
}

// ========== Cover ==========
function renderCover(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  const cn = fta(bp, ["cover-company-name","company-name"]) || opts.companyName || "品牌";
  slide.background = { fill: bc.pri };
  slide.addShape("rect", { x: 0, y: 0, w: SW, h: 0.08, fill: { color: bc.acc } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: (SW - 5.0) / 2, y: 1.0, w: 5.0, h: 2.5, sizing: { type: "contain", w: 5.0, h: 2.5 } });
  } else {
    slide.addShape("rect", { x: (SW - 3.5) / 2, y: 1.2, w: 3.5, h: 1.8, fill: { color: "FFFFFF" }, rectRadius: 0.15, line: { color: "FFFFFF", width: 1 }, shadow: { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.15 } });
  }
  slide.addText(cn, { x: MARGIN, y: 4.0, w: CONTENT_W, h: 1.0, fontSize: 40, bold: true, color: "FFFFFF", align: "center", fontFace: "Microsoft YaHei" });
  slide.addShape("rect", { x: (SW - 3.0) / 2, y: 5.2, w: 3.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("品牌视觉识别系统（VI）规范手册", { x: MARGIN, y: 5.5, w: CONTENT_W, h: 0.6, fontSize: 20, bold: true, color: "FFFFFF", align: "center", transparency: 5 });
  slide.addText("VISUAL IDENTITY GUIDELINES", { x: MARGIN, y: 6.2, w: CONTENT_W, h: 0.4, fontSize: 14, color: "FFFFFF", align: "center", transparency: 20, charSpacing: 5 });
  if (opts.mascotData) {
    slide.addImage({ data: normImg(opts.mascotData), x: SW - 3.8, y: 4.5, w: 3.2, h: 3.6, sizing: { type: "contain", w: 3.2, h: 3.6 }, transparency: 5 });
  }
  slide.addText(`${cn}  ·  v1.0  ·  ${new Date().getFullYear()}`, { x: MARGIN, y: SH - 1.0, w: CONTENT_W, h: 0.4, fontSize: 12, color: "FFFFFF", align: "center", transparency: 25 });
  slide.addShape("rect", { x: 0, y: SH - 0.1, w: SW, h: 0.1, fill: { color: bc.acc } });
}

// ========== Closing ==========
function renderClosing(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  const cn = opts.companyName || "品牌";
  slide.background = { fill: bc.pri };
  slide.addShape("rect", { x: 0, y: 0, w: SW, h: 0.08, fill: { color: bc.acc } });
  slide.addText("感谢观看", { x: MARGIN, y: SH / 2 - 2.0, w: CONTENT_W, h: 1.2, fontSize: 40, bold: true, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: (SW - 2.0) / 2, y: SH / 2 - 0.6, w: 2.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText(`${cn} · 品牌视觉识别系统 (VI) 规范手册`, { x: MARGIN, y: SH / 2 - 0.3, w: CONTENT_W, h: 0.5, fontSize: 14, color: "FFFFFF", align: "center", transparency: 20 });
  if (opts.mascotData) {
    slide.addImage({ data: normImg(opts.mascotData), x: (SW - 2.5) / 2, y: SH / 2 + 0.5, w: 2.5, h: 2.8, sizing: { type: "contain", w: 2.5, h: 2.8 }, transparency: 10 });
  }
  slide.addText(`如有疑问，请联系 ${cn}`, { x: MARGIN, y: SH - 1.5, w: CONTENT_W, h: 0.4, fontSize: 12, color: "FFFFFF", align: "center", transparency: 30 });
  slide.addShape("rect", { x: 0, y: SH - 0.1, w: SW, h: 0.1, fill: { color: bc.acc } });
}

// ========== Content Page Header ==========
function addHeader(slide: PptxGenJS.Slide, title: string, bc: BC): void {
  slide.background = { fill: "FFFFFF" };
  slide.addShape("rect", { x: 0, y: 0, w: SW, h: 0.07, fill: { color: bc.pri } });
  slide.addText(title, { x: MARGIN, y: 0.4, w: CONTENT_W, h: 0.6, fontSize: 22, bold: true, color: bc.priDark });
  slide.addShape("rect", { x: MARGIN, y: 1.05, w: 1.8, h: 0.05, fill: { color: bc.acc } });
}

// ========== Brand Philosophy ==========
function renderPhilosophy(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "品牌核心理念", bc);
  const sections = extractPhilSections(bp);
  let yPos = 1.6;
  for (let i = 0; i < sections.length; i++) {
    const s = sections[i];
    slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.1, h: 1.8, fill: { color: bc.pri }, rectRadius: 0.03 });
    slide.addText(s.label, { x: MARGIN + 0.25, y: yPos + 0.1, w: CONTENT_W - 0.35, h: 0.5, fontSize: 16, bold: true, color: bc.pri });
    slide.addText(s.content || "待品牌方补充", { x: MARGIN + 0.25, y: yPos + 0.65, w: CONTENT_W - 0.35, h: 0.9, fontSize: 13, color: "444444", lineSpacingMultiple: 1.5, valign: "top" });
    yPos += 2.1;
  }
  if (opts.mascotData) {
    slide.addImage({ data: normImg(opts.mascotData), x: SW - 2.0, y: SH - 3.0, w: 1.6, h: 1.9, sizing: { type: "contain", w: 1.6, h: 1.9 }, transparency: 60 });
  }
}

// ========== Logo Interpretation ==========
function renderLogoPage(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "标识诠释", bc);
  const logoW = 4.0, logoH = 3.0;
  if (opts.logoData) {
    slide.addShape("rect", { x: (SW - logoW - 0.6) / 2, y: 1.5, w: logoW + 0.6, h: logoH + 0.6, fill: { color: "F5F5F5" }, rectRadius: 0.1 });
    slide.addImage({ data: normImg(opts.logoData), x: (SW - logoW) / 2, y: 1.8, w: logoW, h: logoH, sizing: { type: "contain", w: logoW, h: logoH } });
  }
  const philosophy = fta(bp, ["logo-philosophy","logo-meaning","logo-concept"]) || "Logo 凝练了品牌核心视觉要素，体现品牌独特识别性。";
  slide.addText("设计理念", { x: MARGIN, y: 5.5, w: CONTENT_W, h: 0.4, fontSize: 14, bold: true, color: bc.pri });
  slide.addText(philosophy, { x: MARGIN, y: 6.0, w: CONTENT_W, h: 1.2, fontSize: 12, color: "444444", lineSpacingMultiple: 1.6 });
  if (opts.mascotData) {
    slide.addText("IP 角色介绍", { x: MARGIN, y: 7.5, w: CONTENT_W, h: 0.4, fontSize: 14, bold: true, color: bc.pri });
    const ipW = 2.0, ipH = 2.5;
    slide.addShape("rect", { x: (SW - ipW - 0.4) / 2, y: 8.0, w: ipW + 0.4, h: ipH + 0.2, fill: { color: "F5F5F5" }, rectRadius: 0.08 });
    slide.addImage({ data: normImg(opts.mascotData), x: (SW - ipW) / 2, y: 8.1, w: ipW, h: ipH, sizing: { type: "contain", w: ipW, h: ipH } });
    const mascotDesc = fta(bp, ["mascot-philosophy","mascot-meaning","ip-intro"]) || "品牌IP公仔，承载品牌个性与亲和力。";
    slide.addText(mascotDesc, { x: MARGIN, y: 10.5, w: CONTENT_W, h: 0.5, fontSize: 11, color: "666666", align: "center", lineSpacingMultiple: 1.4 });
  }
}

// ========== Brand Colors ==========
function renderColors(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "标准色彩规范", bc);
  const colors = [
    { hex: bc.pri, label: "品牌主色", name: "Primary" },
    { hex: bc.sec, label: "辅助色", name: "Secondary" },
    { hex: bc.acc, label: "强调色", name: "Accent" },
  ];
  const blockW = 2.0, blockH = 2.2, gap = 0.3;
  const totalW = blockW * 3 + gap * 2;
  const startX = (SW - totalW) / 2;
  const startY = 1.5;

  for (let i = 0; i < 3; i++) {
    const c = colors[i];
    const x = startX + i * (blockW + gap);
    const isWhite = c.hex === "FFFFFF" || c.hex === "FFF";
    slide.addShape("rect", {
      x, y: startY, w: blockW, h: blockH,
      fill: { color: c.hex },
      rectRadius: 0.1,
      line: isWhite ? { color: "CCCCCC", width: 1 } : undefined,
      shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 }
    });
    const textColor = isLight(c.hex) ? "333333" : "FFFFFF";
    slide.addText(c.name, { x, y: startY + 0.3, w: blockW, h: 0.4, fontSize: 13, color: textColor, align: "center", transparency: 40 });
    slide.addText(c.label, { x, y: startY + blockH + 0.15, w: blockW, h: 0.35, fontSize: 13, bold: true, color: "333333", align: "center" });
    slide.addText(`#${c.hex}`, { x, y: startY + blockH + 0.5, w: blockW, h: 0.3, fontSize: 12, color: "555555", align: "center" });
    const rgb = hex2rgb(c.hex);
    if (rgb) {
      slide.addText(`RGB: ${rgb.r}, ${rgb.g}, ${rgb.b}`, { x, y: startY + blockH + 0.8, w: blockW, h: 0.3, fontSize: 11, color: "777777", align: "center" });
      const cmyk = rgb2cmyk(rgb);
      if (cmyk) {
        slide.addText(`CMYK: ${cmyk.c}, ${cmyk.m}, ${cmyk.y}, ${cmyk.k}`, { x, y: startY + blockH + 1.1, w: blockW, h: 0.3, fontSize: 11, color: "777777", align: "center" });
      }
    }
  }

  const comboY = startY + blockH + 1.8;
  slide.addText("色彩组合示例", { x: MARGIN, y: comboY, w: CONTENT_W, h: 0.4, fontSize: 14, bold: true, color: bc.pri });
  const combos = [
    { colors: [bc.pri, bc.sec], label: "主色 + 辅助色" },
    { colors: ["FFFFFF", bc.acc], label: "白底 + 强调色" },
    { colors: [bc.priDark, "FFFFFF"], label: "深主色 + 白底" },
  ];
  const comboW = 2.0, comboH = 0.8;
  const comboStartX = (SW - totalW) / 2;
  for (let i = 0; i < combos.length; i++) {
    const cx = comboStartX + i * (comboW + gap);
    const halfW = comboW / 2;
    slide.addShape("rect", { x: cx, y: comboY + 0.5, w: halfW, h: comboH, fill: { color: combos[i].colors[0] }, line: combos[i].colors[0] === "FFFFFF" ? { color: "E0E0E0", width: 0.5 } : undefined });
    slide.addShape("rect", { x: cx + halfW, y: comboY + 0.5, w: halfW, h: comboH, fill: { color: combos[i].colors[1] }, line: combos[i].colors[1] === "FFFFFF" ? { color: "E0E0E0", width: 0.5 } : undefined });
    slide.addText(combos[i].label, { x: cx, y: comboY + 0.5 + comboH + 0.1, w: comboW, h: 0.3, fontSize: 11, color: "555555", align: "center" });
  }
}

// ========== Typography ==========
function renderTypography(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "字体系统", bc);
  let yPos = 1.5;
  slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.1, h: 1.5, fill: { color: bc.pri }, rectRadius: 0.03 });
  slide.addText("中文字体", { x: MARGIN + 0.25, y: yPos + 0.1, w: CONTENT_W - 0.35, h: 0.4, fontSize: 16, bold: true, color: bc.pri });
  slide.addText("标题字体：思源黑体 / Noto Sans SC", { x: MARGIN + 0.25, y: yPos + 0.55, w: CONTENT_W - 0.35, h: 0.35, fontSize: 12, color: "444444" });
  slide.addText("正文字体：思源宋体 / Noto Serif SC", { x: MARGIN + 0.25, y: yPos + 0.9, w: CONTENT_W - 0.35, h: 0.35, fontSize: 12, color: "444444" });
  slide.addText("AaBbCc 你好世界 0123", { x: MARGIN + 0.25, y: yPos + 1.35, w: CONTENT_W - 0.35, h: 0.5, fontSize: 24, color: "333333" });
  yPos += 2.2;

  slide.addShape("rect", { x: MARGIN, y: yPos, w: 0.1, h: 1.5, fill: { color: bc.sec }, rectRadius: 0.03 });
  slide.addText("英文字体", { x: MARGIN + 0.25, y: yPos + 0.1, w: CONTENT_W - 0.35, h: 0.4, fontSize: 16, bold: true, color: bc.sec });
  slide.addText("Brand Font: Montserrat", { x: MARGIN + 0.25, y: yPos + 0.55, w: CONTENT_W - 0.35, h: 0.35, fontSize: 12, color: "444444" });
  slide.addText("Body Font: Open Sans", { x: MARGIN + 0.25, y: yPos + 0.9, w: CONTENT_W - 0.35, h: 0.35, fontSize: 12, color: "444444" });
  slide.addText("AaBbCc Hello World 0123", { x: MARGIN + 0.25, y: yPos + 1.35, w: CONTENT_W - 0.35, h: 0.5, fontSize: 24, color: "333333" });
  yPos += 2.2;

  slide.addText("字号层级规范", { x: MARGIN, y: yPos, w: CONTENT_W, h: 0.4, fontSize: 14, bold: true, color: bc.pri });
  const rows = [
    [{ text: "层级", options: { fontSize: 11, bold: true, color: "FFFFFF" } }, { text: "字号", options: { fontSize: 11, bold: true, color: "FFFFFF" } }, { text: "应用场景", options: { fontSize: 11, bold: true, color: "FFFFFF" } }],
    [{ text: "一级标题", options: { fontSize: 11, color: "333333" } }, { text: "28-36px", options: { fontSize: 11, color: "333333" } }, { text: "封面/章节标题", options: { fontSize: 11, color: "333333" } }],
    [{ text: "二级标题", options: { fontSize: 11, color: "333333" } }, { text: "20-24px", options: { fontSize: 11, color: "333333" } }, { text: "内页大标题", options: { fontSize: 11, color: "333333" } }],
    [{ text: "正文", options: { fontSize: 11, color: "333333" } }, { text: "12-14px", options: { fontSize: 11, color: "333333" } }, { text: "正文说明文字", options: { fontSize: 11, color: "333333" } }],
    [{ text: "辅助文字", options: { fontSize: 11, color: "333333" } }, { text: "10-11px", options: { fontSize: 11, color: "333333" } }, { text: "注释/标注/页码", options: { fontSize: 11, color: "333333" } }],
  ];
  slide.addTable(rows, { x: MARGIN, y: yPos + 0.5, w: CONTENT_W, colW: [1.8, 1.8, 3.47], border: { pt: 0.5, color: "E0E0E0" }, rowH: [0.4, 0.4, 0.4, 0.4, 0.4], autoPage: false });
}

// ========== Basic Spec ==========
function renderBasicSpec(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "基础规范", bc);
  slide.addText("LOGO 保护空间", { x: MARGIN, y: 1.5, w: CONTENT_W, h: 0.4, fontSize: 15, bold: true, color: bc.pri });
  slide.addText("LOGO 四周保留至少 15% 保护空间，不可被任何元素遮挡或裁切", { x: MARGIN, y: 1.95, w: CONTENT_W, h: 0.4, fontSize: 12, color: "555555" });
  const demoSize = 2.5;
  const demoX = (SW - demoSize) / 2;
  const demoY = 2.8;
  slide.addShape("rect", { x: demoX - 0.3, y: demoY - 0.3, w: demoSize + 0.6, h: demoSize + 0.6, fill: { color: "F5F5F5" }, rectRadius: 0.05, line: { color: "E0E0E0", width: 0.5, dashType: "dash" } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: demoX, y: demoY, w: demoSize, h: demoSize, sizing: { type: "contain", w: demoSize, h: demoSize } });
  }
  slide.addText("15% 保护空间", { x: demoX - 0.3, y: demoY + demoSize + 0.1, w: demoSize + 0.6, h: 0.3, fontSize: 10, color: "999999", align: "center" });

  slide.addText("最小尺寸规范", { x: MARGIN, y: 6.2, w: CONTENT_W, h: 0.4, fontSize: 15, bold: true, color: bc.pri });
  const rows = [
    [{ text: "应用场景", options: { fontSize: 11, bold: true, color: "FFFFFF" } }, { text: "最小宽度", options: { fontSize: 11, bold: true, color: "FFFFFF" } }, { text: "说明", options: { fontSize: 11, bold: true, color: "FFFFFF" } }],
    [{ text: "印刷品", options: { fontSize: 11, color: "333333" } }, { text: "30mm", options: { fontSize: 11, color: "333333" } }, { text: "名片/信封等印刷物料", options: { fontSize: 11, color: "333333" } }],
    [{ text: "数字媒体", options: { fontSize: 11, color: "333333" } }, { text: "80px", options: { fontSize: 11, color: "333333" } }, { text: "网站/App 等数字媒介", options: { fontSize: 11, color: "333333" } }],
    [{ text: "户外广告", options: { fontSize: 11, color: "333333" } }, { text: "200mm", options: { fontSize: 11, color: "333333" } }, { text: "广告牌/展架等大尺寸场景", options: { fontSize: 11, color: "333333" } }],
  ];
  slide.addTable(rows, { x: MARGIN, y: 6.8, w: CONTENT_W, colW: [1.8, 1.8, 3.47], border: { pt: 0.5, color: "E0E0E0" }, rowH: [0.4, 0.4, 0.4, 0.4], autoPage: false });
}

// ========== Scene Pages — 行业适配核心 ==========
function renderScene(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, type: string, bc: BC, industry: IndustryType): void {
  slide.background = { fill: "FFFFFF" };
  const configs = getSceneConfigs(industry);
  const config = configs[type] || { title: type, desc: "" };
  addHeader(slide, config.title, bc);
  slide.addText(config.desc, { x: MARGIN, y: 1.4, w: CONTENT_W, h: 0.4, fontSize: 12, color: "666666" });

  switch (industry) {
    case "restaurant":
      if (type === "stationery") drawRestaurantStationery(slide, bc, opts);
      else if (type === "packaging") drawRestaurantPackaging(slide, bc, opts);
      else drawRestaurantMarketing(slide, bc, opts);
      break;
    case "beverage":
      if (type === "stationery") drawBeverageStationery(slide, bc, opts);
      else if (type === "packaging") drawBeveragePackaging(slide, bc, opts);
      else drawBeverageMarketing(slide, bc, opts);
      break;
    case "beauty":
      if (type === "stationery") drawBeautyStationery(slide, bc, opts);
      else if (type === "packaging") drawBeautyPackaging(slide, bc, opts);
      else drawBeautyMarketing(slide, bc, opts);
      break;
    case "retail":
      if (type === "stationery") drawRetailStationery(slide, bc, opts);
      else if (type === "packaging") drawRetailPackaging(slide, bc, opts);
      else drawRetailMarketing(slide, bc, opts);
      break;
    default:
      if (type === "stationery") drawGeneralStationery(slide, bc, opts);
      else if (type === "packaging") drawGeneralPackaging(slide, bc, opts);
      else drawGeneralMarketing(slide, bc, opts);
  }
}

// ==================== 餐饮行业 ====================
function drawRestaurantStationery(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 餐巾纸套 — 扁长矩形
  const nw = 4.0, nh = 1.6;
  const nx = (SW - nw) / 2, ny = 2.0;
  slide.addShape("rect", { x: nx, y: ny, w: nw, h: nh, fill: { color: "FFFFFF" }, rectRadius: 0.06, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.1 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: nx, y: ny, w: nw, h: nh, fill: { color: bc.pri, transparency: 8 }, rectRadius: 0.06 });
  slide.addShape("rect", { x: nx, y: ny, w: 0.1, h: nh, fill: { color: bc.priDark } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: nx + 0.3, y: ny + 0.15, w: 1.2, h: 0.7, sizing: { type: "contain", w: 1.2, h: 0.7 } });
  }
  slide.addText(opts.companyName || "品牌", { x: nx + 1.6, y: ny + 0.15, w: 2.0, h: 0.4, fontSize: 14, bold: true, color: "333333" });
  slide.addText("优质餐巾纸 · 用心服务", { x: nx + 1.6, y: ny + 0.6, w: 2.0, h: 0.35, fontSize: 10, color: "888888" });
  slide.addShape("rect", { x: nx + 0.3, y: ny + nh - 0.35, w: nw - 0.6, h: 0.04, fill: { color: bc.acc } });
  slide.addText("餐巾纸套", { x: nx, y: ny + nh + 0.08, w: nw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 筷子套 — 细长形
  const sw = 1.0, sh = 3.8;
  const sx = SW / 2 - 2.0, sy = ny + nh + 0.8;
  slide.addShape("rect", { x: sx, y: sy, w: sw, h: sh, fill: { color: "FFFFFF" }, rectRadius: 0.04, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: sx, y: sy, w: sw, h: 0.8, fill: { color: bc.pri }, rectRadius: 0.03 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: sx + 0.08, y: sy + 0.1, w: 0.84, h: 0.55, sizing: { type: "contain", w: 0.84, h: 0.55 } });
  }
  slide.addText("筷", { x: sx, y: sy + 1.2, w: sw, h: 0.4, fontSize: 18, color: bc.pri, align: "center" });
  slide.addText("子", { x: sx, y: sy + 1.6, w: sw, h: 0.4, fontSize: 18, color: bc.pri, align: "center" });
  slide.addShape("rect", { x: sx + 0.2, y: sy + sh - 0.5, w: 0.6, h: 0.04, fill: { color: bc.acc } });
  slide.addText("筷子套", { x: sx - 0.3, y: sy + sh + 0.08, w: sw + 0.6, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 外卖贴纸 — 方形
  const tw = 2.2, th = 2.2;
  const tx = SW / 2 + 0.5, ty = sy + 0.5;
  slide.addShape("rect", { x: tx, y: ty, w: tw, h: th, fill: { color: bc.pri }, rectRadius: 0.12, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.1 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: tx + 0.4, y: ty + 0.3, w: 1.4, h: 1.0, sizing: { type: "contain", w: 1.4, h: 1.0 } });
  }
  slide.addText("已封签 · 放心食用", { x: tx, y: ty + 1.5, w: tw, h: 0.35, fontSize: 10, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: tx + 0.3, y: ty + th - 0.25, w: tw - 0.6, h: 0.04, fill: { color: bc.acc } });
  slide.addText("外卖封签贴纸", { x: tx - 0.3, y: ty + th + 0.08, w: tw + 0.6, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawRestaurantPackaging(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 外卖袋
  const bw = 3.4, bh = 4.0;
  const bx = 1.0, by = 2.0;
  slide.addShape("rect", { x: bx, y: by, w: bw, h: bh, fill: { color: bc.pri }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 } });
  // 提手线
  slide.addShape("line", { x: bx + 0.8, y: by - 0.4, w: 0, h: 0.5, line: { color: bc.priDark, width: 2.5 } });
  slide.addShape("line", { x: bx + bw - 0.8, y: by - 0.4, w: 0, h: 0.5, line: { color: bc.priDark, width: 2.5 } });
  // 顶部深色条
  slide.addShape("rect", { x: bx, y: by, w: bw, h: 0.25, fill: { color: bc.priDark }, rectRadius: 0.05 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bx + 0.5, y: by + 0.6, w: 2.4, h: 1.8, sizing: { type: "contain", w: 2.4, h: 1.8 } });
  }
  slide.addText(opts.companyName || "品牌", { x: bx, y: by + 2.6, w: bw, h: 0.4, fontSize: 16, bold: true, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: bx + 0.5, y: by + 3.2, w: bw - 1.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("外卖袋", { x: bx, y: by + bh + 0.08, w: bw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 打包盒
  const bxW = 3.2, bxH = 3.5;
  const bxX = 5.0, bxY = 2.3;
  slide.addShape("rect", { x: bxX, y: bxY, w: bxW, h: bxH, fill: { color: "FFFFFF" }, rectRadius: 0.1, shadow: { type: "outer", blur: 6, offset: 3, color: "000000", opacity: 0.12 }, line: { color: "E0E0E0", width: 0.3 } });
  // 盒盖 — 品牌色区域
  slide.addShape("rect", { x: bxX, y: bxY, w: bxW, h: 1.0, fill: { color: bc.pri }, rectRadius: 0.08 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bxX + 0.6, y: bxY + 0.1, w: 2.0, h: 0.7, sizing: { type: "contain", w: 2.0, h: 0.7 } });
  }
  // 盒身内容
  slide.addText("精 选 食 材", { x: bxX, y: bxY + 1.4, w: bxW, h: 0.5, fontSize: 14, bold: true, color: bc.pri, align: "center" });
  slide.addText("用心制作", { x: bxX, y: bxY + 1.9, w: bxW, h: 0.35, fontSize: 11, color: "888888", align: "center" });
  slide.addShape("rect", { x: bxX + 0.8, y: bxY + 2.5, w: bxW - 1.6, h: 0.04, fill: { color: bc.acc } });
  slide.addText("打包盒", { x: bxX, y: bxY + bxH + 0.08, w: bxW, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawRestaurantMarketing(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 菜单封面
  const mw = 4.5, mh = 5.5;
  const mx = 0.5, my = 2.0;
  slide.addShape("rect", { x: mx, y: my, w: mw, h: mh, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: mx, y: my, w: mw, h: mh * 0.5, fill: { color: bc.pri }, rectRadius: 0.05 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: mx + 1.0, y: my + 0.5, w: 2.5, h: 1.8, sizing: { type: "contain", w: 2.5, h: 1.8 } });
  }
  slide.addText("菜  单", { x: mx + 0.4, y: my + mh * 0.5 + 0.3, w: mw - 0.8, h: 0.7, fontSize: 28, bold: true, color: "333333", align: "center", fontFace: "Microsoft YaHei" });
  slide.addText("MENU", { x: mx + 0.4, y: my + mh * 0.5 + 1.0, w: mw - 0.8, h: 0.4, fontSize: 14, color: "999999", align: "center", charSpacing: 8 });
  slide.addShape("rect", { x: mx + 1.0, y: my + mh * 0.5 + 1.6, w: mw - 2.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("菜单封面", { x: mx, y: my + mh + 0.08, w: mw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 桌牌/立牌
  const tw = 2.5, th = 2.0;
  const tx = 5.5, ty = 2.5;
  slide.addShape("rect", { x: tx, y: ty, w: tw, h: th, fill: { color: bc.priLight }, rectRadius: 0.06, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.1 }, line: { color: bc.pri, width: 1 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: tx + 0.3, y: ty + 0.15, w: 1.0, h: 0.6, sizing: { type: "contain", w: 1.0, h: 0.6 } });
  }
  slide.addText("扫码点餐", { x: tx, y: ty + 0.9, w: tw, h: 0.4, fontSize: 14, bold: true, color: bc.pri, align: "center" });
  slide.addText("[ 二维码 ]", { x: tx, y: ty + 1.3, w: tw, h: 0.35, fontSize: 11, color: "999999", align: "center" });
  slide.addText("桌牌 / 立牌", { x: tx - 0.2, y: ty + th + 0.08, w: tw + 0.4, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 好评卡
  const cw = 2.5, ch = 1.5;
  const cx = 5.5, cy = ty + th + 1.0;
  slide.addShape("rect", { x: cx, y: cy, w: cw, h: ch, fill: { color: "FFFFFF" }, rectRadius: 0.06, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 }, line: { color: bc.acc, width: 1.5 } });
  slide.addShape("rect", { x: cx, y: cy, w: 0.08, h: ch, fill: { color: bc.acc } });
  slide.addText("好评返现", { x: cx + 0.2, y: cy + 0.15, w: cw - 0.3, h: 0.35, fontSize: 13, bold: true, color: bc.pri });
  slide.addText("五星好评截图发客服", { x: cx + 0.2, y: cy + 0.55, w: cw - 0.3, h: 0.3, fontSize: 10, color: "666666" });
  slide.addText("立享优惠 →", { x: cx + 0.2, y: cy + 0.9, w: cw - 0.3, h: 0.3, fontSize: 11, bold: true, color: bc.acc });
  slide.addText("好评卡", { x: cx - 0.2, y: cy + ch + 0.08, w: cw + 0.4, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

// ==================== 茶饮行业 ====================
function drawBeverageStationery(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 杯套
  const cw = 3.5, ch = 1.2;
  const cx = (SW - cw) / 2, cy = 2.0;
  slide.addShape("rect", { x: cx, y: cy, w: cw, h: ch, fill: { color: bc.pri }, rectRadius: 0.08, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.1 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: cx + 0.3, y: cy + 0.15, w: 1.0, h: 0.6, sizing: { type: "contain", w: 1.0, h: 0.6 } });
  }
  slide.addText(opts.companyName || "品牌", { x: cx + 1.4, y: cy + 0.15, w: 1.8, h: 0.4, fontSize: 14, bold: true, color: "FFFFFF" });
  slide.addText("手作好茶 · 新鲜每一天", { x: cx + 1.4, y: cy + 0.6, w: 1.8, h: 0.3, fontSize: 10, color: "FFFFFF", transparency: 30 });
  slide.addText("杯套", { x: cx, y: cy + ch + 0.08, w: cw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 杯垫
  const dw = 2.4, dh = 2.4;
  const dx = 1.2, dy = cy + ch + 0.8;
  slide.addShape("rect", { x: dx, y: dy, w: dw, h: dh, fill: { color: bc.priLight }, rectRadius: 0.15, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.08 }, line: { color: bc.pri, width: 1 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: dx + 0.4, y: dy + 0.4, w: 1.6, h: 1.2, sizing: { type: "contain", w: 1.6, h: 1.2 }, transparency: 10 });
  }
  slide.addText("杯垫", { x: dx, y: dy + dh + 0.08, w: dw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 名片
  const nw = 3.6, nh = 2.2;
  const nx = 4.2, ny = dy;
  slide.addShape("rect", { x: nx, y: ny, w: nw, h: nh, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.1 }, line: { color: "E8E8E8", width: 0.3 } });
  slide.addShape("rect", { x: nx, y: ny, w: 0.1, h: nh, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: nx + 0.3, y: ny + 0.2, w: 1.2, h: 0.7, sizing: { type: "contain", w: 1.2, h: 0.7 } });
  }
  slide.addText("张 伟\n店长", { x: nx + 0.3, y: ny + 1.0, w: 1.5, h: 0.8, fontSize: 11, color: "333333", lineSpacingMultiple: 1.4 });
  slide.addText("138-0000-0000", { x: nx + 1.9, y: ny + 1.2, w: 1.5, h: 0.3, fontSize: 10, color: "888888", align: "right" });
  slide.addText("名片", { x: nx, y: ny + nh + 0.08, w: nw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawBeveragePackaging(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 外带杯
  const cw = 2.2, ch = 4.5;
  const cx = 1.5, cy = 2.0;
  // 杯身
  slide.addShape("rect", { x: cx, y: cy + 0.4, w: cw, h: ch - 0.4, fill: { color: "FFFFFF" }, rectRadius: 0.06, shadow: { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.12 }, line: { color: "E0E0E0", width: 0.3 } });
  // 杯盖
  slide.addShape("rect", { x: cx - 0.1, y: cy, w: cw + 0.2, h: 0.5, fill: { color: bc.priDark }, rectRadius: 0.08 });
  // 品牌色带
  slide.addShape("rect", { x: cx, y: cy + 1.2, w: cw, h: 1.5, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: cx + 0.3, y: cy + 1.35, w: 1.6, h: 1.1, sizing: { type: "contain", w: 1.6, h: 1.1 } });
  }
  slide.addText(opts.companyName || "品牌", { x: cx, y: cy + 3.2, w: cw, h: 0.35, fontSize: 12, bold: true, color: bc.pri, align: "center" });
  slide.addText("外带杯", { x: cx - 0.3, y: cy + ch + 0.08, w: cw + 0.6, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 外卖袋
  const bw = 3.0, bh = 3.6;
  const bx = 5.0, by = 2.2;
  slide.addShape("rect", { x: bx, y: by, w: bw, h: bh, fill: { color: bc.pri }, rectRadius: 0.06, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 } });
  slide.addShape("line", { x: bx + 0.6, y: by - 0.3, w: 0, h: 0.4, line: { color: bc.priDark, width: 2 } });
  slide.addShape("line", { x: bx + bw - 0.6, y: by - 0.3, w: 0, h: 0.4, line: { color: bc.priDark, width: 2 } });
  slide.addShape("rect", { x: bx, y: by, w: bw, h: 0.2, fill: { color: bc.priDark }, rectRadius: 0.04 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bx + 0.4, y: by + 0.5, w: 2.2, h: 1.5, sizing: { type: "contain", w: 2.2, h: 1.5 } });
  }
  slide.addText(opts.companyName || "品牌", { x: bx, y: by + 2.2, w: bw, h: 0.4, fontSize: 14, bold: true, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: bx + 0.4, y: by + 2.8, w: bw - 0.8, h: 0.04, fill: { color: bc.acc } });
  slide.addText("外卖袋", { x: bx, y: by + bh + 0.08, w: bw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawBeverageMarketing(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 价目表
  const pw = 3.8, ph = 5.5;
  const px = 0.5, py = 2.0;
  slide.addShape("rect", { x: px, y: py, w: pw, h: ph, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: px, y: py, w: pw, h: 1.2, fill: { color: bc.pri }, rectRadius: 0.06 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: px + 0.4, y: py + 0.1, w: 1.4, h: 0.8, sizing: { type: "contain", w: 1.4, h: 0.8 } });
  }
  slide.addText("价目表", { x: px + 2.0, y: py + 0.3, w: 1.5, h: 0.5, fontSize: 18, bold: true, color: "FFFFFF", align: "center" });
  const items = ["招牌奶茶", "鲜果茶", "纯茶系列", "特调饮品"];
  let iy = py + 1.6;
  for (const item of items) {
    slide.addText(item, { x: px + 0.4, y: iy, w: 2.0, h: 0.35, fontSize: 12, color: "333333" });
    slide.addText("¥", { x: px + pw - 1.2, y: iy, w: 0.8, h: 0.35, fontSize: 12, color: bc.pri, align: "right" });
    slide.addShape("rect", { x: px + 0.4, y: iy + 0.4, w: pw - 0.8, h: 0.02, fill: { color: "F0F0F0" } });
    iy += 0.6;
  }
  slide.addText("价目表", { x: px, y: py + ph + 0.08, w: pw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 促销卡
  const cw = 3.0, ch = 2.8;
  const cx = 5.0, cy = 2.5;
  slide.addShape("rect", { x: cx, y: cy, w: cw, h: ch, fill: { color: bc.pri }, rectRadius: 0.1, shadow: { type: "outer", blur: 6, offset: 3, color: "000000", opacity: 0.12 } });
  slide.addText("限时优惠", { x: cx, y: cy + 0.3, w: cw, h: 0.5, fontSize: 20, bold: true, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: cx + 0.5, y: cy + 0.9, w: cw - 1.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("第二杯半价", { x: cx, y: cy + 1.2, w: cw, h: 0.4, fontSize: 16, color: "FFFFFF", align: "center" });
  slide.addText("会员专享", { x: cx, y: cy + 1.8, w: cw, h: 0.35, fontSize: 12, color: "FFFFFF", transparency: 30, align: "center" });
  slide.addText("促销卡", { x: cx, y: cy + ch + 0.08, w: cw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

// ==================== 美容行业 ====================
function drawBeautyStationery(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 预约卡
  const aw = 3.6, ah = 2.2;
  const ax = (SW - aw) / 2, ay = 2.0;
  slide.addShape("rect", { x: ax, y: ay, w: aw, h: ah, fill: { color: "FFFFFF" }, rectRadius: 0.1, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.1 }, line: { color: bc.pri, width: 1 } });
  slide.addShape("rect", { x: ax, y: ay, w: aw, h: 0.08, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: ax + 0.3, y: ay + 0.2, w: 1.0, h: 0.6, sizing: { type: "contain", w: 1.0, h: 0.6 } });
  }
  slide.addText("预约卡", { x: ax + 1.4, y: ay + 0.2, w: 1.8, h: 0.4, fontSize: 14, bold: true, color: bc.pri });
  slide.addText("预约日期：____年____月____日\n预约项目：________________\n预约技师：________________", { x: ax + 0.3, y: ay + 0.9, w: aw - 0.6, h: 1.0, fontSize: 11, color: "666666", lineSpacingMultiple: 1.6 });
  slide.addText("预约卡", { x: ax, y: ay + ah + 0.08, w: aw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 会员卡
  const mw = 3.6, mh = 2.2;
  const mx = (SW - mw) / 2, my = ay + ah + 0.8;
  slide.addShape("rect", { x: mx, y: my, w: mw, h: mh, fill: { color: bc.pri }, rectRadius: 0.1, shadow: { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.12 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: mx + 0.3, y: my + 0.2, w: 1.2, h: 0.7, sizing: { type: "contain", w: 1.2, h: 0.7 } });
  }
  slide.addText("尊享会员", { x: mx + 1.6, y: my + 0.3, w: 1.6, h: 0.4, fontSize: 14, bold: true, color: "FFFFFF" });
  slide.addShape("rect", { x: mx + 0.3, y: my + 1.2, w: mw - 0.6, h: 0.04, fill: { color: bc.acc } });
  slide.addText("NO. 8888 8888 8888", { x: mx + 0.3, y: my + 1.4, w: mw - 0.6, h: 0.35, fontSize: 12, color: "FFFFFF", transparency: 20, charSpacing: 3 });
  slide.addText("会员卡", { x: mx, y: my + mh + 0.08, w: mw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawBeautyPackaging(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 产品标签
  const lw = 3.0, lh = 1.8;
  const lx = (SW - lw) / 2, ly = 2.0;
  slide.addShape("rect", { x: lx, y: ly, w: lw, h: lh, fill: { color: "FFFFFF" }, rectRadius: 0.06, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 }, line: { color: bc.pri, width: 1 } });
  slide.addShape("rect", { x: lx, y: ly, w: 0.08, h: lh, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: lx + 0.2, y: ly + 0.2, w: 0.8, h: 0.5, sizing: { type: "contain", w: 0.8, h: 0.5 } });
  }
  slide.addText("产品名称", { x: lx + 1.1, y: ly + 0.2, w: 1.6, h: 0.35, fontSize: 13, bold: true, color: bc.pri });
  slide.addText("净含量：30ml", { x: lx + 1.1, y: ly + 0.6, w: 1.6, h: 0.3, fontSize: 10, color: "888888" });
  slide.addShape("rect", { x: lx + 0.2, y: ly + lh - 0.35, w: lw - 0.4, h: 0.04, fill: { color: bc.acc } });
  slide.addText("产品标签", { x: lx, y: ly + lh + 0.08, w: lw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 礼品袋
  const gw = 3.0, gh = 3.8;
  const gx = (SW - gw) / 2, gy = ly + lh + 0.8;
  slide.addShape("rect", { x: gx, y: gy, w: gw, h: gh, fill: { color: bc.priLight }, rectRadius: 0.08, shadow: { type: "outer", blur: 6, offset: 3, color: "000000", opacity: 0.1 }, line: { color: bc.pri, width: 1 } });
  slide.addShape("line", { x: gx + 0.7, y: gy - 0.3, w: 0, h: 0.4, line: { color: bc.pri, width: 2 } });
  slide.addShape("line", { x: gx + gw - 0.7, y: gy - 0.3, w: 0, h: 0.4, line: { color: bc.pri, width: 2 } });
  slide.addShape("rect", { x: gx, y: gy, w: gw, h: 0.2, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: gx + 0.5, y: gy + 0.6, w: 2.0, h: 1.5, sizing: { type: "contain", w: 2.0, h: 1.5 }, transparency: 5 });
  }
  slide.addText("礼品袋", { x: gx, y: gy + gh + 0.08, w: gw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawBeautyMarketing(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 价目表
  const pw = 3.5, ph = 5.0;
  const px = 0.8, py = 2.0;
  slide.addShape("rect", { x: px, y: py, w: pw, h: ph, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 6, offset: 3, color: "000000", opacity: 0.12 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: px, y: py, w: pw, h: 1.0, fill: { color: bc.pri }, rectRadius: 0.06 });
  slide.addText("服务价目表", { x: px, y: py + 0.2, w: pw, h: 0.5, fontSize: 18, bold: true, color: "FFFFFF", align: "center" });
  const items = ["基础护理", "深度清洁", "美白疗程", "特色项目"];
  let iy = py + 1.4;
  for (const item of items) {
    slide.addText(item, { x: px + 0.3, y: iy, w: 2.0, h: 0.3, fontSize: 12, color: "333333" });
    slide.addText("咨询", { x: px + pw - 1.0, y: iy, w: 0.6, h: 0.3, fontSize: 12, color: bc.pri, align: "right" });
    iy += 0.5;
  }
  slide.addText("价目表", { x: px, y: py + ph + 0.08, w: pw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 海报
  const hw = 3.0, hh = 4.0;
  const hx = 5.0, hy = 2.5;
  slide.addShape("rect", { x: hx, y: hy, w: hw, h: hh, fill: { color: bc.pri }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 } });
  slide.addText("限时体验", { x: hx, y: hy + 0.5, w: hw, h: 0.5, fontSize: 22, bold: true, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: hx + 0.5, y: hy + 1.2, w: hw - 1.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("新客专享\n首次体验价", { x: hx, y: hy + 1.5, w: hw, h: 0.8, fontSize: 14, color: "FFFFFF", align: "center", lineSpacingMultiple: 1.5 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: hx + 0.6, y: hy + 2.6, w: 1.8, h: 1.0, sizing: { type: "contain", w: 1.8, h: 1.0 }, transparency: 10 });
  }
  slide.addText("促销海报", { x: hx, y: hy + hh + 0.08, w: hw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

// ==================== 零售行业 ====================
function drawRetailStationery(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 名片
  const nw = 3.6, nh = 2.2;
  const nx = (SW - nw) / 2, ny = 2.0;
  slide.addShape("rect", { x: nx, y: ny, w: nw, h: nh, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.1 }, line: { color: "E8E8E8", width: 0.3 } });
  slide.addShape("rect", { x: nx, y: ny, w: 0.1, h: nh, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: nx + 0.3, y: ny + 0.2, w: 1.2, h: 0.7, sizing: { type: "contain", w: 1.2, h: 0.7 } });
  }
  slide.addText("张 伟\n店长", { x: nx + 0.3, y: ny + 1.0, w: 1.5, h: 0.8, fontSize: 11, color: "333333", lineSpacingMultiple: 1.4 });
  slide.addText("138-0000-0000\nshop@brand.com", { x: nx + 1.9, y: ny + 1.2, w: 1.5, h: 0.6, fontSize: 10, color: "888888", lineSpacingMultiple: 1.4, align: "right" });
  slide.addText("名片", { x: nx, y: ny + nh + 0.08, w: nw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 价格标签
  const tw = 2.2, th = 1.4;
  const tx = 1.5, ty = ny + nh + 0.8;
  slide.addShape("rect", { x: tx, y: ty, w: tw, h: th, fill: { color: bc.pri }, rectRadius: 0.06, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: tx + 0.3, y: ty + 0.15, w: 0.6, h: 0.4, sizing: { type: "contain", w: 0.6, h: 0.4 } });
  }
  slide.addText("¥ 99.00", { x: tx, y: ty + 0.65, w: tw, h: 0.4, fontSize: 16, bold: true, color: "FFFFFF", align: "center" });
  // 挂孔
  slide.addShape("ellipse", { x: tx + tw / 2 - 0.08, y: ty - 0.12, w: 0.16, h: 0.16, fill: { color: "FFFFFF" }, line: { color: "CCCCCC", width: 0.5 } });
  slide.addText("价格标签", { x: tx - 0.2, y: ty + th + 0.08, w: tw + 0.4, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 会员卡
  const mw = 2.2, mh = 1.4;
  const mx = 4.5, my = ty;
  slide.addShape("rect", { x: mx, y: my, w: mw, h: mh, fill: { color: bc.pri }, rectRadius: 0.08, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: mx + 0.2, y: my + 0.1, w: 0.7, h: 0.4, sizing: { type: "contain", w: 0.7, h: 0.4 } });
  }
  slide.addText("VIP", { x: mx, y: my + 0.6, w: mw, h: 0.35, fontSize: 16, bold: true, color: "FFFFFF", align: "center" });
  slide.addText("NO. 8888", { x: mx, y: my + 0.95, w: mw, h: 0.25, fontSize: 9, color: "FFFFFF", transparency: 30, align: "center" });
  slide.addText("会员卡", { x: mx - 0.2, y: my + mh + 0.08, w: mw + 0.4, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawRetailPackaging(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 购物袋
  const bw = 3.4, bh = 4.0;
  const bx = 1.0, by = 2.0;
  slide.addShape("rect", { x: bx, y: by, w: bw, h: bh, fill: { color: bc.pri }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 } });
  slide.addShape("line", { x: bx + 0.8, y: by - 0.4, w: 0, h: 0.5, line: { color: bc.priDark, width: 2.5 } });
  slide.addShape("line", { x: bx + bw - 0.8, y: by - 0.4, w: 0, h: 0.5, line: { color: bc.priDark, width: 2.5 } });
  slide.addShape("rect", { x: bx, y: by, w: bw, h: 0.25, fill: { color: bc.priDark }, rectRadius: 0.05 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bx + 0.5, y: by + 0.6, w: 2.4, h: 1.8, sizing: { type: "contain", w: 2.4, h: 1.8 } });
  }
  slide.addText(opts.companyName || "品牌", { x: bx, y: by + 2.6, w: bw, h: 0.4, fontSize: 16, bold: true, color: "FFFFFF", align: "center" });
  slide.addShape("rect", { x: bx + 0.5, y: by + 3.2, w: bw - 1.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("购物袋", { x: bx, y: by + bh + 0.08, w: bw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 包装盒
  const bxW = 3.2, bxH = 3.8;
  const bxX = 5.0, bxY = 2.2;
  slide.addShape("rect", { x: bxX, y: bxY, w: bxW, h: bxH, fill: { color: "FFFFFF" }, rectRadius: 0.1, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: bxX, y: bxY + bxH * 0.25, w: bxW, h: bxH * 0.35, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bxX + 0.6, y: bxY + bxH * 0.25 + 0.2, w: 2.0, h: 1.2, sizing: { type: "contain", w: 2.0, h: 1.2 } });
  }
  slide.addText("产品包装盒", { x: bxX, y: bxY + bxH + 0.08, w: bxW, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawRetailMarketing(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  // 促销海报
  const pw = 4.0, ph = 5.5;
  const px = 0.5, py = 2.0;
  slide.addShape("rect", { x: px, y: py, w: pw, h: ph, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: px, y: py, w: pw, h: ph * 0.45, fill: { color: bc.pri }, rectRadius: 0.05 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: px + 1.0, y: py + 0.4, w: 2.0, h: 1.5, sizing: { type: "contain", w: 2.0, h: 1.5 } });
  }
  slide.addText("限时特惠", { x: px + 0.4, y: py + ph * 0.45 + 0.3, w: pw - 0.8, h: 0.6, fontSize: 20, bold: true, color: "333333" });
  slide.addText("全场满减 · 会员折上折", { x: px + 0.4, y: py + ph * 0.45 + 1.0, w: pw - 0.8, h: 0.4, fontSize: 12, color: "888888" });
  slide.addShape("rect", { x: px + 0.4, y: py + ph * 0.45 + 1.6, w: 1.5, h: 0.04, fill: { color: bc.acc } });
  slide.addText("促销海报", { x: px, y: py + ph + 0.08, w: pw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  // 货架卡
  const sw2 = 2.8, sh2 = 2.0;
  const sx = 5.0, sy = 3.0;
  slide.addShape("rect", { x: sx, y: sy, w: sw2, h: sh2, fill: { color: bc.priLight }, rectRadius: 0.06, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 }, line: { color: bc.pri, width: 1 } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: sx + 0.3, y: sy + 0.15, w: 0.8, h: 0.5, sizing: { type: "contain", w: 0.8, h: 0.5 } });
  }
  slide.addText("热销推荐", { x: sx, y: sy + 0.7, w: sw2, h: 0.35, fontSize: 14, bold: true, color: bc.pri, align: "center" });
  slide.addShape("rect", { x: sx + 0.5, y: sy + 1.15, w: sw2 - 1.0, h: 0.04, fill: { color: bc.acc } });
  slide.addText("店长推荐 · 品质保证", { x: sx, y: sy + 1.3, w: sw2, h: 0.3, fontSize: 10, color: "888888", align: "center" });
  slide.addText("货架卡", { x: sx, y: sy + sh2 + 0.08, w: sw2, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

// ==================== 通用行业 (V4默认) ====================
function drawGeneralStationery(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  const cw = 3.6, ch = 2.2;
  const cx = (SW - cw) / 2, cy = 2.2;
  slide.addShape("rect", { x: cx, y: cy, w: cw, h: ch, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 6, offset: 3, color: "000000", opacity: 0.12 }, line: { color: "E8E8E8", width: 0.3 } });
  slide.addShape("rect", { x: cx, y: cy, w: 0.12, h: ch, fill: { color: bc.pri }, rectRadius: 0.04 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: cx + 0.3, y: cy + 0.25, w: 1.5, h: 0.8, sizing: { type: "contain", w: 1.5, h: 0.8 } });
  }
  slide.addText("张 伟\n品牌总监", { x: cx + 0.3, y: cy + 1.15, w: 1.8, h: 0.8, fontSize: 11, color: "333333", lineSpacingMultiple: 1.4 });
  slide.addText("138-0000-0000\nbrand@company.com", { x: cx + 1.9, y: cy + 1.15, w: 1.5, h: 0.8, fontSize: 10, color: "888888", lineSpacingMultiple: 1.4, align: "right" });
  slide.addText("名片", { x: cx, y: cy + ch + 0.1, w: cw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  const ew = 4.2, eh = 2.4;
  const ex = (SW - ew) / 2, ey = cy + ch + 0.8;
  slide.addShape("rect", { x: ex, y: ey, w: ew, h: eh, fill: { color: "FFFFFF" }, rectRadius: 0.06, shadow: { type: "outer", blur: 5, offset: 2, color: "000000", opacity: 0.1 }, line: { color: "E8E8E8", width: 0.3 } });
  slide.addShape("rect", { x: ex, y: ey, w: ew, h: 0.18, fill: { color: bc.pri }, rectRadius: 0.03 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: ex + ew - 1.5, y: ey + 0.4, w: 1.2, h: 0.6, sizing: { type: "contain", w: 1.2, h: 0.6 }, transparency: 15 });
  }
  slide.addText("收件人信息", { x: ex + 0.4, y: ey + 0.5, w: 2.5, h: 0.4, fontSize: 11, color: "CCCCCC" });
  slide.addText("地址信息", { x: ex + 0.4, y: ey + 1.0, w: 2.5, h: 0.3, fontSize: 10, color: "DDDDDD" });
  slide.addText("信封", { x: ex, y: ey + eh + 0.1, w: ew, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  const lw = 3.6, lh = 1.3;
  const lx = (SW - lw) / 2, ly = ey + eh + 0.7;
  slide.addShape("rect", { x: lx, y: ly, w: lw, h: lh, fill: { color: "FFFFFF" }, rectRadius: 0.04, shadow: { type: "outer", blur: 4, offset: 2, color: "000000", opacity: 0.08 }, line: { color: "E8E8E8", width: 0.3 } });
  slide.addShape("rect", { x: lx, y: ly, w: lw, h: 0.12, fill: { color: bc.pri }, rectRadius: 0.02 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: lx + 0.2, y: ly + 0.3, w: 0.8, h: 0.4, sizing: { type: "contain", w: 0.8, h: 0.4 }, transparency: 20 });
  }
  slide.addText("信纸 / 报信纸", { x: lx, y: ly + lh + 0.1, w: lw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawGeneralPackaging(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  const bw = 3.2, bh = 3.8;
  const bx = (SW - bw) / 2, by = 2.2;
  slide.addShape("rect", { x: bx, y: by, w: bw, h: bh, fill: { color: "FFFFFF" }, rectRadius: 0.1, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: bx, y: by + bh * 0.25, w: bw, h: bh * 0.35, fill: { color: bc.pri } });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bx + 0.6, y: by + bh * 0.25 + 0.2, w: 2.0, h: 1.2, sizing: { type: "contain", w: 2.0, h: 1.2 } });
  }
  slide.addText("产品包装盒", { x: bx, y: by + bh + 0.1, w: bw, h: 0.3, fontSize: 11, color: "999999", align: "center" });

  const bgW = 2.8, bgH = 3.4;
  const bgX = (SW - bgW) / 2, bgY = by + bh + 0.8;
  slide.addShape("rect", { x: bgX, y: bgY, w: bgW, h: bgH, fill: { color: bc.pri }, rectRadius: 0.06, shadow: { type: "outer", blur: 6, offset: 3, color: "000000", opacity: 0.12 } });
  slide.addShape("rect", { x: bgX, y: bgY, w: bgW, h: 0.2, fill: { color: bc.priDark }, rectRadius: 0.03 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: bgX + 0.5, y: bgY + 0.6, w: 1.8, h: 1.2, sizing: { type: "contain", w: 1.8, h: 1.2 }, transparency: 5 });
  }
  slide.addShape("line", { x: bgX + 0.6, y: bgY - 0.3, w: 0, h: 0.5, line: { color: bc.priDark, width: 2 } });
  slide.addShape("line", { x: bgX + bgW - 0.6, y: bgY - 0.3, w: 0, h: 0.5, line: { color: bc.priDark, width: 2 } });
  slide.addText("手提袋 / 外卖袋", { x: bgX, y: bgY + bgH + 0.1, w: bgW, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

function drawGeneralMarketing(slide: PptxGenJS.Slide, bc: BC, opts: RenderPptxOptions): void {
  const pw = 4.0, ph = 5.5;
  const px = (SW - pw) / 2, py = 2.2;
  slide.addShape("rect", { x: px, y: py, w: pw, h: ph, fill: { color: "FFFFFF" }, rectRadius: 0.08, shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.15 }, line: { color: "E0E0E0", width: 0.3 } });
  slide.addShape("rect", { x: px, y: py, w: pw, h: ph * 0.45, fill: { color: bc.pri }, rectRadius: 0.05 });
  if (opts.logoData) {
    slide.addImage({ data: normImg(opts.logoData), x: px + 1.0, y: py + 0.4, w: 2.0, h: 1.5, sizing: { type: "contain", w: 2.0, h: 1.5 }, transparency: 5 });
  }
  slide.addText("品牌主标题", { x: px + 0.4, y: py + ph * 0.45 + 0.3, w: pw - 0.8, h: 0.6, fontSize: 18, bold: true, color: "333333" });
  slide.addText("副标题文字说明", { x: px + 0.4, y: py + ph * 0.45 + 1.0, w: pw - 0.8, h: 0.4, fontSize: 12, color: "888888" });
  slide.addShape("rect", { x: px + 0.4, y: py + ph * 0.45 + 1.8, w: 1.5, h: 0.04, fill: { color: bc.acc } });
  slide.addText("海报 / 宣传页", { x: px, y: py + ph + 0.1, w: pw, h: 0.3, fontSize: 11, color: "999999", align: "center" });
}

// ========== Summary ==========
function renderSummary(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, "总结", bc);
  const vision = fta(bp, ["ph-vision-content","brand-vision-content","vision-content"]);
  if (vision && vision !== "待定") {
    slide.addShape("rect", { x: MARGIN, y: 1.5, w: CONTENT_W, h: 1.2, fill: { color: bc.priLight }, rectRadius: 0.1 });
    slide.addText(`"${vision}"`, { x: MARGIN + 0.3, y: 1.6, w: CONTENT_W - 0.6, h: 1.0, fontSize: 15, italic: true, color: bc.priDark, align: "center", lineSpacingMultiple: 1.5, valign: "middle" });
  }
  const pillars = [
    { label: "一致性", desc: "所有媒介输出必须严格遵守本手册规范，确保品牌在任何触点下都能被精准识别" },
    { label: "专业性", desc: "通过标准化的视觉语言建立客户信任，展现品牌作为行业专家的专业形象" },
    { label: "持续性", desc: "VI 系统是品牌长期发展的核心无形资产，是品牌价值持续积累的视觉载体" },
  ];
  let yPos = 3.2;
  for (let i = 0; i < pillars.length; i++) {
    const p = pillars[i];
    slide.addShape("roundRect", { x: MARGIN + 0.2, y: yPos, w: 0.5, h: 0.5, fill: { color: bc.pri }, rectRadius: 0.25 });
    slide.addText(`${i + 1}`, { x: MARGIN + 0.2, y: yPos, w: 0.5, h: 0.5, fontSize: 14, bold: true, color: "FFFFFF", align: "center", valign: "middle" });
    slide.addText(p.label, { x: MARGIN + 0.9, y: yPos, w: 2.5, h: 0.45, fontSize: 16, bold: true, color: bc.pri });
    slide.addText(p.desc, { x: MARGIN + 0.9, y: yPos + 0.5, w: CONTENT_W - 1.1, h: 0.7, fontSize: 12, color: "555555", lineSpacingMultiple: 1.5 });
    yPos += 1.5;
  }
}

// ========== Generic ==========
function renderGeneric(slide: PptxGenJS.Slide, bp: PageBlueprint, opts: RenderPptxOptions, bc: BC): void {
  addHeader(slide, bp.label || bp.pageId, bc);
  let yPos = 1.8;
  for (const el of bp.elements) {
    if (el.type === "text" && el.content) {
      const fs = el.fontSize ? Math.max(11, Math.round(el.fontSize * 0.7)) : 12;
      slide.addText(el.content, { x: MARGIN, y: yPos, w: CONTENT_W, h: 0.5, fontSize: fs, bold: (el.fontWeight || 400) >= 600, color: "333333" });
      yPos += 0.6;
    }
  }
}

// ========== Helpers ==========
function hx(c: string): string { return c.replace("#", "").toUpperCase(); }
function normImg(d: string): string { return d.startsWith("data:") ? d : `data:image/png;base64,${d}`; }
function darken(hex: string): string {
  const c = hex.replace("#", "");
  const r = Math.max(0, parseInt(c.slice(0, 2), 16) - 60);
  const g = Math.max(0, parseInt(c.slice(2, 4), 16) - 60);
  const b = Math.max(0, parseInt(c.slice(4, 6), 16) - 60);
  return [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("").toUpperCase();
}
function lighten(hex: string): string {
  const c = hex.replace("#", "");
  const r = Math.min(255, parseInt(c.slice(0, 2), 16) + 120);
  const g = Math.min(255, parseInt(c.slice(2, 4), 16) + 120);
  const b = Math.min(255, parseInt(c.slice(4, 6), 16) + 120);
  return [r, g, b].map(v => v.toString(16).padStart(2, "0")).join("").toUpperCase();
}
function isLight(hex: string): boolean {
  const c = hex.replace("#", "");
  if (c.length < 6) return false;
  const r = parseInt(c.slice(0, 2), 16), g = parseInt(c.slice(2, 4), 16), b = parseInt(c.slice(4, 6), 16);
  return (r * 0.299 + g * 0.587 + b * 0.114) > 200;
}
function hex2rgb(hex: string): { r: number; g: number; b: number } | null {
  const c = hex.replace("#", "");
  if (c.length < 6) return null;
  return { r: parseInt(c.slice(0, 2), 16), g: parseInt(c.slice(2, 4), 16), b: parseInt(c.slice(4, 6), 16) };
}
function rgb2cmyk(rgb: { r: number; g: number; b: number }): { c: number; m: number; y: number; k: number } | null {
  const r1 = rgb.r / 255, g1 = rgb.g / 255, b1 = rgb.b / 255;
  const k = 1 - Math.max(r1, g1, b1);
  if (k >= 1) return { c: 0, m: 0, y: 0, k: 100 };
  return { c: Math.round(((1 - r1 - k) / (1 - k)) * 100), m: Math.round(((1 - g1 - k) / (1 - k)) * 100), y: Math.round(((1 - b1 - k) / (1 - k)) * 100), k: Math.round(k * 100) };
}
function fta(bp: PageBlueprint, ids: string[]): string {
  for (const id of ids) { const el = bp.elements.find(e => e.id === id); if (el?.content) return el.content; }
  for (const id of ids) { const el = bp.elements.find(e => e.id?.includes(id)); if (el?.content) return el.content; }
  return "";
}
function extractPhilSections(bp: PageBlueprint): { label: string; content: string }[] {
  const pairs = [
    { ids: ["ph-vision-label","brand-vision-label"], cids: ["ph-vision-content","brand-vision-content","vision-content"], fallback: "品牌愿景", keywords: ["愿景","打造"] },
    { ids: ["ph-values-label","core-values-label"], cids: ["ph-values-content","core-values-content","values-content"], fallback: "核心价值", keywords: ["价值","核心"] },
    { ids: ["ph-market-label","target-market-label"], cids: ["ph-market-content","target-market-content","market-content"], fallback: "目标市场", keywords: ["市场","目标"] },
  ];
  return pairs.map(p => {
    const label = fta(bp, p.ids) || p.fallback;
    let content = fta(bp, p.cids);
    if (!content || content === "待定") {
      for (const el of bp.elements) {
        if (el.type === "text" && el.content) {
          const cl = el.content.toLowerCase();
          if (p.keywords.some(kw => cl.includes(kw))) { content = el.content; break; }
        }
      }
    }
    return { label, content: content || "待品牌方补充" };
  });
}
