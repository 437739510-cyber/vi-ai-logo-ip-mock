/**
 * API: Generate VI Manual PPTX via PptxGenJS Engine V2
 *
 * V2 fixes:
 * - Company name from clientInfo properly passed
 * - Logo/mascot loaded from project data
 * - Better error handling
 */
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { readFile, mkdir, writeFile, readdir, stat } from "fs/promises";
import { planPages } from "@/lib/page-planner";
import { renderPptxToBuffer } from "@/lib/render-pptx";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { projectId, clientInfo, brandColors, logoUrl, mascotUrl } = body;

    if (!projectId) {
      return NextResponse.json({ error: "projectId required" }, { status: 400 });
    }

    const companyName = clientInfo?.companyName || "";

    // Step 1: Load logo/mascot as base64 data URIs
    let logoData: string | null = null;
    let mascotData: string | null = null;
    let mascotSplitViews: string[] | null = null;

    if (logoUrl) {
      logoData = await loadImageAsBase64(logoUrl);
      console.log("[generate-pptx] Logo loaded:", logoUrl, logoData ? "OK" : "FAILED");
    }

    if (mascotUrl) {
      mascotData = await loadImageAsBase64(mascotUrl);
      console.log("[generate-pptx] Mascot loaded:", mascotUrl, mascotData ? "OK" : "FAILED");
      mascotSplitViews = await loadSplitViews(mascotUrl);
    }

    // Step 2: Generate Page Blueprints
    const blueprints = await planPages({
      clientInfo: {
        companyName: companyName || "\u54c1\u724c",
        brandVision: clientInfo?.brandVision || "",
        coreValues: clientInfo?.coreValues || "",
        targetMarket: clientInfo?.targetMarket || "",
        logoPhilosophy: clientInfo?.logoPhilosophy || "",
        mascotPhilosophy: clientInfo?.mascotPhilosophy || "",
        industry: clientInfo?.industry || "",
      },
      brandColors: brandColors || {
        primary: { hex: "#1A73E8" },
        secondary: { hex: "#34A853" },
        accent: { hex: "#FBBC04" },
      },
      assetAnalysis: {
        logo: {
          hasLogo: !!logoUrl,
          logoUrl,
          elements: [],
          styleTags: [],
          meaning: clientInfo?.logoPhilosophy || "",
        },
        mascot: {
          hasMascot: !!mascotUrl,
          mascotUrl,
          isThreeView: false,
          splitViews: [],
          name: "",
          style: "",
          personality: "",
        },
      },
    });

    console.log("[generate-pptx] Blueprints generated:", blueprints.length, "pages");
    console.log("[generate-pptx] Company name:", companyName);
    console.log("[generate-pptx] Logo data:", logoData ? `base64(${logoData.length} chars)` : "null");
    console.log("[generate-pptx] Mascot data:", mascotData ? `base64(${mascotData.length} chars)` : "null");

    // Step 3: Render PPTX
    const buffer = await renderPptxToBuffer(blueprints, {
      projectName: projectId,
      companyName: companyName || "\u54c1\u724c",
      logoData,
      mascotData,
      mascotSplitViews,
    });

    // Step 4: Save file
    const outputDir = path.join(process.cwd(), "public", "generated");
    await mkdir(outputDir, { recursive: true });
    const fileName = `vi-manual-${projectId}-${Date.now()}.pptx`;
    const filePath = path.join(outputDir, fileName);
    await writeFile(filePath, buffer);

    const downloadUrl = `/generated/${fileName}`;

    return NextResponse.json({
      success: true,
      url: downloadUrl,
      pageCount: blueprints.length,
      fileName,
    });
  } catch (error: any) {
    console.error("[generate-pptx] Error:", error);
    return NextResponse.json(
      { error: error.message || "PPTX generation failed" },
      { status: 500 }
    );
  }
}

// ========== Helpers ==========

async function loadImageAsBase64(imagePath: string): Promise<string | null> {
  try {
    // Try multiple path formats
    const candidates = [
      path.join(process.cwd(), "public", imagePath.replace(/^\//, "")),
      path.join(process.cwd(), imagePath),
    ];

    for (const fullPath of candidates) {
      try {
        const buffer = await readFile(fullPath);
        const ext = path.extname(fullPath).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg"
          ? "image/jpeg"
          : ext === ".gif"
          ? "image/gif"
          : ext === ".svg"
          ? "image/svg+xml"
          : "image/png";
        const dataUri = `data:${mime};base64,${buffer.toString("base64")}`;
        console.log(`[loadImage] Success: ${fullPath} (${buffer.length} bytes)`);
        return dataUri;
      } catch {
        // Try next candidate
      }
    }

    // If it's already a URL (http/https), try to fetch it
    if (imagePath.startsWith("http")) {
      try {
        const resp = await fetch(imagePath);
        if (resp.ok) {
          const buffer = Buffer.from(await resp.arrayBuffer());
          const contentType = resp.headers.get("content-type") || "image/png";
          return `data:${contentType};base64,${buffer.toString("base64")}`;
        }
      } catch {
        // fetch failed
      }
    }

    console.warn("[loadImage] All paths failed for:", imagePath);
    return null;
  } catch (e) {
    console.warn("[loadImage] Error:", String(e));
    return null;
  }
}

async function loadSplitViews(mascotUrl: string): Promise<string[] | null> {
  const views: string[] = [];
  const dir = path.dirname(path.join(process.cwd(), "public", mascotUrl.replace(/^\//, "")));
  const baseName = path.basename(mascotUrl, path.extname(mascotUrl));
  const ext = path.extname(mascotUrl);

  for (const suffix of ["-front", "-side", "-back"]) {
    try {
      const viewPath = path.join(dir, `${baseName}${suffix}${ext}`);
      const buffer = await readFile(viewPath);
      const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : "image/png";
      views.push(`data:${mime};base64,${buffer.toString("base64")}`);
    } catch {
      // Split view not found
    }
  }

  return views.length === 3 ? views : null;
}
