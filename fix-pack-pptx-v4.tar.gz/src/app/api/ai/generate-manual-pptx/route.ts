/**
 * API: Generate VI Manual PPTX via PptxGenJS Engine V4
 *
 * V4 核心改动：
 * - route.ts 直接查 Supabase 数据库拿 submission 数据
 * - 不再依赖前端传 brandColors/companyName/logoUrl/mascotUrl
 * - 前端只需传 projectId，后端自己查一切
 * - brandColors 兼容 {hex} 嵌套格式和 string 格式
 * - Logo/Mascot 从 processed-assets 目录和 Supabase Storage 双路查找
 */
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { readFile, mkdir, writeFile, readdir } from "fs/promises";
import { planPages } from "@/lib/page-planner";
import { renderPptxToBuffer } from "@/lib/render-pptx";
import { supabaseAdmin } from "@/lib/supabase";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { projectId } = body;

    if (!projectId) {
      return NextResponse.json({ error: "projectId required" }, { status: 400 });
    }

    // ===== Step 1: 从 Supabase 查 project + submission =====
    const { data: project, error: projErr } = await supabaseAdmin
      .from("projects")
      .select("id, submission_id")
      .eq("id", projectId)
      .single();

    let submission: any = null;
    if (project?.submission_id) {
      const { data: sub, error: subErr } = await supabaseAdmin
        .from("submissions")
        .select("*")
        .eq("id", project.submission_id)
        .single();
      if (!subErr && sub) submission = sub;
    }

    // ===== Step 2: 提取所有数据（前端传入 + DB fallback） =====
    const companyName = body.clientInfo?.companyName || body.clientInfo?.clientName || submission?.company_name || submission?.companyName || "品牌";
    const industry = body.clientInfo?.industry || submission?.industry || "";
    const brandVision = body.clientInfo?.brandVision || submission?.brand_vision || submission?.brandVision || "";
    const coreValues = body.clientInfo?.coreValues || submission?.core_values || submission?.coreValues || "";
    const targetMarket = body.clientInfo?.targetMarket || submission?.target_market || submission?.targetMarket || "";
    const logoPhilosophy = body.clientInfo?.logoPhilosophy || submission?.logo_philosophy || submission?.logoPhilosophy || "";
    const mascotPhilosophy = body.clientInfo?.mascotPhilosophy || submission?.mascot_philosophy || submission?.mascotPhilosophy || "";

    // brandColors: 优先前端传入，其次DB
    const rawColors = body.brandColors || submission?.brand_colors || submission?.brandColors;
    const realColors = normalizeColors(rawColors, industry);

    console.log("[generate-pptx] Company:", companyName);
    console.log("[generate-pptx] Colors:", JSON.stringify(realColors));
    console.log("[generate-pptx] Industry:", industry);
    console.log("[generate-pptx] Vision:", brandVision ? "OK" : "empty");

    // ===== Step 3: 加载 Logo/Mascot =====
    let logoData: string | null = null;
    let mascotData: string | null = null;
    let mascotSplitViews: string[] | null = null;

    // 从前端传入的URL
    if (body.logoUrl) logoData = await loadImg(body.logoUrl);
    // 从processed-assets目录查找
    if (!logoData) logoData = await findAsset(projectId, "logo");
    // 从Supabase Storage查找
    if (!logoData) logoData = await findFromStorage(projectId, "logo");

    if (body.mascotUrl) mascotData = await loadImg(body.mascotUrl);
    if (body.mascotFiles?.length > 0) {
      for (const mf of body.mascotFiles) {
        const url = typeof mf === "string" ? mf : mf.url;
        mascotData = await loadImg(url);
        if (mascotData) break;
      }
    }
    if (!mascotData) mascotData = await findAsset(projectId, "mascot");
    if (!mascotData) mascotData = await findFromStorage(projectId, "mascot");
    if (mascotData) mascotSplitViews = await findSplitViews(projectId);

    console.log("[generate-pptx] Logo:", logoData ? "OK" : "null");
    console.log("[generate-pptx] Mascot:", mascotData ? "OK" : "null");

    // ===== Step 4: 生成蓝图 =====
    const blueprints = await planPages({
      clientInfo: {
        companyName: companyName,
        brandVision,
        coreValues,
        targetMarket,
        logoPhilosophy,
        mascotPhilosophy,
        industry,
      },
      brandColors: {
        primary: { hex: realColors.primary },
        secondary: { hex: realColors.secondary },
        accent: { hex: realColors.accent },
      },
      assetAnalysis: {
        logo: { hasLogo: !!logoData, logoUrl: body.logoUrl || "", elements: [], styleTags: [], meaning: logoPhilosophy },
        mascot: { hasMascot: !!mascotData, mascotUrl: body.mascotUrl || "", isThreeView: !!(mascotSplitViews?.length === 3), splitViews: mascotSplitViews || [], name: "", style: "", personality: "" },
      },
    });

    console.log("[generate-pptx] Blueprints:", blueprints.length, "pages");

    // ===== Step 5: 渲染 PPTX =====
    const buffer = await renderPptxToBuffer(blueprints, {
      projectName: projectId,
      companyName,
      logoData,
      mascotData,
      mascotSplitViews,
      brandColors: realColors,
    });

    // ===== Step 6: 保存文件 =====
    const outputDir = path.join(process.cwd(), "public", "generated");
    await mkdir(outputDir, { recursive: true });
    const fileName = `vi-manual-${projectId}-${Date.now()}.pptx`;
    await writeFile(path.join(outputDir, fileName), buffer);

    return NextResponse.json({
      success: true,
      url: `/generated/${fileName}`,
      pageCount: blueprints.length,
      fileName,
    });
  } catch (error: any) {
    console.error("[generate-pptx] Error:", error);
    return NextResponse.json({ error: error.message || "PPTX generation failed" }, { status: 500 });
  }
}

// ========== Helpers ==========

/** Normalize brandColors — handle BOTH formats from Supabase and TypeScript */
function normalizeColors(colors: any, industry?: string): { primary: string; secondary: string; accent: string } {
  const defaults = { primary: "#1A73E8", secondary: "#34A853", accent: "#FBBC04" };
  if (!colors) return defaults;
  // Format 1: { primary: { hex: "#xxx", name: "..." }, ... } — Supabase snake_case format
  if (colors.primary?.hex) {
    return {
      primary: colors.primary.hex || defaults.primary,
      secondary: colors.secondary?.hex || defaults.secondary,
      accent: colors.accent?.hex || defaults.accent,
    };
  }
  // Format 2: { primary: "#xxx", ... } — TypeScript interface format
  if (typeof colors.primary === "string") {
    return {
      primary: colors.primary || defaults.primary,
      secondary: (typeof colors.secondary === "string" ? colors.secondary : defaults.secondary),
      accent: (typeof colors.accent === "string" ? colors.accent : defaults.accent),
    };
  }
  return defaults;
}

async function loadImg(imagePath: string): Promise<string | null> {
  if (!imagePath) return null;
  const candidates = [
    path.join(process.cwd(), "public", imagePath.replace(/^\//, "")),
    path.join(process.cwd(), imagePath),
  ];
  for (const fp of candidates) {
    try {
      const buf = await readFile(fp);
      const ext = path.extname(fp).toLowerCase();
      const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".gif" ? "image/gif" : ext === ".svg" ? "image/svg+xml" : "image/png";
      return `data:${mime};base64,${buf.toString("base64")}`;
    } catch { /* next */ }
  }
  if (imagePath.startsWith("http")) {
    try {
      const resp = await fetch(imagePath);
      if (resp.ok) {
        const buf = Buffer.from(await resp.arrayBuffer());
        const ct = resp.headers.get("content-type") || "image/png";
        return `data:${ct};base64,${buf.toString("base64")}`;
      }
    } catch { /* fail */ }
  }
  return null;
}

async function findAsset(projectId: string, type: "logo" | "mascot"): Promise<string | null> {
  try {
    const dir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(dir);
    const keywords = type === "logo" ? ["logo", "logo-processed"] : ["mascot", "ip", "character"];
    for (const file of files) {
      const lower = file.toLowerCase();
      if (keywords.some(k => lower.includes(k))) {
        const buf = await readFile(path.join(dir, file));
        const ext = path.extname(file).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        return `data:${mime};base64,${buf.toString("base64")}`;
      }
    }
  } catch { /* dir not found */ }
  return null;
}

/** 从 Supabase Storage 查找资产 */
async function findFromStorage(projectId: string, type: "logo" | "mascot"): Promise<string | null> {
  try {
    const prefix = `${projectId}/${type}`;
    const { data, error } = await supabaseAdmin.storage
      .from("processed-assets")
      .list(prefix, { limit: 5 });

    if (error || !data || data.length === 0) return null;

    const file = data[0];
    const filePath = `${prefix}/${file.name}`;
    const { data: urlData } = supabaseAdmin.storage
      .from("processed-assets")
      .getPublicUrl(filePath);

    if (urlData?.publicUrl) {
      return await loadImg(urlData.publicUrl);
    }
  } catch { /* storage not configured */ }
  return null;
}

async function findSplitViews(projectId: string): Promise<string[] | null> {
  try {
    const dir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(dir);
    const views: string[] = [];
    for (const suffix of ["-front", "-side", "-back"]) {
      for (const file of files) {
        if (file.toLowerCase().includes(`mascot${suffix}`) || file.toLowerCase().includes(`ip${suffix}`)) {
          const buf = await readFile(path.join(dir, file));
          const ext = path.extname(file).toLowerCase();
          const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : "image/png";
          views.push(`data:${mime};base64,${buf.toString("base64")}`);
          break;
        }
      }
    }
    return views.length === 3 ? views : null;
  } catch { return null; }
}
