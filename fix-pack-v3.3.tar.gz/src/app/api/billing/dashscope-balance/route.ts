/**
 * DashScope / 通义万相 Account Status V3
 * DashScope 没有公开的余额查询API，改为轻量测试调用验证Key有效
 * 兼容 DASHSCOPE_API_KEY / ALIYUN_API_KEY / WANXIANG_API_KEY 三种变量名
 */
import { NextResponse } from 'next/server';

export async function GET() {
  // Try multiple env var names for compatibility
  const apiKey = process.env.DASHSCOPE_API_KEY 
    || process.env.ALIYUN_API_KEY 
    || process.env.WANXIANG_API_KEY;
    
  if (!apiKey) {
    return NextResponse.json({
      availableAmount: null,
      availableCashAmount: null,
      currency: 'CNY',
      source: 'error',
      error: '通义万相 API Key 未配置，请设置 ALIYUN_API_KEY 环境变量',
    }, { status: 503 });
  }

  try {
    // Use OpenAI-compatible endpoint for a minimal test call
    const res = await fetch('https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'qwen-turbo',
        messages: [{ role: 'user', content: 'hi' }],
        max_tokens: 1,
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (!res.ok) {
      const errText = await res.text();
      console.error('[dashscope-balance] Test call error:', res.status, errText);
      
      let errorMsg = `通义万相 API 返回错误 (${res.status})`;
      try {
        const errData = JSON.parse(errText);
        if (errData.error?.message) {
          if (errData.error.message.includes('InvalidApiKey') || errData.error.message.includes('invalid api-key')) {
            errorMsg = 'API Key 无效';
          } else if (errData.error.message.includes('quota') || errData.error.message.includes('Quota')) {
            errorMsg = '免费额度已用完，请充值';
          } else {
            errorMsg = errData.error.message;
          }
        }
      } catch {}
      
      return NextResponse.json({
        availableAmount: null,
        availableCashAmount: null,
        currency: 'CNY',
        source: 'error',
        error: errorMsg,
      }, { status: 503 });
    }

    // Key works! 
    const data = await res.json();
    
    return NextResponse.json({
      availableAmount: null, // DashScope has no balance query API
      availableCashAmount: null,
      currency: 'CNY',
      source: 'dashscope_test',
      status: 'active',
      message: 'API Key 已配置且可用',
      model: data.model || 'qwen-turbo',
    });
  } catch (err: any) {
    console.error('[dashscope-balance] Request failed:', err);
    return NextResponse.json({
      availableAmount: null,
      availableCashAmount: null,
      currency: 'CNY',
      source: 'error',
      error: '连接失败: ' + (err.message || '未知错误'),
    }, { status: 503 });
  }
}
