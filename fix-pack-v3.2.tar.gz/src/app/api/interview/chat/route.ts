import { NextRequest, NextResponse } from "next/server";

const DEEPSEEK_API_KEY = process.env.DEEPSEEK_API_KEY || "";
const DEEPSEEK_URL = "https://api.deepseek.com/v1/chat/completions";

const SYSTEM_PROMPT = `你是一位经验丰富的品牌顾问，正在跟一位小店老板做品牌访谈。

你的目标：
- 用聊天的方式，挖出客人"有但自己不知道"的品牌资产
- 每次只问一个问题，等客人回答
- 语言要像朋友聊天，接地气，不要用专业术语
- 根据客人的回答追问细节，不要机械地按顺序问

访谈重点（按优先级）：
1. 品牌故事：这家店有什么特别的故事？为什么叫这个名字？
2. 差异化：跟同行比，最不一样的地方是什么？
3. 客人怎么说：回头客最常夸你什么？
4. 品牌个性：如果品牌是一个人，是什么性格？
5. 视觉偏好：有没有喜欢的风格？或者特别讨厌的风格？
6. 情感连接：客人对这家店有什么感情？

规则：
- 每条回复控制在2-3句话
- 不要一次问多个问题
- 客人回答简短时，鼓励多说一点
- 客人说不出来时，换个角度问（比如：那客人怎么评价你？）
- 6-8轮对话后，如果信息足够了，用"好的，我觉得已经了解得差不多了！"结束
- 结束时最后一句话必须是：[访谈完成]`;

const MAX_ROUNDS = 10;
const DONE_SIGNAL = "[访谈完成]";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { messages, projectId } = body;

    if (!messages || !Array.isArray(messages)) {
      return NextResponse.json({ error: "缺少消息" }, { status: 400 });
    }

    // 计算用户消息数（判断轮数）
    const userCount = messages.filter((m: { role: string }) => m.role === "user").length;

    const apiMessages = [
      { role: "system", content: SYSTEM_PROMPT },
      ...messages,
    ];

    // 如果没有DeepSeek Key，用本地逻辑
    if (!DEEPSEEK_API_KEY) {
      return localFallback(userCount);
    }

    const response = await fetch(DEEPSEEK_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${DEEPSEEK_API_KEY}`,
      },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: apiMessages,
        max_tokens: 200,
        temperature: 0.7,
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      console.error("DeepSeek error:", errText);
      return localFallback(userCount);
    }

    const data = await response.json();
    let aiMessage = data.choices?.[0]?.message?.content || "嗯，能再多说一点吗？";

    // 检查是否访谈完成
    const done = aiMessage.includes(DONE_SIGNAL) || userCount >= MAX_ROUNDS;
    aiMessage = aiMessage.replace(DONE_SIGNAL, "").trim();

    // 如果轮数到了但AI没主动结束，手动加结束语
    if (userCount >= MAX_ROUNDS && !done) {
      aiMessage += "\n\n好的，我觉得已经了解得差不多了！你的品牌故事很打动人，我会好好帮你想办法让它被更多人看到。";
    }

    return NextResponse.json({
      message: aiMessage,
      done: done || userCount >= MAX_ROUNDS,
    });
  } catch (error) {
    console.error("Interview API error:", error);
    return NextResponse.json(
      { error: "服务器错误" },
      { status: 500 }
    );
  }
}

// 本地降级：没有DeepSeek Key时用预设问题
function localFallback(userCount: number) {
  const questions = [
    "你的店有什么特别的故事吗？为什么做这一行？",
    "跟同行比起来，你觉得你最不一样的地方是什么？",
    "回头客最常夸你什么？他们为什么愿意再来？",
    "如果用一句话形容你的店，你会怎么说？",
    "有没有什么风格是你特别喜欢的？或者特别不想要的？",
    "你觉得客人对你这家店是什么感情？",
    "有没有什么遗憾，觉得品牌做得不够好的地方？",
    "如果给你一次重新来过的机会，你最想改什么？",
  ];

  const idx = Math.min(userCount, questions.length - 1);
  const done = userCount >= 6;

  return NextResponse.json({
    message: done
      ? "好的，我觉得已经了解得差不多了！你的品牌故事很打动人，我会好好帮你想办法让它被更多人看到。"
      : questions[idx],
    done,
  });
}
