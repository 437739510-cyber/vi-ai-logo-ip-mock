"use client";

import { useState } from "react";
import Link from "next/link";

export default function StudentRegisterPage() {
  const [form, setForm] = useState({
    phone: "",
    password: "",
    realName: "",
    university: "",
    major: "",
    grade: "",
    wechat: "",
    serviceArea: "",
  });
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<{ success: boolean; message: string } | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setResult(null);

    try {
      const res = await fetch("/api/student/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      setResult(data);
    } catch {
      setResult({ success: false, message: "网络错误，请重试" });
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (field: string, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* 头部 */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-neutral-900">大学生加入</h1>
          <p className="mt-2 text-neutral-500">拍照、代发、地图标注，轻松赚生活费</p>
        </div>

        {/* 注册成功提示 */}
        {result?.success && (
          <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-xl text-green-700 text-center">
            <div className="text-2xl mb-1">🎉</div>
            <div className="font-medium">注册成功！</div>
            <div className="text-sm mt-1">等待审核通过后即可接单</div>
          </div>
        )}

        {/* 注册表单 */}
        <form onSubmit={handleSubmit} className="bg-white rounded-2xl shadow-sm border border-neutral-100 p-6 space-y-4">
          {/* 手机号 */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">手机号 *</label>
            <input
              type="tel"
              required
              placeholder="用于登录"
              value={form.phone}
              onChange={(e) => handleChange("phone", e.target.value)}
              className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* 密码 */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">密码 *</label>
            <input
              type="password"
              required
              minLength={6}
              placeholder="至少6位"
              value={form.password}
              onChange={(e) => handleChange("password", e.target.value)}
              className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* 姓名 */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">真实姓名 *</label>
            <input
              type="text"
              required
              placeholder="发工资用"
              value={form.realName}
              onChange={(e) => handleChange("realName", e.target.value)}
              className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* 学校 */}
          <div>
            <label className="block text-sm font-medium text-neutral-700 mb-1">学校 *</label>
            <input
              type="text"
              required
              placeholder="你所在的大学"
              value={form.university}
              onChange={(e) => handleChange("university", e.target.value)}
              className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          {/* 专业 + 年级 */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">专业</label>
              <input
                type="text"
                placeholder="如：视觉传达"
                value={form.major}
                onChange={(e) => handleChange("major", e.target.value)}
                className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">年级</label>
              <select
                value={form.grade}
                onChange={(e) => handleChange("grade", e.target.value)}
                className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent bg-white"
              >
                <option value="">选择年级</option>
                <option value="大一">大一</option>
                <option value="大二">大二</option>
                <option value="大三">大三</option>
                <option value="大四">大四</option>
                <option value="研一">研一</option>
                <option value="研二">研二</option>
                <option value="研三">研三</option>
              </select>
            </div>
          </div>

          {/* 微信 + 服务区域 */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">微信</label>
              <input
                type="text"
                placeholder="方便联系"
                value={form.wechat}
                onChange={(e) => handleChange("wechat", e.target.value)}
                className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-neutral-700 mb-1">服务区域</label>
              <input
                type="text"
                placeholder="如：海口龙华区"
                value={form.serviceArea}
                onChange={(e) => handleChange("serviceArea", e.target.value)}
                className="w-full px-4 py-2.5 border border-neutral-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>

          {/* 错误提示 */}
          {result && !result.success && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-red-600 text-sm">
              {result.message}
            </div>
          )}

          {/* 提交按钮 */}
          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 bg-blue-600 text-white font-medium rounded-xl hover:bg-blue-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? "提交中..." : "注册"}
          </button>

          {/* 工资说明 */}
          <div className="mt-4 p-3 bg-neutral-50 rounded-xl">
            <div className="text-xs font-medium text-neutral-500 mb-2">💰 你能赚多少</div>
            <div className="grid grid-cols-2 gap-1 text-xs text-neutral-600">
              <span>📸 上门拍照</span><span className="text-right font-medium">50元/次</span>
              <span>📍 地图标注</span><span className="text-right font-medium">30元/套</span>
              <span>📱 社交代发</span><span className="text-right font-medium">10元/条</span>
              <span>📦 物料配送</span><span className="text-right font-medium">20元/次</span>
              <span>🛠 现场支持</span><span className="text-right font-medium">30元/时</span>
            </div>
          </div>
        </form>

        {/* 返回首页 */}
        <div className="text-center mt-6">
          <Link href="/" className="text-sm text-neutral-400 hover:text-neutral-600">
            ← 返回首页
          </Link>
        </div>
      </div>
    </div>
  );
}
