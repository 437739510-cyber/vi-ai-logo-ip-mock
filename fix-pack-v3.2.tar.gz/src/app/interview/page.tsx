"use client";

import { useState, useRef, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";

type ChatMessage = {
  role: "ai" | "user";
  content: string;
};

function InterviewChat() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const prefillProjectId = searchParams.get("projectId") || "";
  const prefillName = searchParams.get("name") || "";
  const prefillCompany = searchParams.get("company") || "";
  const prefillPhone = searchParams.get("phone") || "";
  const prefillIndustry = searchParams.get("industry") || "";

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [interviewDone, setInterviewDone] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setMessages([
      {
        role: "ai",
        content:
          "嗨！我是品牌大脑的AI顾问 🧠\n\n刚才你填的基本信息我收到了，接下来我想跟你聊聊天，帮你把藏在心底的品牌故事挖出来。\n\n不用想太多，想到什么说什么就好。",
      },
      {
        role: "ai",
        content: "第一个问题：你的店开了多久了？当初为什么想做这个？",
      },
    ]);
  }, []);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, loading]);

  // 访谈完成后自动提交需求
  useEffect(() => {
    if (!interviewDone || submitted) return;

    const submitData = async () => {
      setSubmitting(true);
      try {
        // 从聊天记录中提取品牌信息
        const chatText = messages
          .map((m) => (m.role === "user" ? "客户：" : "AI：") + m.content)
          .join("\n");

        const res = await fetch("/api/submit", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            clientName: prefillName,
            companyName: prefillCompany,
            phone: prefillPhone,
            industry: prefillIndustry,
            description: chatText,
            // 把访谈内容作为品牌素材传入
            brandVision: "",
            coreValues: "",
            targetMarket: "",
            interviewTranscript: chatText,
          }),
        });

        const data = await res.json();
        if (data.success) {
          console.log("提交成功，projectId:", data.projectId);
        }
        setSubmitted(true);
      } catch (e) {
        console.error("提交失败:", e);
        setSubmitted(true); // 即使失败也允许用户继续
      } finally {
        setSubmitting(false);
      }
    };

    // 延迟2秒提交，让用户看到完成提示
    const timer = setTimeout(submitData, 2000);
    return () => clearTimeout(timer);
  }, [interviewDone, submitted]);

  const sendMessage = async () => {
    if (!input.trim() || loading) return;
    const userMsg = input.trim();
    setInput("");
    setMessages((prev) => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const chatHistory = messages
        .filter((m) => m.role === "user" || m.role === "ai")
        .map((m) => ({ role: m.role === "ai" ? "assistant" : "user", content: m.content }));

      chatHistory.push({ role: "user", content: userMsg });

      const res = await fetch("/api/interview/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          messages: chatHistory,
          projectId: prefillProjectId,
        }),
      });

      const data = await res.json();
      const aiReply = data.message || "嗯，我理解了。能再多说一点吗？";
      setMessages((prev) => [...prev, { role: "ai", content: aiReply }]);

      if (data.done) {
        setInterviewDone(true);
      }
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "ai", content: "网络好像有点问题，再试一次？" },
      ]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      {/* 顶部 */}
      <div className="bg-white border-b border-neutral-100 px-4 py-3 flex items-center gap-3 sticky top-0 z-10">
        <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm font-bold">
          脑
        </div>
        <div>
          <div className="text-sm font-medium text-neutral-900">品牌访谈</div>
          <div className="text-xs text-green-500">AI在线</div>
        </div>
        <div className="ml-auto">
          <button
            onClick={() => router.push("/")}
            className="text-xs text-neutral-400 hover:text-neutral-600"
          >
            退出
          </button>
        </div>
      </div>

      {/* 聊天区域 */}
      <div className="flex-1 overflow-y-auto px-4 py-6 max-w-2xl mx-auto w-full">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`mb-4 flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
          >
            {msg.role === "ai" && (
              <div className="w-7 h-7 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold mr-2 mt-1 shrink-0">
                脑
              </div>
            )}
            <div
              className={`max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed whitespace-pre-line ${
                msg.role === "user"
                  ? "bg-blue-600 text-white rounded-br-md"
                  : "bg-white text-neutral-800 shadow-sm border border-neutral-100 rounded-bl-md"
              }`}
            >
              {msg.content}
            </div>
          </div>
        ))}

        {loading && (
          <div className="mb-4 flex justify-start">
            <div className="w-7 h-7 bg-blue-600 rounded-full flex items-center justify-center text-white text-xs font-bold mr-2 mt-1 shrink-0">
              脑
            </div>
            <div className="bg-white px-4 py-3 rounded-2xl rounded-bl-md shadow-sm border border-neutral-100">
              <div className="flex gap-1">
                <span
                  className="w-2 h-2 bg-neutral-300 rounded-full animate-bounce"
                  style={{ animationDelay: "0ms" }}
                />
                <span
                  className="w-2 h-2 bg-neutral-300 rounded-full animate-bounce"
                  style={{ animationDelay: "150ms" }}
                />
                <span
                  className="w-2 h-2 bg-neutral-300 rounded-full animate-bounce"
                  style={{ animationDelay: "300ms" }}
                />
              </div>
            </div>
          </div>
        )}

        <div ref={chatEndRef} />
      </div>

      {/* 访谈完成提示 */}
      {interviewDone && (
        <div className="bg-green-50 border-t border-green-200 px-4 py-4 text-center">
          <div className="text-sm text-green-700 font-medium">🎉 品牌访谈完成！</div>
          <div className="text-xs text-green-600 mt-1">
            {submitting ? "正在提交您的品牌信息..." : "您的品牌信息已提交，我们将在1-2个工作日内联系您。"}
          </div>
          <button
            onClick={() => router.push("/")}
            className="mt-3 px-6 py-2 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700"
          >
            返回首页
          </button>
        </div>
      )}

      {/* 输入区域 */}
      {!interviewDone && (
        <div className="bg-white border-t border-neutral-100 px-4 py-4">
          <div className="max-w-2xl mx-auto flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && sendMessage()}
              placeholder="想到什么说什么..."
              className="flex-1 px-4 py-3 border border-neutral-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
              disabled={loading}
              autoFocus
            />
            <button
              onClick={sendMessage}
              disabled={loading || !input.trim()}
              className="px-5 py-3 bg-blue-600 text-white rounded-xl text-sm font-medium hover:bg-blue-700 disabled:opacity-50"
            >
              发送
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function InterviewPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center text-neutral-400">加载中...</div>}>
      <InterviewChat />
    </Suspense>
  );
}
