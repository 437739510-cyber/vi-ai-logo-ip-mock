/**
 * API: Generate VI Manual PPTX via PptxGenJS Engine V6
 *
 * V6 核心改动（在V5基础上）：
 * - 修复品牌色：brand_colors为null时按行业给默认色（不再用Google蓝）
 * - DeepSeek优化通义万相prompt（1次API调用，7个prompt一起优化）
 * - 通义万相生成7张写实场景图（3张wan2.6高清 + 4张turbo快速）
 * - 传递所有品牌数据+7张写实图到渲染器
 * - 降级策略：图片生成失败3次重试，全部失败回退色块方案
 */
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { readFile, mkdir, writeFile, readdir } from "fs/promises";
import { planPages } from "@/lib/page-planner";
import { renderPptxToBuffer } from "@/lib/render-pptx";
import { supabaseAdmin } from "@/lib/supabase";

export const dynamic = "force-dynamic";
export const maxDuration = 300;

// ========== 行业场景图定义 ==========
type IndustryType = "restaurant" | "beverage" | "beauty" | "retail" | "education" | "general";

interface SceneImgDef {
  key: string;        // e.g. "stationery-1"
  model: string;      // "wanx2.6-image" | "wanx2.1-t2i-turbo"
  rawPrompt: string;  // 英文base prompt
  page: string;       // "stationery" | "packaging" | "marketing"
}

function getIndustryType(industry?: string): IndustryType {
  if (!industry) return "general";
  const s = industry.toLowerCase();
  if (/餐|食|面|火锅|烧烤|烘焙|饺子|包子|炒菜|饭店|小吃|饭馆|海鲜|川菜|粤菜|湘菜|鲁菜|馆|椰岛/.test(s)) return "restaurant";
  if (/茶|咖啡|饮|奶茶|果汁|酒|酒吧|饮品|奶茶店/.test(s)) return "beverage";
  if (/美容|美发|理发|美甲|spa|沙龙|造型|护肤|美体|美睫/.test(s)) return "beauty";
  if (/零售|超市|便利|商店|杂货|服装|鞋|饰品|母婴|数码/.test(s)) return "retail";
  if (/教育|培训|学|课|幼儿园|托管|辅导/.test(s)) return "education";
  return "general";
}

const SCENE_IMG_DEFS: Record<IndustryType, SceneImgDef[]> = {
  restaurant: [
    { key: "stationery-1", model: "wanx2.6-image", page: "stationery", rawPrompt: "Professional product photography of a restaurant napkin sleeve and chopstick cover set, placed on a wooden table, clean minimalist design with subtle brand color accents, studio lighting, top-down angle, no text no letters no watermark, blank space for logo placement" },
    { key: "stationery-2", model: "wanx2.1-t2i-turbo", page: "stationery", rawPrompt: "Professional product photography of a restaurant staff apron hanging on a hook, clean design with brand color trim, soft studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-1", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a food delivery paper bag standing on a surface, minimalist design with brand color stripe, clean studio background, side angle view, no text no letters no watermark, blank space for logo placement" },
    { key: "packaging-2", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a takeout food container box with lid, placed on clean surface, brand color accent on packaging, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-3", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a restaurant menu cover, closed on a table, elegant minimalist design with brand color edge, soft lighting, no text no letters no watermark, blank space for logo" },
    { key: "marketing-1", model: "wanx2.6-image", page: "marketing", rawPrompt: "Professional product photography of a promotional standee poster display in a restaurant, brand color theme, studio setting, no text no letters no watermark, blank space for logo and headline" },
    { key: "marketing-2", model: "wanx2.1-t2i-turbo", page: "marketing", rawPrompt: "Professional product photography of a restaurant review card and table stand on a dining table, clean minimal design, brand color accent, studio lighting, no text no letters no watermark, blank space for logo" },
  ],
  beverage: [
    { key: "stationery-1", model: "wanx2.6-image", page: "stationery", rawPrompt: "Professional product photography of a takeaway cup with cup sleeve, clean minimalist design with brand color pattern, studio lighting, angled view, no text no letters no watermark, blank space for logo placement" },
    { key: "stationery-2", model: "wanx2.1-t2i-turbo", page: "stationery", rawPrompt: "Professional product photography of a barista apron, clean design with brand color trim, soft studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-1", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a branded paper tote bag standing upright, minimalist design with brand color, clean studio background, no text no letters no watermark, blank space for logo" },
    { key: "packaging-2", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a beverage delivery packaging box, clean design with brand color stripe, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-3", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a price menu board for a beverage shop, clean minimal design with brand color, studio setting, no text no letters no watermark, blank space for text" },
    { key: "marketing-1", model: "wanx2.6-image", page: "marketing", rawPrompt: "Professional product photography of a promotional poster for a tea shop, brand color theme, studio setting, no text no letters no watermark, blank space for headline and logo" },
    { key: "marketing-2", model: "wanx2.1-t2i-turbo", page: "marketing", rawPrompt: "Professional product photography of a membership card for a beverage brand, brand color gradient, clean studio background, no text no letters no watermark, blank space for logo" },
  ],
  beauty: [
    { key: "stationery-1", model: "wanx2.6-image", page: "stationery", rawPrompt: "Professional product photography of a beauty product bottle and packaging box set, elegant minimalist design with brand color, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "stationery-2", model: "wanx2.1-t2i-turbo", page: "stationery", rawPrompt: "Professional product photography of a beauty salon appointment card, clean minimal design, brand color accent, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-1", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a branded gift bag with ribbon handles, elegant minimalist design, brand color theme, studio background, no text no letters no watermark, blank space for logo" },
    { key: "packaging-2", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a beauty product label on a jar, clean design with brand color border, studio lighting, no text no letters no watermark, blank space for text" },
    { key: "packaging-3", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a VIP membership card with elegant design, brand color gradient, clean background, no text no letters no watermark, blank space for logo" },
    { key: "marketing-1", model: "wanx2.6-image", page: "marketing", rawPrompt: "Professional product photography of a beauty salon promotional poster, brand color theme, elegant and luxurious style, studio setting, no text no letters no watermark, blank space for headline" },
    { key: "marketing-2", model: "wanx2.1-t2i-turbo", page: "marketing", rawPrompt: "Professional product photography of a beauty service price list menu, clean minimal design, brand color accent, studio lighting, no text no letters no watermark, blank space for text" },
  ],
  retail: [
    { key: "stationery-1", model: "wanx2.6-image", page: "stationery", rawPrompt: "Professional product photography of a business card mockup, clean minimalist design with brand color edge, studio lighting, angled view, no text no letters no watermark, blank space for logo" },
    { key: "stationery-2", model: "wanx2.1-t2i-turbo", page: "stationery", rawPrompt: "Professional product photography of a retail price tag with hanging string, brand color accent, clean studio background, no text no letters no watermark, blank space for text" },
    { key: "packaging-1", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a branded shopping bag with handles, standing on surface, minimalist design with brand color, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-2", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a product packaging box, clean elegant design with brand color band, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-3", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a gift wrapping paper with brand color pattern, studio setting, no text no letters no watermark, blank space for logo" },
    { key: "marketing-1", model: "wanx2.6-image", page: "marketing", rawPrompt: "Professional product photography of a retail promotional poster display, brand color theme, modern clean style, studio setting, no text no letters no watermark, blank space for headline" },
    { key: "marketing-2", model: "wanx2.1-t2i-turbo", page: "marketing", rawPrompt: "Professional product photography of a retail shelf display card, brand color accent, clean studio background, no text no letters no watermark, blank space for text" },
  ],
  education: [
    { key: "stationery-1", model: "wanx2.6-image", page: "stationery", rawPrompt: "Professional product photography of a school name card and ID badge, clean design with brand color, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "stationery-2", model: "wanx2.1-t2i-turbo", page: "stationery", rawPrompt: "Professional product photography of an education institution letterhead paper, brand color header stripe, studio setting, no text no letters no watermark, blank space for text" },
    { key: "packaging-1", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a branded tote bag for education, brand color design, clean studio background, no text no letters no watermark, blank space for logo" },
    { key: "packaging-2", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a course material folder, brand color accent, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-3", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a branded envelope, brand color stripe, clean studio background, no text no letters no watermark, blank space for address" },
    { key: "marketing-1", model: "wanx2.6-image", page: "marketing", rawPrompt: "Professional product photography of an education enrollment promotional poster, brand color theme, inspiring style, studio setting, no text no letters no watermark, blank space for headline" },
    { key: "marketing-2", model: "wanx2.1-t2i-turbo", page: "marketing", rawPrompt: "Professional product photography of a campus event banner stand, brand color design, studio lighting, no text no letters no watermark, blank space for text" },
  ],
  general: [
    { key: "stationery-1", model: "wanx2.6-image", page: "stationery", rawPrompt: "Professional product photography of a business card mockup, clean minimalist design with brand color edge, studio lighting, angled view, no text no letters no watermark, blank space for logo" },
    { key: "stationery-2", model: "wanx2.1-t2i-turbo", page: "stationery", rawPrompt: "Professional product photography of a company letterhead paper, brand color header, studio setting, no text no letters no watermark, blank space for text" },
    { key: "packaging-1", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a branded tote bag, standing upright, minimalist design with brand color, clean studio background, no text no letters no watermark, blank space for logo" },
    { key: "packaging-2", model: "wanx2.6-image", page: "packaging", rawPrompt: "Professional product photography of a product packaging box, clean elegant design with brand color band, studio lighting, no text no letters no watermark, blank space for logo" },
    { key: "packaging-3", model: "wanx2.1-t2i-turbo", page: "packaging", rawPrompt: "Professional product photography of a branded envelope, brand color stripe, clean studio background, no text no letters no watermark, blank space for address" },
    { key: "marketing-1", model: "wanx2.6-image", page: "marketing", rawPrompt: "Professional product photography of a corporate promotional poster, brand color theme, modern professional style, studio setting, no text no letters no watermark, blank space for headline" },
    { key: "marketing-2", model: "wanx2.1-t2i-turbo", page: "marketing", rawPrompt: "Professional product photography of a company ID badge and lanyard, brand color accent, studio lighting, no text no letters no watermark, blank space for photo and name" },
  ],
};

// ========== 行业默认色 ==========
const INDUSTRY_DEFAULTS: Record<string, { primary: string; secondary: string; accent: string }> = {
  restaurant:  { primary: "#2E7D32", secondary: "#E65100", accent: "#F9A825" },
  beverage:    { primary: "#00695C", secondary: "#D84315", accent: "#FFB300" },
  beauty:      { primary: "#AD1457", secondary: "#6A1B9A", accent: "#F48FB1" },
  retail:      { primary: "#1565C0", secondary: "#EF6C00", accent: "#78909C" },
  education:   { primary: "#283593", secondary: "#00897B", accent: "#FF8F00" },
  general:     { primary: "#37474F", secondary: "#00897B", accent: "#FFB300" },
};

function getIndustryDefaults(industry?: string): { primary: string; secondary: string; accent: string } {
  if (!industry) return INDUSTRY_DEFAULTS.general;
  const s = industry.toLowerCase();
  if (/餐|食|面|火锅|烧烤|烘焙|饺子|包子|炒菜|饭店|小吃|饭馆|海鲜|川菜|粤菜|湘菜|鲁菜|馆|椰岛/.test(s)) return INDUSTRY_DEFAULTS.restaurant;
  if (/茶|咖啡|饮|奶茶|果汁|酒|酒吧|饮品/.test(s)) return INDUSTRY_DEFAULTS.beverage;
  if (/美容|美发|理发|美甲|spa|沙龙|造型|护肤/.test(s)) return INDUSTRY_DEFAULTS.beauty;
  if (/零售|超市|便利|商店|服装|饰品/.test(s)) return INDUSTRY_DEFAULTS.retail;
  if (/教育|培训|学|课|幼儿园/.test(s)) return INDUSTRY_DEFAULTS.education;
  return INDUSTRY_DEFAULTS.general;
}

function normalizeColors(colors: any, industry?: string): { primary: string; secondary: string; accent: string } {
  const defaults = getIndustryDefaults(industry);
  if (!colors) return defaults;

  // Format 1: { primary: { hex: "#xxx" }, ... }
  if (colors.primary?.hex) {
    return {
      primary: colors.primary.hex || defaults.primary,
      secondary: colors.secondary?.hex || defaults.secondary,
      accent: colors.accent?.hex || defaults.accent,
    };
  }
  // Format 2: { primary: "#xxx", ... }
  if (typeof colors.primary === "string" && colors.primary) {
    return {
      primary: colors.primary || defaults.primary,
      secondary: (typeof colors.secondary === "string" ? colors.secondary : defaults.secondary) || defaults.secondary,
      accent: (typeof colors.accent === "string" ? colors.accent : defaults.accent) || defaults.accent,
    };
  }
  // Format 3: Array
  if (Array.isArray(colors) && colors.length > 0) {
    return {
      primary: colors[0]?.hex || colors[0] || defaults.primary,
      secondary: (colors[1]?.hex || colors[1] || defaults.secondary) as string,
      accent: (colors[2]?.hex || colors[2] || defaults.accent) as string,
    };
  }
  return defaults;
}

// ========== DeepSeek Prompt 优化 ==========
async function optimizePromptsWithDeepSeek(
  rawPrompts: string[],
  brandData: { name: string; industry: string; colors: string; vision: string }
): Promise<string[]> {
  const apiKey = process.env.DEEPSEEK_API_KEY;
  if (!apiKey) {
    console.log("[optimizePrompts] No DEEPSEEK_API_KEY, using raw prompts");
    return rawPrompts;
  }

  try {
    const systemPrompt = `You are an expert at writing image generation prompts for AI art tools (Alibaba Tongyi Wanxiang).
Given brand info and raw scene descriptions, write precise English prompts for realistic product photography mockups.
Rules:
1. Highly detailed with lighting, angle, material, composition descriptions
2. NO text, letters, or words in generated images - text overlaid later
3. Clean professional studio settings
4. Include brand color references
5. Add "no text, no letters, no watermark, blank space for logo" in every prompt
6. 50-100 words per prompt
7. Return exactly the same number of prompts, one per line, no numbering`;

    const userPrompt = `Brand: ${brandData.name}\nIndustry: ${brandData.industry}\nBrand Colors: ${brandData.colors}\nVision: ${brandData.vision}\n\nRaw prompts:\n${rawPrompts.map((p, i) => `${i + 1}. ${p}`).join("\n")}\n\nOptimized prompts:`;

    const resp = await fetch("https://api.deepseek.com/chat/completions", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "deepseek-chat",
        messages: [{ role: "system", content: systemPrompt }, { role: "user", content: userPrompt }],
        temperature: 0.7,
        max_tokens: 2000,
      }),
    });

    if (!resp.ok) {
      console.error("[optimizePrompts] DeepSeek error:", resp.status);
      return rawPrompts;
    }

    const data = await resp.json();
    const content = data.choices?.[0]?.message?.content || "";
    const optimized = content.split("\n").map(l => l.replace(/^\d+[\.\)]\s*/, "").trim()).filter(l => l.length > 20);

    if (optimized.length >= rawPrompts.length) {
      console.log("[optimizePrompts] Got", optimized.length, "optimized prompts");
      return optimized.slice(0, rawPrompts.length);
    }
    console.log("[optimizePrompts] Not enough results, using raw");
    return rawPrompts;
  } catch (err: any) {
    console.error("[optimizePrompts] Error:", err.message);
    return rawPrompts;
  }
}

// ========== 通义万相 图片生成 ==========
async function generateSceneImage(prompt: string, model: string): Promise<string | null> {
  const apiKey = process.env.ALIYUN_API_KEY;
  if (!apiKey) {
    console.error("[generateImage] No ALIYUN_API_KEY");
    return null;
  }

  const maxRetries = 3;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 60000); // 60s per image

      const resp = await fetch("https://dashscope.aliyuncs.com/compatible-mode/v1/images/generations", {
        method: "POST",
        headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
        body: JSON.stringify({ model, prompt, n: 1, size: "1024*1024" }),
        signal: controller.signal,
      });

      clearTimeout(timeout);

      if (!resp.ok) {
        const errText = await resp.text();
        console.error(`[generateImage] ${model} attempt ${attempt}: ${resp.status} ${errText.substring(0, 200)}`);
        continue;
      }

      const data = await resp.json();
      const imageUrl = data.data?.[0]?.url;
      const b64 = data.data?.[0]?.b64_json;

      if (b64) {
        console.log(`[generateImage] ${model} OK (base64, ${b64.length} chars)`);
        return `data:image/png;base64,${b64}`;
      }

      if (imageUrl) {
        // Fetch image from URL and convert to base64
        const imgResp = await fetch(imageUrl);
        if (imgResp.ok) {
          const imgBuf = Buffer.from(await imgResp.arrayBuffer());
          const base64 = imgBuf.toString("base64");
          console.log(`[generateImage] ${model} OK (url fetched, ${base64.length} chars)`);
          return `data:image/png;base64,${base64}`;
        }
      }

      console.error(`[generateImage] ${model} attempt ${attempt}: No image data in response`);
    } catch (err: any) {
      if (err.name === "AbortError") {
        console.error(`[generateImage] ${model} attempt ${attempt}: Timeout`);
      } else {
        console.error(`[generateImage] ${model} attempt ${attempt}: ${err.message}`);
      }
    }
  }
  return null;
}

// ========== 主流程 ==========
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { projectId } = body;

    if (!projectId) {
      return NextResponse.json({ error: "projectId required" }, { status: 400 });
    }

    // ===== Step 1: 从 Supabase 查 project + submission =====
    const { data: project, error: projErr } = await supabaseAdmin
      .from("projects")
      .select("id, submission_id")
      .eq("id", projectId)
      .single();

    if (projErr) console.error("[generate-pptx] Project query error:", projErr.message);

    let submission: any = null;
    if (project?.submission_id) {
      const { data: sub, error: subErr } = await supabaseAdmin
        .from("submissions")
        .select("*")
        .eq("id", project.submission_id)
        .single();
      if (!subErr && sub) submission = sub;
    }

    // ===== Step 2: 提取所有数据 =====
    const companyName = body.clientInfo?.companyName || body.clientInfo?.clientName || submission?.company_name || submission?.companyName || "品牌";
    const industry = body.clientInfo?.industry || submission?.industry || "";
    const brandVision = body.clientInfo?.brandVision || submission?.brand_vision || submission?.brandVision || "";
    const coreValues = body.clientInfo?.coreValues || submission?.core_values || submission?.coreValues || "";
    const targetMarket = body.clientInfo?.targetMarket || submission?.target_market || submission?.targetMarket || "";
    const logoPhilosophy = body.clientInfo?.logoPhilosophy || submission?.logo_philosophy || submission?.logoPhilosophy || "";
    const mascotPhilosophy = body.clientInfo?.mascotPhilosophy || submission?.mascot_philosophy || submission?.mascotPhilosophy || "";

    const rawColors = body.brandColors || submission?.brand_colors || submission?.brandColors;
    const realColors = normalizeColors(rawColors, industry);

    console.log("[generate-pptx] ===== BRAND DATA =====");
    console.log("[generate-pptx] Company:", companyName, "| Industry:", industry);
    console.log("[generate-pptx] Colors:", JSON.stringify(realColors));
    console.log("[generate-pptx] Vision:", brandVision ? brandVision.substring(0, 50) : "empty");
    console.log("[generate-pptx] CoreValues:", coreValues ? coreValues.substring(0, 50) : "empty");
    console.log("[generate-pptx] LogoPhilosophy:", logoPhilosophy ? logoPhilosophy.substring(0, 50) : "empty");

    // ===== Step 3: 加载 Logo/Mascot =====
    let logoData: string | null = null;
    let mascotData: string | null = null;
    let mascotSplitViews: string[] | null = null;

    if (body.logoUrl) logoData = await loadImg(body.logoUrl);
    if (!logoData) logoData = await findAsset(projectId, "logo");
    if (!logoData) logoData = await findFromStorage(projectId, "logo");

    if (body.mascotUrl) mascotData = await loadImg(body.mascotUrl);
    if (body.mascotFiles?.length > 0) {
      for (const mf of body.mascotFiles) {
        const url = typeof mf === "string" ? mf : mf.url;
        mascotData = await loadImg(url);
        if (mascotData) break;
      }
    }
    if (!mascotData) mascotData = await findAsset(projectId, "mascot");
    if (!mascotData) mascotData = await findFromStorage(projectId, "mascot");
    if (mascotData) mascotSplitViews = await findSplitViews(projectId);

    console.log("[generate-pptx] Logo:", logoData ? "OK" : "null", "| Mascot:", mascotData ? "OK" : "null");

    // ===== Step 4: 生成 AI 写实场景图 =====
    const industryType = getIndustryType(industry);
    const imgDefs = SCENE_IMG_DEFS[industryType] || SCENE_IMG_DEFS.general;
    const rawPrompts = imgDefs.map(d => d.rawPrompt);

    console.log("[generate-pptx] ===== AI IMAGE GENERATION =====");
    console.log("[generate-pptx] Industry type:", industryType, "| Images to generate:", imgDefs.length);

    // 4a: DeepSeek 优化 prompt
    const optimizedPrompts = await optimizePromptsWithDeepSeek(rawPrompts, {
      name: companyName,
      industry,
      colors: `${realColors.primary} ${realColors.secondary} ${realColors.accent}`,
      vision: brandVision || "N/A",
    });

    // 4b: 通义万相 并行生成7张图
    const imageResults = await Promise.allSettled(
      imgDefs.map(async (def, i) => {
        const prompt = optimizedPrompts[i] || def.rawPrompt;
        console.log(`[generateImage] Starting ${def.key} (${def.model})...`);
        const imgData = await generateSceneImage(prompt, def.model);
        return { key: def.key, page: def.page, data: imgData };
      })
    );

    const sceneImages: Record<string, string> = {};
    let imgSuccess = 0;
    for (const result of imageResults) {
      if (result.status === "fulfilled" && result.value.data) {
        sceneImages[result.value.key] = result.value.data;
        imgSuccess++;
      } else if (result.status === "rejected") {
        console.error("[generateImage] Failed:", result.reason);
      }
    }
    console.log(`[generate-pptx] Images: ${imgSuccess}/${imgDefs.length} success`);

    // ===== Step 5: 生成蓝图 =====
    const blueprints = await planPages({
      clientInfo: { companyName, brandVision, coreValues, targetMarket, logoPhilosophy, mascotPhilosophy, industry },
      brandColors: {
        primary: { hex: realColors.primary },
        secondary: { hex: realColors.secondary },
        accent: { hex: realColors.accent },
      },
      assetAnalysis: {
        logo: { hasLogo: !!logoData, logoUrl: body.logoUrl || "", elements: [], styleTags: [], meaning: logoPhilosophy },
        mascot: { hasMascot: !!mascotData, mascotUrl: body.mascotUrl || "", isThreeView: !!(mascotSplitViews?.length === 3), splitViews: mascotSplitViews || [], name: "", style: "", personality: "" },
      },
    });

    console.log("[generate-pptx] Blueprints:", blueprints.length, "pages");

    // ===== Step 6: 渲染 PPTX =====
    const buffer = await renderPptxToBuffer(blueprints, {
      projectName: projectId,
      companyName,
      industry,
      logoData,
      mascotData,
      mascotSplitViews,
      brandColors: realColors,
      brandVision,
      coreValues,
      targetMarket,
      logoPhilosophy,
      mascotPhilosophy,
      sceneImages,
    });

    // ===== Step 7: 保存文件 =====
    const outputDir = path.join(process.cwd(), "public", "generated");
    await mkdir(outputDir, { recursive: true });
    const fileName = `vi-manual-${projectId}-${Date.now()}.pptx`;
    await writeFile(path.join(outputDir, fileName), buffer);

    console.log("[generate-pptx] ===== DONE =====", fileName, `(${imgSuccess} images, ${blueprints.length} pages)`);

    return NextResponse.json({
      success: true,
      url: `/generated/${fileName}`,
      pageCount: blueprints.length,
      imageCount: imgSuccess,
      fileName,
    });
  } catch (error: any) {
    console.error("[generate-pptx] Error:", error);
    return NextResponse.json({ error: error.message || "PPTX generation failed" }, { status: 500 });
  }
}

// ========== Helper Functions ==========
async function loadImg(imagePath: string): Promise<string | null> {
  if (!imagePath) return null;
  const candidates = [
    path.join(process.cwd(), "public", imagePath.replace(/^\//, "")),
    path.join(process.cwd(), imagePath),
  ];
  for (const fp of candidates) {
    try {
      const buf = await readFile(fp);
      const ext = path.extname(fp).toLowerCase();
      const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".gif" ? "image/gif" : ext === ".svg" ? "image/svg+xml" : "image/png";
      return `data:${mime};base64,${buf.toString("base64")}`;
    } catch { /* next */ }
  }
  if (imagePath.startsWith("http")) {
    try {
      const resp = await fetch(imagePath);
      if (resp.ok) {
        const buf = Buffer.from(await resp.arrayBuffer());
        const ct = resp.headers.get("content-type") || "image/png";
        return `data:${ct};base64,${buf.toString("base64")}`;
      }
    } catch { /* fail */ }
  }
  return null;
}

async function findAsset(projectId: string, type: "logo" | "mascot"): Promise<string | null> {
  try {
    const dir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(dir);
    const keywords = type === "logo" ? ["logo", "logo-processed"] : ["mascot", "ip", "character"];
    for (const file of files) {
      const lower = file.toLowerCase();
      if (keywords.some(k => lower.includes(k))) {
        const buf = await readFile(path.join(dir, file));
        const ext = path.extname(file).toLowerCase();
        const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : ext === ".svg" ? "image/svg+xml" : "image/png";
        return `data:${mime};base64,${buf.toString("base64")}`;
      }
    }
  } catch { /* dir not found */ }
  return null;
}

async function findFromStorage(projectId: string, type: "logo" | "mascot"): Promise<string | null> {
  try {
    const prefix = `${projectId}/${type}`;
    const { data, error } = await supabaseAdmin.storage.from("processed-assets").list(prefix, { limit: 5 });
    if (error || !data || data.length === 0) return null;
    const file = data[0];
    const filePath = `${prefix}/${file.name}`;
    const { data: urlData } = supabaseAdmin.storage.from("processed-assets").getPublicUrl(filePath);
    if (urlData?.publicUrl) return await loadImg(urlData.publicUrl);
  } catch { /* storage not configured */ }
  return null;
}

async function findSplitViews(projectId: string): Promise<string[] | null> {
  try {
    const dir = path.join(process.cwd(), "public", "processed-assets", projectId);
    const files = await readdir(dir);
    const views: string[] = [];
    for (const suffix of ["-front", "-side", "-back"]) {
      for (const file of files) {
        if (file.toLowerCase().includes(`mascot${suffix}`) || file.toLowerCase().includes(`ip${suffix}`)) {
          const buf = await readFile(path.join(dir, file));
          const ext = path.extname(file).toLowerCase();
          const mime = ext === ".jpg" || ext === ".jpeg" ? "image/jpeg" : "image/png";
          views.push(`data:${mime};base64,${buf.toString("base64")}`);
          break;
        }
      }
    }
    return views.length === 3 ? views : null;
  } catch { return null; }
}
